#!/bin/sh

usage="Usage: $0 [--download] [--download-only] [--compressed] [--prefix=PREFIX] [--install=INSTALL] [--without-all] [--with-BUILD] [--without-BUILD] [--shared]

Optional Builds:
  --without-zlib
  --without-png
  --without-jpeg
  --without-pthread
  --without-sdl
  --without-mjpeg"

download=false
compressed=false
build=true
PREFIX=
INSTALL=

build_zlib=true
build_png=true
build_jpeg=true
build_pthread=true
build_sdl=true
build_mjpeg=true

LIBTYPE="--disable-shared --enable-static"

while test $# -gt 0; do
  ac_optarg=
  case $1 in
    *=*)
      ac_optarg=`expr "X$1" : '[^=]*=\(.*\)'`
      ;;
  esac
  case $1 in
    --download)
      download=true
      compressed=true
      ;;
    --download-only)
      download=true
      compressed=false
      build=false
      ;;
    --compressed)
      compressed=true
      ;;
    --prefix=*)
      PREFIX=$ac_optarg
      ;;
    --install=*)
      INSTALL=$ac_optarg
      ;;
    --without-all)
      build_zlib=false
      build_png=false
      build_jpeg=false
      build_pthread=false
      build_mjpeg=false
      build_sdl=false
      ;;
    --with-*)
      with_arg=`expr "$1" : '--with-\(.*\)'`
      eval "build_$with_arg=true"
      ;;
    --without-*)
      without_arg=`expr "$1" : '--without-\(.*\)'`
      eval "build_$without_arg=false"
      ;;
    --shared)
      LIBTYPE="--enable-shared --disable-static"
      ;;
    *)
      echo "${usage}" 1>&2
      exit 1
      ;;
  esac
  shift
done


if test -z "$PREFIX"; then
  PREFIX=/usr/dvdauthor
fi
if test -z "$INSTALL"; then
  INSTALL=$PREFIX
fi
export TOPDIR=`pwd` PATH=$PREFIX/bin:$PATH

function need_prog
{
  uppername=`echo "$1" | sed -e 'y|abcdefghijklmnopqrstuvwxyz./-|ABCDEFGHIJKLMNOPQRSTUVWXYZ___|'`
  if eval "test \"x\$$uppername\" = \"x\"" || ! eval "test -f \$$uppername"; then
    local ret=`type -p $1`
    eval "$uppername=$ret"
  fi
  if eval "test \"x\$$uppername\" != \"x\""; then
    eval "echo $uppername=\$$uppername"
  else
    echo ERROR: $1 not found, but needed
    exit 1
  fi
}

if test x$download = xtrue; then
  need_prog wget
fi
if test x$build = xtrue; then
  need_prog libtoolize
  need_prog aclocal
  need_prog autoconf
  need_prog autoheader
  need_prog automake
fi

if test x$build = xtrue; then
  echo PREFIX=$PREFIX
fi


ZLIB=zlib-1.2.3
ZLIB_FILE=$ZLIB.tar.bz2
LIBPNG=libpng-1.2.22
LIBPNG_FILE=$LIBPNG.tar.bz2
JPEG=jpeg-6b
JPEG_FILE=jpegsrc.v6b.tar.gz
PTHREADS=pthreads-w32-2-8-0-release
PTHREADS_FILE=pthreads-w32-2-8-0-release.tar.gz
SDL=SDL-1.2.12
SDL_FILE=$SDL.tar.gz
MJPEGTOOLS=mjpegtools-1.9.0rc3
MJPEGTOOLS_FILE=$MJPEGTOOLS.tar.gz

CONFOPTS="--prefix=$PREFIX"
CPPFLAGS=-I$PREFIX/include
CFLAGS=-O3
CXXFLAGS=-O3
LDFLAGS=-L$PREFIX/lib
PKG_CONFIG_PATH=$PREFIX/lib/pkgconfig
export CPPFLAGS CFLAGS CXXFLAGS LDFLAGS PKG_CONFIG_PATH

set -x

if test x$build_zlib = xtrue; then
  if test x$download = xtrue; then
    $WGET http://www.gzip.org/zlib/$ZLIB_FILE
  fi
  if test x$compressed = xtrue; then
    tar -xjf $ZLIB_FILE
    ret_value=$?
    if test $ret_value != 0; then
      echo extraction of zlib failed
      exit $ret_value
    fi
  fi
  if test x$build = xtrue; then
    cd $ZLIB
    ./configure $CONFOPTS
    ret_value=$?
    if test $ret_value != 0; then
      echo configure of zlib failed
      exit $ret_value
    fi
    make
    ret_value=$?
    if test $ret_value != 0; then
      echo make of zlib failed
      exit $ret_value
    fi
    make install
    ret_value=$?
    if test $ret_value != 0; then
      echo make install of zlib failed
      exit $ret_value
    fi
    cd $TOPDIR
  fi
fi

if test x$build_png = xtrue; then
  if test x$download = xtrue; then
    $WGET ftp://ftp.simplesystems.org/pub/png/src/$LIBPNG_FILE
  fi
  if test x$compressed = xtrue; then
    tar -xjf $LIBPNG_FILE
    ret_value=$?
    if test $ret_value != 0; then
      echo extraction of libpng failed
      exit $ret_value
    fi
  fi
  if test x$build = xtrue; then
    cd $LIBPNG
    ./configure $CONFOPTS $LIBTYPE
    ret_value=$?
    if test $ret_value != 0; then
      echo configure of libpng failed
      exit $ret_value
    fi
    make
    ret_value=$?
    if test $ret_value != 0; then
      echo make of libpng failed
      exit $ret_value
    fi
    make install
    ret_value=$?
    if test $ret_value != 0; then
      echo make install of libpng failed
      exit $ret_value
    fi
    cd $TOPDIR
  fi
fi

if test x$build_jpeg = xtrue; then
  if test x$download = xtrue; then
    $WGET http://www.ijg.org/files/$JPEG_FILE
  fi
  if test x$compressed = xtrue; then
    tar -xzf $JPEG_FILE
    ret_value=$?
    if test $ret_value != 0; then
      echo extraction of jpeg failed
      exit $ret_value
    fi
  fi
  if test x$build = xtrue; then
    cd $JPEG
    ./configure $CONFOPTS $LIBTYPE
    ret_value=$?
    if test $ret_value != 0; then
      echo configure of jpeg failed
      exit $ret_value
    fi
    make
    ret_value=$?
    if test $ret_value != 0; then
      echo make of jpeg failed
      exit $ret_value
    fi
    make install-lib
    ret_value=$?
    if test $ret_value != 0; then
      echo make install-lib of jpeg failed
      exit $ret_value
    fi
    cd $TOPDIR
  fi
fi

if test x$build_pthread = xtrue; then
  if test x$download = xtrue; then
    $WGET ftp://sourceware.org/pub/pthreads-win32/$PTHREADS_FILE
  fi
  if test x$compressed = xtrue; then
    tar -xzf $PTHREADS_FILE
    ret_value=$?
    if test $ret_value != 0; then
      echo extraction of pthreads failed
      exit $ret_value
    fi
  fi
  if test x$build = xtrue; then
    cd $PTHREADS
    make clean GC-static
    ret_value=$?
    if test $ret_value != 0; then
      echo make of pthreads failed
      exit $ret_value
    fi
    cp pthread.h $PREFIX/include/
    cp semaphore.h $PREFIX/include/
    cp sched.h $PREFIX/include/
    cp libpthreadGC2.a $PREFIX/lib/libpthread.a
    cd $TOPDIR
  fi
fi

if test x$build_sdl = xtrue; then
  if test x$download = xtrue; then
    $WGET http://www.libsdl.org/release/$SDL_FILE
  fi
  if test x$compressed = xtrue; then
    tar -xzf $SDL_FILE
    ret_value=$?
    if test $ret_value != 0; then
      echo extraction of sdl failed
      exit $ret_value
    fi
    cd $SDL
    patch -p0 <../sdl-stdout.patch
    ret_value=$?
    if test $ret_value != 0; then
      echo patch of sdl failed
      exit $ret_value
    fi
    cd $TOPDIR
  fi
  if test x$build = xtrue; then
    cd $SDL
    ./autogen.sh
    ret_value=$?
    if test $ret_value != 0; then
      echo autogen of sdl failed
      exit $ret_value
    fi
    ./configure $CONFOPTS $LIBTYPE --disable-pthreads --disable-stdio-redirect
    ret_value=$?
    if test $ret_value != 0; then
      echo configure of sdl failed
      exit $ret_value
    fi
    make
    ret_value=$?
    if test $ret_value != 0; then
      echo make of sdl failed
      exit $ret_value
    fi
    make install
    ret_value=$?
    if test $ret_value != 0; then
      echo make install of sdl failed
      exit $ret_value
    fi
    cd $TOPDIR
  fi
fi

if test x$build_mjpeg = xtrue; then
  if test x$download = xtrue; then
    $WGET http://dfn.dl.sourceforge.net/sourceforge/mjpeg/$MJPEGTOOLS_FILE
  fi
  if test x$compressed = xtrue; then
    tar -xzf $MJPEGTOOLS_FILE
    ret_value=$?
    if test $ret_value != 0; then
      echo extraction of mjpegtools failed
      exit $ret_value
    fi
    cd $MJPEGTOOLS
    patch -p0 <$TOPDIR/$MJPEGTOOLS-mingw.patch || \
    {
      echo patch of mjpegtools failed
      exit 1
    }
    cd $TOPDIR
  fi
  if test x$build = xtrue; then
    cd $MJPEGTOOLS
    rm -rf aclocal.m4 configure Makefile.in
    $LIBTOOLIZE --copy --automake
    ret_value=$?
    if test $ret_value != 0; then
      echo libtoolize of mjpegtools failed
      exit $ret_value
    fi
    $ACLOCAL -I $PREFIX/share/aclocal
    ret_value=$?
    if test $ret_value != 0; then
      echo aclocal of mjpegtools failed
      exit $ret_value
    fi
    $AUTOCONF
    ret_value=$?
    if test $ret_value != 0; then
      echo autoconf of dvdauthor failed
      exit $ret_value
    fi
    $AUTOHEADER
    ret_value=$?
    if test $ret_value != 0; then
      echo autoheader of dvdauthor failed
      exit $ret_value
    fi
    $AUTOMAKE -a -c
    ret_value=$?
    if test $ret_value != 0; then
      echo automake of dvdauthor failed
      exit $ret_value
    fi
    mkdir build
    cd build
    ../configure --prefix=$INSTALL --enable-static --disable-shared LDFLAGS="$LDFLAGS -static"
    ret_value=$?
    if test $ret_value != 0; then
      echo configure of mjpegtools failed
      exit $ret_value
    fi
    make LDFLAGS="$LDFLAGS -all-static"
    ret_value=$?
    if test $ret_value != 0; then
      echo make of mjpegtools failed
      exit $ret_value
    fi
    make install-strip
    ret_value=$?
    if test $ret_value != 0; then
      echo make install-strip of mjpegtools failed
      exit $ret_value
    fi
    cd $TOPDIR
  fi
fi

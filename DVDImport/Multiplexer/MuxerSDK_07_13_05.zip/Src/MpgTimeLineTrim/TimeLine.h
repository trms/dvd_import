//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//	Copyright (C) 2003 AMMTools. All rights reserved.
//	http://www.ammtools.com mailto:support@ammtools.com

#pragma once
#include <list>
#include "..\XUtils\XUString.h"

class CSegmentEntry
{
public:
	CSegmentEntry(double fSegBegin, double fSegEnd) :
	  m_fSegBegin(fSegBegin), m_fSegEnd(fSegEnd)
	{}

	bool IsInvalid() const
	{
		return m_fSegBegin < 0 || m_fSegEnd <= 0 ||
				m_fSegBegin >= m_fSegEnd;
	}

	bool DoOverlap(const CSegmentEntry& Seg) const
	{
		return (m_fSegBegin < Seg.m_fSegBegin && Seg.m_fSegBegin < m_fSegEnd) ||
				(m_fSegBegin < Seg.m_fSegEnd && Seg.m_fSegEnd < m_fSegEnd);
	}

	const double m_fSegBegin;
	const double m_fSegEnd;
};

class CTimeLine : public std::list<CSegmentEntry>
{
public:
	CTimeLine(LPCTSTR tcsFileName, LPCTSTR tcsPrefix = _T("Segment")) :
		m_sForFileName(tcsFileName), m_sFileNamePrefix(tcsPrefix)
	{}

	const XU::CTString	m_sForFileName; // 
	XU::CTString		m_sFileNamePrefix; // We use this for generating segments output file names
};
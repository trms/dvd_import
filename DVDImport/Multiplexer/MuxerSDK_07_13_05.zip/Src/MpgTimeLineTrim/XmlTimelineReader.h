//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//	Copyright (C) 2003 AMMTools. All rights reserved.
//	http://www.ammtools.com mailto:support@ammtools.com

#pragma once
#include "..\XUtils\XUXmlParser.h"
#include "TimeLine.h"

class CXmlTimelineReader : public XU::AXmlParseCallback, public XU::CXmlParser
{
public:
	CXmlTimelineReader(LPCTSTR tcsXmlFileName);

	const CTimeLine* GetTimeLineFor(LPCTSTR tcsFileName) const
	{
		return m_TimeLines.Find(tcsFileName);
	}


	// AXmlParseCallback impl
	virtual void OnParseStart(LPCSTR csData, size_t nDataSize){}
	virtual void OnParseCompleted(HRESULT hr){}

	// We neeed only this function
	virtual void OnElementBegin(ptrdiff_t nPos, LPCTSTR csTag, const XU::CItemsList* pParams);
	//

	virtual void OnElementDataBegin(ptrdiff_t nPos, LPCTSTR tsTag){}
	virtual void OnElementDataEnd(ptrdiff_t nPos, LPCTSTR tsTag){}
	virtual void OnComments(ptrdiff_t nPos, size_t nSize){}
	virtual void OnInstruction(ptrdiff_t nPos, size_t nSize){}

private:
	void OnNextTimeLine(const XU::CItemsList* pParams);
	void OnNextTimeLineEntry(const XU::CItemsList* pParams);

	class CTimeLineList : public std::list<CTimeLine>
	{
	public:
		const CTimeLine* Find(LPCTSTR tcsFileName);
	};

	struct PSearch : public std::unary_function<CTimeLine&, bool>
	{
		PSearch(LPCTSTR tcsStr) : m_sString(tcsStr)
		{}
		result_type operator()(argument_type l)
		{
			return !_tcsicmp(l.m_sForFileName, m_sString);
		}
		const XU::CTString m_sString;
	};

	mutable CTimeLineList m_TimeLines;

	CTimeLine*			m_pCurTimeLine;
};
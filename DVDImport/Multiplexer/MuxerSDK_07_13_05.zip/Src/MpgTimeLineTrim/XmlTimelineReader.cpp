//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//	Copyright (C) 2003 AMMTools. All rights reserved.
//	http://www.ammtools.com mailto:support@ammtools.com

#include "XmlTimeLineReader.h"
#include <functional>
#include "..\XUtils\XUFileNameUtils.h"

CXmlTimelineReader::CXmlTimelineReader(LPCTSTR tcsXmlFileName) :
		XU::CXmlParser(*this, tcsXmlFileName),
		m_pCurTimeLine(NULL)
{
	Start();
}

void CXmlTimelineReader::OnElementBegin(ptrdiff_t nPos, LPCTSTR csTag, const XU::CItemsList* pParams)
{
	if(XU::CheckName(csTag, "TimeLine"))
		OnNextTimeLine(pParams);
	else if(XU::CheckName(csTag, "Segment"))
		OnNextTimeLineEntry(pParams);
}

void CXmlTimelineReader::OnNextTimeLine(const XU::CItemsList* pParams)
{	using namespace XU;
	// Check here if this element is valid
	// if(...)
	// 	throw _T("Invalid element");

	CTString sFileName, sSegmentPrefix(_T("Segment_"));

	CItemsList& params = const_cast<CItemsList&>(*pParams);
	for(CItemsList::iterator n  = params.begin(); n != params.end(); n++)
		if(CheckName(*n, _T("ForFile")))
			sFileName = GetLPCTSTR(*n);
		else if(CheckName(*n, _T("SegmentPrefix")))
			sSegmentPrefix = GetLPCTSTR(*n);

	m_TimeLines.push_back(CTimeLine(sFileName, sSegmentPrefix));
	m_pCurTimeLine = &m_TimeLines.back();
}

void CXmlTimelineReader::OnNextTimeLineEntry(const XU::CItemsList* pParams)
{	using namespace XU;
	// Check here if this element is valid
	// if(...)
	// 	throw _T("Invalid element");

	double fStart = 0, fEnd = 0;
	CItemsList& params = const_cast<CItemsList&>(*pParams);
	for(CItemsList::iterator n  = params.begin(); n != params.end(); n++)
		if(CheckName(*n, _T("Start")))
			fStart = GetDouble(*n);
		else if(CheckName(*n, _T("End")))
			fEnd = GetDouble(*n);

	assert(m_pCurTimeLine);
	m_pCurTimeLine->push_back(CSegmentEntry(fStart, fEnd));
}


const CTimeLine* CXmlTimelineReader::CTimeLineList::Find(LPCTSTR tcsFileName)
{
	// Try to find with full path search
	iterator f = std::find_if(begin(), end(), PSearch(tcsFileName));
	if(f != end())
		return &(*f);

	// Extract only filename and try to search for it
	XU::CTString sFileName(XU::GetFileName(XU::CTString(tcsFileName)));

	f = std::find_if(begin(), end(), PSearch(sFileName));
	if(f != end())
		return &(*f);
	
	// If there is a default timeline for all input files
	f = std::find_if(begin(), end(), PSearch(_T("")));
	if(f != end())
		return &(*f);


	return NULL; // Not found
}
//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//	Copyright (C) 2003 AMMTools. All rights reserved.
//	http://www.ammtools.com mailto:support@ammtools.com


#pragma once
#include "..\AMMTDS\DirectShow.h"
#include "TimeLine.h"

//
#include "..\Inc\MuxerFltrIfaces.h"
#include "..\Inc\SmartFileDumpFltrIfaces.h"

class CTimeLineGraph : public AMMTDS::CGraph
{
public:
	CTimeLineGraph(LPCTSTR tcsInFile, LPCTSTR tcsOutDir, const CTimeLine& TimeLine);
	class CStringList : public std::list<XU::CTString>{};

	CStringList			m_GraphInfo;

	// Graph statistics
    REFERENCE_TIME		GetCurrentMuxTime() const;
    ULONGLONG			GetCurrentMuxBytePos() const;
    DWORD				GetCurrentMuxStatus() const;

	LPCWSTR				GetCurOutputFileName() const;
    ULONGLONG			GetBytesWritten() const;        

protected:
	// CGraph overrides
	// Initialization
	virtual HRESULT		CreateFilters(LPCWSTR wcsSourceFile);
	virtual HRESULT		ConnectFilters();
	virtual HRESULT		QueryInterfaces();

private:
	bool				m_bConnectAutomatic;
	AMMTDS::CFilter		ConnectDemuxer(AMMTDS::CFilter& Source);
	void				SelectMuxer(AMMTDS::CPin pinVideo,AMMTDS::CPin pinAudio);
	AMMTDS::CPin		FindVideoPin(const AMMTDS::CFilter& Demuxer);
	AMMTDS::CPin		FindAudioPin(const AMMTDS::CFilter& Demuxer);

	// Filters
	AMMTDS::CFilter				m_AudioSource;
	AMMTDS::CFilter				m_VideoSource;

	AMMTDS::CFilter				m_ProgramMuxer;
	AMMTDS::CFilter				m_SystemMuxer;

	AMMTDS::CFilter				m_FileDump;
	CComPtr<IDumpProgress>		m_DumpProgress;
	CComPtr<IFileSinkFilter>	m_DumpSink;
	mutable XU::CWString		m_sCurOutFilename;

	// Currently selected multiplexer 
	AMMTDS::CFilter				m_Muxer;
	CComPtr<IMuxProgress>		m_MuxProgress;

	XU::CWString				m_sOutDir;
	const CTimeLine&			m_TimeLine;
};
//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//	Copyright (C) 2003 AMMTools. All rights reserved.
//	http://www.ammtools.com mailto:support@ammtools.com


#include "TimelineGraph.h"

#include "stdafx.h"
#include "..\XUtils\XUString.h"
#include "..\XUtils\XUFileNameUtils.h"
#include <conio.h>
#include "XmlTimelineReader.h"


#pragma warning(disable: 4290) // warning C4290: MS compiler doesn't support C++ function exception specification

// Helper class for parsing program input arguments
class CArgParser
{
public:
	CArgParser(int argc, _TCHAR* argv[]); // throws an exception if something wrong

	XU::CTString	m_sInFile;		// Input MPEG filename
	XU::CTString	m_sXmlFile;		// XML file with timeline
	XU::CTString	m_sOutDir;		// Output directory for trimmed segments
};


// Helper class for tracking multiplexing proccess
class CMuxingProgress
{
public:
	CMuxingProgress(const CTimeLineGraph& Graph, size_t nSecsTimeout);
	~CMuxingProgress();

	void	Display();

private:
	const CTimeLineGraph&	m_Graph;
	// Statistics
	const size_t			m_nSecsTimeout;
	REFERENCE_TIME*			m_rtPrevPositions;
	XU::CWString			m_wcsPrevOutputFileName;
	ULONGLONG				m_ullCurBytesWritten;
	bool					m_bNext;
};


// Display graph properties
void DisplayGraphInfo(const CTimeLineGraph& Graph);

// Check if timeline is valid and display errors if any found
void ValidateTimeLine(const CTimeLine* pTimeline) throw (LPCTSTR);


// Main
int _tmain(int argc, _TCHAR* argv[])
{
    CoInitialize(NULL);
	try
	{
		// Parse and check arguments
		CArgParser Args(argc, argv);

		// Read XML timelines
		_tprintf(_T("Reading timeline... "));
		CXmlTimelineReader XmlReader(Args.m_sXmlFile);

		// Find timeline for given input file
		const CTimeLine* pTimeLine = XmlReader.GetTimeLineFor(Args.m_sInFile);
		
		// Check if TimeLine has any errors
		ValidateTimeLine(pTimeLine);// thorws exception if something is wrong

		int n = 0;
		for(CTimeLine::iterator j = const_cast<CTimeLine*>(pTimeLine)->begin(); 
			j != const_cast<CTimeLine*>(pTimeLine)->end();  j++, n++)
			_tprintf(_T("\nEntry # %d (Begin = %2g sec  End = %2g sec)\n"),
				n,	(*j).m_fSegBegin, (*j).m_fSegEnd);

		// Build the graph
		_tprintf(_T("OK\nInitializing graph... "));
		CTimeLineGraph Graph(Args.m_sInFile, Args.m_sOutDir, *pTimeLine);
		_tprintf(_T("OK\n"));
		DisplayGraphInfo(Graph);

		_tprintf(_T("Running graph (Press 'Esc' to abort)\n"));
		// Run the graph 
		HRESULT hr = Graph.Run();
		if(FAILED(hr))
			throw AMMTDS::CQuartzExc(_T("Run failed"), hr);

		// Create object for tracking multiplexing progress
		CMuxingProgress Progress(Graph, 10);

		// Now wait until graph is done with its job
		// or user press 'Esc'
		while(!Graph.WaitForCompletion(1000)) // 1 sec timeout
		{
			if(_kbhit() && _getch() == 27)
				throw _T("Operation aborted by user\n");

			Progress.Display();
		}
		_tprintf(_T("\nOperation completed."));
	}
	catch(LPCTSTR tcsError)
	{
		_tprintf(tcsError);
	}
	catch(const XU::CW32Exc& exc)
	{
		XU::CTString sMsg;
		if(exc.FormatMessage(sMsg))
			_tprintf(sMsg);
		else
			_tprintf((LPCTSTR)exc);
	}
	catch(...)
	{
		_tprintf(_T("Unexpected failure!"));
	}

	_tprintf(_T("\nPress any key to exit\n"));
	_getch();

	CoUninitialize();
	return 0;
}

void DisplayGraphInfo(const CTimeLineGraph& Graph)
{
	for(CTimeLineGraph::CStringList::const_iterator i = Graph.m_GraphInfo.begin();
		i != Graph.m_GraphInfo.end(); i++)
	{
		_tprintf((LPCTSTR)(*i));
		_tprintf(_T("\n"));
	}
}

// Check if timeline is valid and display errors if any found
void ValidateTimeLine(const CTimeLine* pTimeline) throw (LPCTSTR)
{
	if(!pTimeline || pTimeline->empty())
		throw _T("ERROR: TimeLine for given input MPEG file is empty");

	// check for not-positive time duration
	CTimeLine::const_iterator i = std::find_if(pTimeline->begin(), pTimeline->end(),
							std::mem_fun_ref(&CSegmentEntry::IsInvalid));
	if(i != pTimeline->end())
	{
		_tprintf(_T("\nEntry # %d is invalid: Begin = %2g sec  End = %2g sec\n"),
			std::distance(i, pTimeline->begin()), (*i).m_fSegBegin, (*i).m_fSegEnd);
		throw _T("ERROR: Timeline is invalid. Aborting.");
	}

	// check for overlapping
	for(CTimeLine::iterator j = const_cast<CTimeLine*>(pTimeline)->begin(); 
			j != const_cast<CTimeLine*>(pTimeline)->end();  j++)
	{
		CTimeLine::iterator next = j;
		++ next;
		for(next; next != const_cast<CTimeLine*>(pTimeline)->end();  next++)
			if((*j).DoOverlap(*next))
			{
				_tprintf(_T("\nOverlaping entries:\n\
	Entry # %d (Begin = %2g sec  End = %2g sec)\n\
	Entry # %d (Begin = %2g sec  End = %2g sec)\n"),
					std::distance(j, const_cast<CTimeLine*>(pTimeline)->begin()), (*j).m_fSegBegin, (*j).m_fSegEnd,
					std::distance(next, const_cast<CTimeLine*>(pTimeline)->begin()), (*next).m_fSegBegin, (*next).m_fSegEnd);
				throw _T("ERROR: Timeline is invalid. Aborting.");
			}
	}
}


// CArgParser implementation
CArgParser::CArgParser(int argc, _TCHAR* argv[]) // Arguments passed to program
{
	if(argc < 4)
		throw _T("ERROR: 3 input argumens are expected: input MPEG filename,\
XML TimeLine filename and output directory name.");

	if(argc > 4)
		_tprintf(_T("WARNING: Only 3 arguments are expected. Extra arguments will be ignored.\n"));

	m_sInFile	= argv[1];		// Input MPEG filename
	m_sXmlFile	= argv[2];		// XML file with timeline
	m_sOutDir	= argv[3];		// Output directory for trimmed segments

	// Check if input files exist
	if(!XU::CheckCanOpenFile(m_sInFile))
		throw XU::CW32FileExc(_T("Unable to open input MPEG file : "),
								m_sInFile, HRESULT_FROM_WIN32(GetLastError()));

	if(!XU::CheckCanOpenFile(m_sXmlFile))
		throw XU::CW32FileExc(_T("Unable to open XML timeline file : "),
								m_sXmlFile, HRESULT_FROM_WIN32(GetLastError()));

	// Try to open output directory
	XU::XUCreateDirectory(m_sOutDir);
	if(!XU::CheckDirectoryExisists(m_sOutDir))
		throw XU::CW32FileExc(_T("Unable to open Output directory : "),
								m_sOutDir, HRESULT_FROM_WIN32(GetLastError()));
}

// CMuxingProgress implementation
CMuxingProgress::CMuxingProgress(const CTimeLineGraph& Graph, size_t nSecsTimeout) :
				m_Graph(Graph),
				m_nSecsTimeout(nSecsTimeout),
				m_ullCurBytesWritten(Graph.GetBytesWritten()),
				m_rtPrevPositions(new REFERENCE_TIME[nSecsTimeout]),
				m_bNext(true)
{
	for(size_t n = 0; n < m_nSecsTimeout; n++)
		m_rtPrevPositions[n] = -1;
}

CMuxingProgress::~CMuxingProgress()
{
	delete [] m_rtPrevPositions;
}

void CMuxingProgress::Display()
{
	// Check if proccess hangs
	REFERENCE_TIME rtCurMuxTime = m_Graph.GetCurrentMuxTime();
	if(rtCurMuxTime == m_rtPrevPositions[0])// we havn't move during last 10 seconds ?
		throw _T("Progress has not changed during timeout period. Aborting...\n");
	// Remember current position
	for(size_t n = 0; n < 7; n++)
		m_rtPrevPositions[n] = m_rtPrevPositions[n + 1];
	m_rtPrevPositions[8] = rtCurMuxTime;

	// Display progress
	// Have current filename and number of written bytes changed?
	LPCWSTR wcsCurFileName = m_Graph.GetCurOutputFileName();
	bool bNewFile = _wcsicmp(m_wcsPrevOutputFileName, wcsCurFileName);
	ULONGLONG ullWritten = m_Graph.GetBytesWritten();
	DWORD dwMuxStatus = m_Graph.GetCurrentMuxStatus();

	if(dwMuxStatus == MUX_STATUS_BETWEEN_INTERVALS)// waiting for next segment
	{
		if(m_bNext)// just entered waiting mode
		{
			_tprintf(_T("\nWaiting for next segment"));
			m_bNext = false;
		}
		_tprintf(_T("."));
	}
	else if(bNewFile)// next segment just began
	{
		_tprintf(_T("\n%s ."), (LPCTSTR)XU::CTString(wcsCurFileName));
		m_wcsPrevOutputFileName = wcsCurFileName;
		m_bNext = true;
	}
	else// continuing writing of current segment
		_tprintf(_T("."));

	m_ullCurBytesWritten = ullWritten;
}


//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//	Copyright (C) 2003 AMMTools. All rights reserved.
//	http://www.ammtools.com mailto:support@ammtools.com


#include "MuxGraph.h"

#include "stdafx.h"
#include "..\XUtils\XUString.h"
#include "..\XUtils\XUFileNameUtils.h"
#include <conio.h>


#pragma warning(disable: 4290) // warning C4290: MS compiler doesn't support C++ function exception specification

// Helper class for parsing program input arguments
class CArgParser
{
public:
	CArgParser(int argc, _TCHAR* argv[]); // throws an exception if something wrong

	XU::CTString	m_sInVideoFile;	// Input MPEG Video filename
	XU::CTString	m_sInAudioFile;	// Input MPEG Audio filename
	XU::CTString	m_sOutFile;		// Output filename
};


// Helper class for tracking multiplexing proccess
class CMuxingProgress
{
public:
	CMuxingProgress(const CMuxGraph& Graph, size_t nSecsTimeout);
	~CMuxingProgress();

	void	Display();

private:
	const CMuxGraph&	m_Graph;
	// Statistics
	const size_t			m_nSecsTimeout;
	REFERENCE_TIME*			m_rtPrevPositions;
	XU::CWString			m_wcsPrevOutputFileName;
	ULONGLONG				m_ullCurBytesWritten;
	bool					m_bNext;
};


// Display graph properties
void DisplayGraphInfo(const CMuxGraph& Graph);

// Main
int _tmain(int argc, _TCHAR* argv[])
{
    CoInitialize(NULL);
	try
	{
		// Parse and check arguments
		CArgParser Args(argc, argv);

		// Build the graph
		_tprintf(_T("Initializing graph... "));
		CMuxGraph Graph(Args.m_sInVideoFile, Args.m_sInAudioFile, Args.m_sOutFile);
		_tprintf(_T("OK\n"));
		DisplayGraphInfo(Graph);

		_tprintf(_T("Running graph (Press 'Esc' to abort)\n"));
		// Run the graph 
		HRESULT hr = Graph.Run();
		if(FAILED(hr))
			throw AMMTDS::CQuartzExc(_T("Run failed"), hr);

		// Create object for tracking multiplexing progress
		CMuxingProgress Progress(Graph, 10);

		// Now wait until graph is done with its job
		// or user press 'Esc'
		while(!Graph.WaitForCompletion(1000)) // 1 sec timeout
		{
			if(_kbhit() && _getch() == 27)
				throw _T("Operation aborted by user\n");

			Progress.Display();
		}
		_tprintf(_T("\nOperation completed."));
	}
	catch(LPCTSTR tcsError)
	{
		_tprintf(tcsError);
	}
	catch(const XU::CW32Exc& exc)
	{
		XU::CTString sMsg;
		if(exc.FormatMessage(sMsg))
			_tprintf(sMsg);
		else
			_tprintf((LPCTSTR)exc);
	}
	catch(...)
	{
		_tprintf(_T("Unexpected failure!"));
	}

	_tprintf(_T("\nPress any key to exit\n"));
	_getch();

	CoUninitialize();
	return 0;
}

void DisplayGraphInfo(const CMuxGraph& Graph)
{
	for(CMuxGraph::CStringList::const_iterator i = Graph.m_GraphInfo.begin();
		i != Graph.m_GraphInfo.end(); i++)
	{
		_tprintf((LPCTSTR)(*i));
		_tprintf(_T("\n"));
	}
}

// CArgParser implementation
CArgParser::CArgParser(int argc, _TCHAR* argv[]) // Arguments passed to program
{
	if(argc < 4)
		throw _T("ERROR: 3 input argumens are expected: input MPEG VIDEO filename,\
input MPEG AUDIO filename, and name for output file.");

	if(argc > 4)
		_tprintf(_T("WARNING: Only 3 arguments are expected. Extra arguments will be ignored.\n"));

	m_sInVideoFile	= argv[1];		// Input MPEG Video filename
	m_sInAudioFile	= argv[2];		// Input MPEG Audio filename
	m_sOutFile	= argv[3];		// Output filename

	// Check if input files exist
	if(!XU::CheckCanOpenFile(m_sInVideoFile))
		throw XU::CW32FileExc(_T("Unable to open input MPEG Video file : "),
								m_sInVideoFile, HRESULT_FROM_WIN32(GetLastError()));

	if(!XU::CheckCanOpenFile(m_sInAudioFile))
		throw XU::CW32FileExc(_T("Unable to open input MPEG Audio file : "),
								m_sInAudioFile, HRESULT_FROM_WIN32(GetLastError()));

	// Try to open output file
	if(!XU::CheckCanOpenFile(m_sOutFile, GENERIC_WRITE, CREATE_ALWAYS))
		throw XU::CW32FileExc(_T("Unable to open Output file : "),
								m_sOutFile, HRESULT_FROM_WIN32(GetLastError()));
}

// CMuxingProgress implementation
CMuxingProgress::CMuxingProgress(const CMuxGraph& Graph, size_t nSecsTimeout) :
				m_Graph(Graph),
				m_nSecsTimeout(nSecsTimeout),
				m_ullCurBytesWritten(Graph.GetBytesWritten()),
				m_rtPrevPositions(new REFERENCE_TIME[nSecsTimeout]),
				m_bNext(true)
{
	for(size_t n = 0; n < m_nSecsTimeout; n++)
		m_rtPrevPositions[n] = -1;
}

CMuxingProgress::~CMuxingProgress()
{
	delete [] m_rtPrevPositions;
}

void CMuxingProgress::Display()
{
	// Check if proccess hangs
	REFERENCE_TIME rtCurMuxTime = m_Graph.GetCurrentMuxTime();
	if(rtCurMuxTime == m_rtPrevPositions[0])// we havn't move during last 10 seconds ?
		throw _T("Progress has not changed during timeout period. Aborting...\n");
	// Remember current position
	for(size_t n = 0; n < 7; n++)
		m_rtPrevPositions[n] = m_rtPrevPositions[n + 1];
	m_rtPrevPositions[8] = rtCurMuxTime;
	m_ullCurBytesWritten = m_Graph.GetBytesWritten();

	// Display progress
	_tprintf(_T("."));
}


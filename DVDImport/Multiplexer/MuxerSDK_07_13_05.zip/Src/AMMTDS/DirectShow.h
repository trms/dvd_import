//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//	Copyright (C) 2003 AMMTools. All rights reserved.
//	http://www.ammtools.com mailto:support@ammtools.com


#pragma once
#include <streams.h>
#include <atlbase.h>
#include <assert.h>
#include <list>
#include <string>
#include "..\XUtils\XUExc.h"

namespace AMMTDS
{
	// DirectShow exception class
	class CQuartzExc : public XU::CW32Exc
	{
	public:
		CQuartzExc(LPCTSTR tcsMessage, HRESULT hr);
		virtual bool	FormatMessage(XU::CTString& sMessage) const;
	};

	// DirectShow PIN class
	class CPin : public CComPtr<IPin>
	{
	public:
		CPin()
		{}
		CPin(IPin* pPin) : CComPtr<IPin>(pPin)
		{}

		class CMediaTypeList : public std::list<AM_MEDIA_TYPE>
		{
		public:
			~CMediaTypeList();
		};
		HRESULT GetMediaTypes(CMediaTypeList& refList) const;
	};

	// DirectShow FILTER class
	class CFilter : public CComPtr<IBaseFilter>
	{
	public:
		CFilter(){}
		CFilter(IBaseFilter* pFilter) : CComPtr<IBaseFilter>(pFilter){}
		CFilter(REFCLSID clsid)
		{
			HRESULT hr = CoCreateInstance(clsid);
			if(FAILED(hr))
				throw hr;
		}
		// Definition of pointer to COM class factory function
		typedef CUnknown *(*ComObjClassFactory)(LPUNKNOWN pUnkOuter, HRESULT *phr);
		
		// Constructor that accepts pointer to
		// COM class factory method
		CFilter(ComObjClassFactory pCreateInstance, HRESULT* pHr)
		{
			HRESULT hr = S_OK;
			INonDelegatingUnknown* pUnk = pCreateInstance(NULL, &hr);
			if(SUCCEEDED(hr) && pUnk)
				hr = pUnk->NonDelegatingQueryInterface(IID_IBaseFilter, (LPVOID*)&p);
			if(pHr)
				*pHr = hr;
		}

		virtual ~CFilter(){}

		CFilter* operator &()
		{
			return	this;
		}

		class CPinsList : public std::list<CPin>{};
		template<typename T> HRESULT EnumPins(CPinsList& refList, T Predicate) const;
		typedef	bool (*PinsEnumFunc)(IPin*);
		HRESULT EnumPins(CPinsList& refList, PinsEnumFunc pPinsEnumFunc) const;
	};


	// DirectShow GRAPH base class
	class CGraph : public CComPtr<IGraphBuilder>
	{
	public:
		virtual ~CGraph();

		//
		// Graph construction 
		HRESULT					Init(LPCWSTR wcsSourceFile);
		void					Reset();

		HRESULT					AddFilter(IBaseFilter* pFilter, LPCWSTR wcsName);
		HRESULT					CreateFilter(REFCLSID clsid, LPCWSTR wcsName, CFilter* pNewFilter = NULL);
		HRESULT					CreateSourceFilter(LPCWSTR wcsFileName, LPCWSTR wcsName, CFilter* pNewFilter = NULL);
		HRESULT					Connect(CPin& OutPin, CPin& InPin, bool bIntelligent = true);
		void					RemoveNotConnectedFilters();


		class CFiltersList : public std::list<CFilter>{};
		template<typename T> HRESULT EnumFilters(CFiltersList& refList, T Predicate) const;
		typedef	bool (*FilterEnumFunc)(IBaseFilter*);
		HRESULT EnumFilters(CFiltersList& refList, FilterEnumFunc pFltEnumFunc) const;

		//
		// Graph runtime operations
		REFERENCE_TIME			GetDuration() const
		{
			return m_rtDuration;
		}

		REFERENCE_TIME			GetPosition() const;
		HRESULT					SetPosition(const REFERENCE_TIME& rt);
		//
		HRESULT					Run();
		HRESULT					Pause();
		HRESULT					Stop();

		enum GraphRuntimeState
		{
			grsStopped = State_Stopped,
			grsPaused = State_Paused,
			grsRunning = State_Running,
			grsIntermediate = grsRunning + 1,
			grsPausedCantCue = grsIntermediate + 1,
			grsError = grsPausedCantCue + 1
		};
		GraphRuntimeState		GetState() const;

		bool					WaitForOperationCompleted() const;
		bool					WaitForCompletion(LONG lTimeout = INFINITE) const;


	protected:
		// Initialization
		virtual HRESULT			CreateFilters(LPCWSTR wcsSourceFile) = 0;
		virtual HRESULT			ConnectFilters()
		{
			return S_OK;
		}
		virtual HRESULT			QueryInterfaces();

		// Deinitializtion
		virtual void			ReleaseInterfaces();
		virtual void			DisassembleGraph()
		{}
		virtual void			ReleaseFilters()
		{}
		

		XU::CWString			m_sSourceFile;

		mutable CComPtr<IMediaSeeking>	m_pSeeking;
		mutable CComPtr<IMediaControl>	m_pControl;
		mutable CComPtr<IMediaEvent>	m_pEvent;

		REFERENCE_TIME					m_rtDuration;
	};

	//
	// Implementation of template functions
	template<typename T> HRESULT CFilter::EnumPins(CFilter::CPinsList& refList, T Predicate) const
	{
		assert(p);

		refList.clear();

		CComPtr<IEnumPins>		pEnum;
		HRESULT hr = const_cast<IBaseFilter*>(p)->EnumPins(&pEnum);
		if(FAILED(hr))
			return hr;

		IPin*	pPin = NULL;
		ULONG	cFetched	= 0;
		while(pEnum->Next(1, &pPin, &cFetched) == S_OK)
		{
			if(Predicate(pPin))
				refList.push_back(pPin);
			pPin->Release();
		}
		return refList.empty() ? S_FALSE : S_OK;
	}


	//
	template<typename T> HRESULT CGraph::EnumFilters(CGraph::CFiltersList& refList, T Predicate) const
	{
		assert(p);

		refList.clear();

		CComPtr<IEnumFilters>	pEnum;
		HRESULT hr = const_cast<IGraphBuilder*>(p)->EnumFilters(&pEnum);
		if(FAILED(hr))
			return hr;

		IBaseFilter*	pFilter = NULL;
		ULONG			cFetched	= 0;
		while(pEnum->Next(1, &pFilter, &cFetched) == S_OK)
		{
			if(Predicate(pFilter))
				refList.push_back(pFilter);
			pFilter->Release();
		}
		return refList.empty() ? S_FALSE : S_OK;
	}
}
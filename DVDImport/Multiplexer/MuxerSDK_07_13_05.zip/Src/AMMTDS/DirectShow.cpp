//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//	Copyright (C) 2003 AMMTools. All rights reserved.
//	http://www.ammtools.com mailto:support@ammtools.com


#include "DirectShow.h"
#include "DirectShowUtils.h"

namespace AMMTDS
{
	// CQuartzExc - exception class for DirectShow
	CQuartzExc::CQuartzExc(LPCTSTR tcsMessage, HRESULT hr):	XU::CW32Exc(tcsMessage, hr)
	{}

	bool CQuartzExc::FormatMessage(XU::CTString& sMessage) const
	{
		bool bRet = false;
		LPTSTR lpszTemp = NULL,	tcsDest = NULL;
		try
		{
			lpszTemp = new TCHAR[MAX_ERROR_TEXT_LEN + 1];
			if(AMGetErrorText(m_hrError, lpszTemp, MAX_ERROR_TEXT_LEN))
			{

				tcsDest = new TCHAR[_tcslen(lpszTemp) + _tcslen(m_tcsText) + 36];
				_stprintf(tcsDest, _T("%s\n(%s hr = 0x%x)\n"), m_tcsText, lpszTemp, m_hrError);
				sMessage = tcsDest;
				bRet = true;
			}
			else
				bRet = XU::CW32Exc::FormatMessage(sMessage);
		}
		catch(...)
		{
			assert(false);
			bRet = false;
		}
		delete [] lpszTemp;
		delete [] tcsDest;
		return bRet;
	}

	CPin::CMediaTypeList::~CMediaTypeList()
	{
		while(!empty())
		{
			if(back().cbFormat)
				CoTaskMemFree((void*)back().pbFormat);
			pop_back();
		}
	}

	HRESULT CPin::GetMediaTypes(CPin::CMediaTypeList& refList) const
	{
		refList.clear();
		CComPtr<IEnumMediaTypes> pEnum;
		HRESULT hr = p->EnumMediaTypes(&pEnum);
		if(SUCCEEDED(hr))
		{
			AM_MEDIA_TYPE*	pamt		= NULL;
			ULONG			cFetched	= 0;
			while(pEnum->Next(1, &pamt, &cFetched) == S_OK)
			{
				refList.push_back(*pamt);
	//			DSFreeMediaType(*pamt);
			}
		}
		return hr;
	}


	// DirectShow Graph class
	CGraph::~CGraph()
	{}

	HRESULT CGraph::Init(LPCWSTR wcsSourceFile)
	{
		HRESULT hr = S_OK;
		try
		{
			Reset();

			if(!p && FAILED(hr= CoCreateInstance(CLSID_FilterGraph)))
				throw hr;

			if(FAILED(hr = CreateFilters(wcsSourceFile)))
				throw hr;

			if(FAILED(hr = ConnectFilters()))
				throw hr;

			if(FAILED(hr = QueryInterfaces()))
				throw hr;

			m_pSeeking->GetDuration(&m_rtDuration);


			m_sSourceFile = wcsSourceFile;
		}
		catch(const HRESULT&)
		{
			Reset();
		}
		return hr;
	}

	void CGraph::Reset()
	{
		m_sSourceFile.clear();
		m_rtDuration = 0;
		ReleaseInterfaces();
		DisassembleGraph();
		ReleaseFilters();
		Release();
	}

	HRESULT CGraph::QueryInterfaces()
	{
		assert(p);
		HRESULT hr = QueryInterface(&m_pSeeking);
		if(FAILED(hr))
			return hr;
		if(FAILED(hr = QueryInterface(&m_pEvent)))
			return hr;
		return hr = QueryInterface(&m_pControl);
	}

	void CGraph::ReleaseInterfaces()
	{
		if(m_pSeeking)
			m_pSeeking.Release();

		if(m_pControl)
			m_pControl.Release();

		if(m_pEvent)
			m_pEvent.Release();
	}

	//
	HRESULT CGraph::AddFilter(IBaseFilter* pFilter, LPCWSTR wcsName)
	{
		assert(p && pFilter);
		if(!pFilter)
			return E_POINTER;
		return p->AddFilter(pFilter, wcsName);
	}

	HRESULT CGraph::CreateFilter(REFCLSID clsid, LPCWSTR wcsName, CFilter* pNewFilter)
	{
		assert(p);
		HRESULT hr = S_OK;
		try
		{
			CFilter	Filter(clsid);
			HRESULT hr = p->AddFilter(Filter, wcsName);
			if(SUCCEEDED(hr) && pNewFilter)
				*pNewFilter = Filter;
		}
		catch(const HRESULT& hrErr)
		{
			hr = hrErr;
		}
		return hr;
	}

	HRESULT CGraph::CreateSourceFilter(LPCWSTR wcsFileName, LPCWSTR wcsName, CFilter* pNewFilter)
	{
		assert(p);
		assert(wcsFileName && wcsName);
		if(!(wcsFileName && wcsName))
			return E_POINTER;

		CComPtr<IBaseFilter> pBaseFilter;
		HRESULT hr = p->AddSourceFilter(wcsFileName, wcsName, &pBaseFilter);
		if(SUCCEEDED(hr) && pNewFilter)
			*pNewFilter = pBaseFilter.p;
		return hr;
	}

	HRESULT CGraph::Connect(CPin& OutPin, CPin& InPin, bool bIntelligent)
	{
		assert(p);
		return bIntelligent ? p->Connect(OutPin, InPin) : p->ConnectDirect(OutPin, InPin, NULL);
	}

	//
	HRESULT CGraph::Run()
	{
		assert(m_pControl);
		HRESULT hr = m_pControl->Run();
		if(hr == S_FALSE)
		{
			WaitForOperationCompleted();
			hr = S_OK;
		}
		return hr;
	}

	HRESULT CGraph::Pause()
	{
		assert(m_pControl);
		HRESULT hr = m_pControl->Pause();
		if(hr == S_FALSE)
		{
			WaitForOperationCompleted();
			hr = S_OK;
		}
		return hr;
	}

	HRESULT	CGraph::Stop()
	{
		assert(m_pControl);
		return m_pControl->Stop();
	}

	CGraph::GraphRuntimeState CGraph::GetState() const
	{
		assert(m_pControl);
		OAFilterState fs = State_Stopped;
		HRESULT hr = m_pControl->GetState(0, &fs);
		return	hr == S_OK ? (GraphRuntimeState)fs : 
				(hr == VFW_S_STATE_INTERMEDIATE ? grsIntermediate :
				(hr == VFW_S_CANT_CUE ? grsPausedCantCue : grsError));
	}

	bool CGraph::WaitForOperationCompleted() const
	{
		assert(m_pControl);
		OAFilterState fs;
		while(m_pControl->GetState(0, &fs) == VFW_S_STATE_INTERMEDIATE)
			Sleep(50);
		return true;
	}

	void CGraph::RemoveNotConnectedFilters()
	{
		CFiltersList filters;
		EnumFilters(filters, AnyFilter);
		CFilter::CPinsList PinsAll, PinsNotConnected;
		for(CFiltersList::iterator i = filters.begin(); i != filters.end(); i++)
		{
			(*i).EnumPins(PinsAll, AnyPin);
			(*i).EnumPins(PinsNotConnected, IsNotConnected);

			if(PinsAll.size() == PinsNotConnected.size())
				p->RemoveFilter(*i);
		}
	}


	// 
	REFERENCE_TIME CGraph::GetPosition() const
	{
		assert(m_pSeeking);
		REFERENCE_TIME rt = 0;
		m_pSeeking->GetCurrentPosition(&rt);
		return rt;
	}

	HRESULT CGraph::SetPosition(const REFERENCE_TIME& rt)
	{
		assert(m_pSeeking);
		REFERENCE_TIME rt1 = rt;
		return m_pSeeking->SetPositions(&rt1, AM_SEEKING_AbsolutePositioning, NULL, AM_SEEKING_NoPositioning);
	}

	//
	bool	CGraph::WaitForCompletion(LONG lTimeout) const
	{
		LONG lEvent = 0;
		HRESULT hr = m_pEvent->WaitForCompletion(lTimeout, &lEvent);
		assert(hr != VFW_E_WRONG_STATE);
		return hr == S_OK;
	}


	//
	HRESULT CFilter::EnumPins(CFilter::CPinsList& refList, CFilter::PinsEnumFunc pPinsEnumFunc) const
	{
		assert(p);

		refList.clear();

		CComPtr<IEnumPins>		pEnum;
		HRESULT hr = const_cast<IBaseFilter*>(p)->EnumPins(&pEnum);
		if(FAILED(hr))
			return hr;

		IPin*	pPin = NULL;
		ULONG	cFetched	= 0;
		while(pEnum->Next(1, &pPin, &cFetched) == S_OK)
		{
			if(pPinsEnumFunc(pPin))
				refList.push_back(pPin);
			pPin->Release();
		}
		return refList.empty() ? S_FALSE : S_OK;
	}

	HRESULT CGraph::EnumFilters(CGraph::CFiltersList& refList,  CGraph::FilterEnumFunc pFltEnumFunc) const
	{
		assert(p);

		refList.clear();

		CComPtr<IEnumFilters>	pEnum;
		HRESULT hr = const_cast<IGraphBuilder*>(p)->EnumFilters(&pEnum);
		if(FAILED(hr))
			return hr;

		IBaseFilter*	pFilter = NULL;
		ULONG			cFetched	= 0;
		while(pEnum->Next(1, &pFilter, &cFetched) == S_OK)
		{
			if(pFltEnumFunc(pFilter))
				refList.push_back(pFilter);
			pFilter->Release();
		}
		return refList.empty() ? S_FALSE : S_OK;
	}

}
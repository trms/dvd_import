//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//	Copyright (C) 2003 AMMTools. All rights reserved.
//	http://www.ammtools.com mailto:support@ammtools.com

#include <streams.h>
#include <DVDMedia.h>
#include <mmreg.h>
#include "DirectShowUtils.h"
#include "DirectShow.h"

namespace AMMTDS
{
	bool IsOutVideo(IPin* pPin)
	{
		assert(pPin);
		if(!IsOutPin(pPin))
			return false;

		// Check mediatypes
		CPin Pin(pPin);
		CPin::CMediaTypeList list;
		Pin.GetMediaTypes(list);
		for(CPin::CMediaTypeList::iterator i = list.begin(); i != list.end(); i++)
		{
			const AM_MEDIA_TYPE& mt = *i;
			if((mt.formattype == FORMAT_MPEGVideo) ||
					(mt.formattype == FORMAT_MPEG2_VIDEO) || 
					(mt.formattype == FORMAT_MPEG2Video))
				return true;
		}
		return false;
	}

	bool IsOutAudio(IPin* pPin)
	{
		assert(pPin);

		if(!IsOutPin(pPin))
			return false;

		// Check mediatypes
		CPin Pin(pPin);
		CPin::CMediaTypeList list;
		Pin.GetMediaTypes(list);
		for(CPin::CMediaTypeList::iterator i = list.begin(); i != list.end(); i++)
		{
			const AM_MEDIA_TYPE& mt = *i;
			if((mt.formattype == FORMAT_WaveFormatEx)	||
					(mt.formattype == FORMAT_DolbyAC3)		||
					(mt.formattype == FORMAT_MPEG2Audio)		||
					(mt.formattype == FORMAT_DVD_LPCMAudio))
				return true;
		}

		return false;
	}

	XU::CTString	FormatStreamName(const AM_MEDIA_TYPE* pType)
	{
		if(!pType)
			return XU::CTString(_T("Unknown Stream"));

		static const GUID SUBTYPE_MP3 = {0x00000055, 0x0000, 0x0010, {0x80, 0x00, 0x00, 0xaa, 0x00, 0x38, 0x9b, 0x71}};
		XU::CTString str(pType->majortype == MEDIATYPE_Video ?
							_T("Unknown Video Stream") : 
							(pType->majortype == MEDIATYPE_Audio ?
							_T("Unknown Audio Stream") : 
							_T("Unknown Stream")));
		TCHAR tcsTmp[128];

		if(pType->subtype == MEDIASUBTYPE_MPEG2_VIDEO)
		{
			if(pType->formattype == FORMAT_MPEG2Video ||
				pType->formattype == FORMAT_VideoInfo2)
			{
				VIDEOINFOHEADER2* pVI = (VIDEOINFOHEADER2*)pType->pbFormat;
				_stprintf(tcsTmp, _T("MPEG-2 Video: %u x %u; %2g fps; %2g mbit/s"),
					pVI->rcSource.right - pVI->rcSource.left,
					pVI->rcSource.bottom - pVI->rcSource.top,
					(float)UNITS/pVI->AvgTimePerFrame,
					(float)pVI->dwBitRate/1000000);
				str = tcsTmp;
			}
			else if(pType->formattype == FORMAT_MPEGVideo ||
					pType->formattype == FORMAT_VideoInfo)
			{
				VIDEOINFOHEADER* pVI = (VIDEOINFOHEADER*)pType->pbFormat;
				_stprintf(tcsTmp, _T("MPEG-2 Video: %u x %u; %2g fps; %2g mbit/s"),
					pVI->rcSource.right - pVI->rcSource.left,
					pVI->rcSource.bottom - pVI->rcSource.top,
					(float)UNITS/pVI->AvgTimePerFrame,
					(float)pVI->dwBitRate/1000000);
				str = tcsTmp;
			}
			else
				str = _T("MPEG-2 Video: unknown format type");
		}
		else if(pType->subtype == MEDIASUBTYPE_MPEG1Payload ||
			pType->subtype == MEDIASUBTYPE_MPEG1Video)
		{
			if(pType->formattype == FORMAT_MPEGVideo || 
				pType->formattype == FORMAT_VideoInfo)
			{
				VIDEOINFOHEADER* pVI = (VIDEOINFOHEADER*)pType->pbFormat;
				_stprintf(tcsTmp, _T("MPEG-1 Video: %u x %u; %2g fps; %2g mbit/s"),
					pVI->bmiHeader.biWidth, pVI->bmiHeader.biHeight,
					(float)UNITS/pVI->AvgTimePerFrame,
					(float)pVI->dwBitRate/1000000);
				str = tcsTmp;
			}
			else
				str = _T("MPEG-1 Video: unknown format type");
		}
		else if(pType->subtype == MEDIASUBTYPE_DOLBY_AC3)
		{
			if(pType->formattype == FORMAT_WaveFormatEx)
			{
				WAVEFORMATEX* pWF = (WAVEFORMATEX*)pType->pbFormat;
				_stprintf(tcsTmp, _T("Dolby AC3 Audio: %u channels; %2g kHz; %g kbit/s"),
					pWF->nChannels,
					(float)pWF->nSamplesPerSec/1000,
					(float)pWF->nAvgBytesPerSec * 8/1000);
				str = tcsTmp;
			}
			else
				str = _T("Dolby AC3 Audio: unknown format type");
		}
		else if(pType->subtype == SUBTYPE_MP3 ||
			pType->subtype == MEDIASUBTYPE_MPEG1AudioPayload ||
			pType->subtype == MEDIASUBTYPE_MPEG2_AUDIO)
		{
			if(pType->formattype == FORMAT_WaveFormatEx)
			{
				MPEG1WAVEFORMAT* pMPF = (MPEG1WAVEFORMAT*)pType->pbFormat;
				WAVEFORMATEX* pWF = &pMPF->wfx;
				_stprintf(tcsTmp, _T("MPEG Audio: layer %u; %u channels; %2g kHz; %g kbit/s"),
					pType->subtype == SUBTYPE_MP3 ? 3 : ((pMPF->fwHeadLayer == 4) ? 3 : pMPF->fwHeadLayer),
					pWF->nChannels,
					(float)pWF->nSamplesPerSec/1000,
					(float)pWF->nAvgBytesPerSec * 8/1000);
				str = tcsTmp;
			}
			else
				str = _T("MPEG Audio: unknown format type");
		}
		else if(pType->subtype == MEDIASUBTYPE_DVD_LPCM_AUDIO)
		{
			if(pType->formattype == FORMAT_WaveFormatEx)
			{
				WAVEFORMATEX* pWF = (WAVEFORMATEX*)pType->pbFormat;
				_stprintf(tcsTmp, _T("DVD LPCM Audio: %u channels; %2g kHz; %g kbit/s"),
					pWF->nChannels,
					(float)pWF->nSamplesPerSec/1000,
					(float)pWF->nAvgBytesPerSec * 8/1000);
				str = tcsTmp;
			}
			else
				str = _T("DVD LPCM Audio: unknown format type");
		}

		return str;
	}

	XU::CTString RefTimeToStringHMS(REFERENCE_TIME rtTime)
	{
		const static REFERENCE_TIME rtHour = (REFERENCE_TIME)60*60*10000000;
		// Format to hrs:mins:secs:ms
		REFERENCE_TIME wHour = rtTime/rtHour;
		rtTime -= wHour * rtHour;

		REFERENCE_TIME wMinute = rtTime/(60*10000000);
		rtTime -= wMinute * (60*10000000);

		REFERENCE_TIME wSecond = rtTime/10000000;
		rtTime -= wSecond * 10000000;
		rtTime = rtTime/100000;

		TCHAR	tcsTmp[32];
		_stprintf(tcsTmp, _T("%2u h %2u m %2u s %2u ms"),
				(ULONG)wHour, (ULONG)wMinute, (ULONG)wSecond, (ULONG)rtTime);
		return XU::CTString(tcsTmp);
	}
}
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//	Copyright (C) 2003 AMMTools. All rights reserved.
//	http://www.ammtools.com mailto:support@ammtools.com


#pragma once

#include <assert.h>
#include <atlbase.h>
#include "..\XUtils\XUString.h"

namespace AMMTDS
{
	inline bool AnyFilter(IBaseFilter* pFilter)
	{
		return true;
	}

	inline bool AnyPin(IPin* pPin)
	{
		return true;
	}

	static bool IsInPin(IPin* pPin)
	{
		assert(pPin);
		PIN_INFO Info;
		pPin->QueryPinInfo(&Info);
		if(Info.pFilter)
			Info.pFilter->Release();
		return Info.dir == PINDIR_INPUT;
	}

	static bool IsOutPin(IPin* pPin)
	{
		assert(pPin);
		PIN_INFO Info;
		pPin->QueryPinInfo(&Info);
		if(Info.pFilter)
			Info.pFilter->Release();
		return Info.dir == PINDIR_OUTPUT;
	}

	inline bool IsConnected(IPin* pPin)
	{
		assert(pPin);
		CComPtr<IPin> pOther;
		return SUCCEEDED(pPin->ConnectedTo(&pOther)) && pOther;
	}

	inline bool IsNotConnected(IPin* pPin)
	{
		return !IsConnected(pPin);
	}

	inline bool IsInNotConnected(IPin* pPin)
	{
		assert(pPin);
		return IsInPin(pPin) && !IsConnected(pPin);
	}

	inline bool IsInConnected(IPin* pPin)
	{
		assert(pPin);
		return IsInPin(pPin) && IsConnected(pPin);
	}

	inline bool IsOutNotConnected(IPin* pPin)
	{
		assert(pPin);
		return IsOutPin(pPin) && !IsConnected(pPin);
	}

	inline bool IsOutConnected(IPin* pPin)
	{
		assert(pPin);
		return IsOutPin(pPin) && IsConnected(pPin);
	}

	bool IsOutVideo(IPin* pPin);
	bool IsOutAudio(IPin* pPin);

	XU::CTString	FormatStreamName(const AM_MEDIA_TYPE* pType);
	XU::CTString	RefTimeToStringHMS(REFERENCE_TIME rtTime);
}
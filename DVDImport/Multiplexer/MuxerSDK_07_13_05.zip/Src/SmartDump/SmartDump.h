//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//	Copyright (C) 2003 AMMTools. All rights reserved.
//	http://www.ammtools.com mailto:support@ammtools.com


#pragma once

#include "OutputFile.h"
#include "MemCache.h"
#include "..\XUtils\XUFileNameUtils.h"

class CDump
{
public:
	CDump() : m_Cache(&m_File), m_nSegment(0)
	{}

	// File operations
	HRESULT	SetFileName(LPCWSTR wcsFileName)
	{
		return m_File.SetFileName(m_FileName = wcsFileName);
	}
	
	LPCWSTR	GetFileName() const
	{
		return m_FileName;
	}

	LPCWSTR	GetCurFileName() const
	{
		return m_File.GetFileName();
	}

	bool	IsReady() const
	{
		return m_File.IsReady();
	}

    // Open and write to the file
    HRESULT OpenFile()
	{
		return m_File.Open();
	}

    HRESULT CloseFile()
	{
		m_nSegment = 0;
		m_Cache.Flush();
		m_Cache.Stop();
		return m_File.Close();
	}

    // Write data streams to a file
    HRESULT Write(const BYTE* pbData, size_t lData)
	{
		return m_Cache.WriteData(pbData, lData);
	}


	///////////////////////////////////////////////////////
	// Segmentation
	HRESULT			OnNewSegment()
	{
		HRESULT hr = S_OK;
		if(m_nSegment)
		{
			m_Cache.Flush();
			m_File.Close();
			
			{// Generate and set next file name
				using namespace XU;
				CTString sFullPath(m_FileName),
					sPath(GetFilePath(sFullPath)),
					sName(GetOnlyFileName(sFullPath)),
					sExt(GetFileExtention(sFullPath));
				TCHAR tcsTmp[256];
				_stprintf(tcsTmp, _T("%s%d.%s"), (LPCTSTR)sName, m_nSegment, (LPCTSTR)sExt);
				sFullPath = MakeFullPath(sPath, tcsTmp);
				m_File.SetFileName(CWString(sFullPath));
			}
			hr = m_File.Open();
		}

		++ m_nSegment;

		return hr;
	}

private:
	XU::CWString	m_FileName;
	COutputFile		m_File;
	CMemCache		m_Cache;

	UINT			m_nSegment;
};


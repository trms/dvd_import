//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//	Copyright (C) 2003 AMMTools. All rights reserved.
//	http://www.ammtools.com mailto:support@ammtools.com


#pragma once

#include "..\XUtils\XUCommandQueue.h"
#include "OutputFile.h"

class CMemCache  
{
	// 
	class CCommand : public XU::CXCommand<HRESULT>
	{
	public:
		CCommand(COutputFile& File, const BYTE* pBuff, size_t nSize, HANDLE* pHndl = 0) : 
						m_File(File), m_pBuff(pBuff), m_nSize(nSize), m_pHndl(pHndl)

		{
			m_Result = S_FALSE;
		}

		void		Execute()
		{
			m_Result	= m_File.Write(m_pBuff, m_nSize);
			m_bExecuted	= true;
		}

		const BYTE*	GetPtr() const
		{
			return m_pBuff;
		}

		HANDLE*	GetNotifyEvent() const
		{
			return m_pHndl;
		}

	private:
		COutputFile&			m_File;
		const BYTE* const		m_pBuff;
		const size_t			m_nSize;
		mutable HANDLE*			m_pHndl;
	};

	typedef	XU::CXCommandQueueCallback<CCommand, CMemCache> CQueue;

	//
	class CCacheThread
	{
	public:
		CCacheThread(CQueue& queue) :	
		  m_Queue(queue), m_hThread(NULL),	m_nPriority(THREAD_PRIORITY_IDLE)
		{}

		~CCacheThread();

		bool		Start();
		void		Stop();
		bool		IsStarted()
		{
			return m_hThread != NULL;
		}

		bool		BoostUp();
		bool		BoostDown();

	private:
		HANDLE		m_hThread;
		int			m_nPriority;
		CQueue&		m_Queue;
	};

	//
	class CBuffer
	{
	public:
		CBuffer(size_t nBuffers, size_t nBuffSize);
		~CBuffer();

		BYTE*		GetNextFreeBuffer();
		void		FreeBuffer(const BYTE* pPtr);
		
		size_t		GetFreeBuffersCount() const
		{
			return m_nFreeBuffers;
		}
		

		const size_t	m_nBufferSize;
		const size_t	m_nBuffers;
		
	private:
		BYTE*			m_pBuffer;
		bool*			m_pbBuffMap; // true = free, false = busy
		size_t			m_nFreeBuffers;
		XU::CXEvent		m_Free;
		XU::CXCritSec	m_CritSec;
	};
	
public:
	CMemCache(COutputFile* pFile, size_t nBuffers = 10, size_t nBuffSize = 64 * 1024);
	virtual ~CMemCache();

	// 
	
	// 
	bool	WriteData(const BYTE* pbData, size_t nDataSize);
	void	Flush();
	void	Stop();
	
	void	ExecCallback(const CCommand& command);

private:
	// Current buffer stuff
	const BYTE*	GetNextFreeBuffer();
	bool		WriteToCurrentBuffer(const BYTE* pbSrcData, size_t nSrcDataSize);

	bool		IsCurrentBufferFull() const
	{
		return m_nCurBuffFillnes == m_Buffer.m_nBufferSize;
	}

	void		SetNewCurrentBuffer(BYTE* pbData)
	{
		assert(IsCurrentBufferFull());
		m_pCurBuffer		= pbData;
		m_nCurBuffFillnes	= 0;
	}

	void		ResetCurrentBuffer()
	{
		m_pCurBuffer		= NULL;
		m_nCurBuffFillnes	= 0;
	}

	///////////////////////////////////////////////////////
	//	Controlling disk write thread priority
	void ControlThreadPriority()
	{
		// Check fullnes of cache
		if(m_Buffer.GetFreeBuffersCount() > m_Buffer.m_nBuffers - (m_Buffer.m_nBuffers >> 2))
			m_Thread.BoostDown();
		if(m_Buffer.GetFreeBuffersCount() < (m_Buffer.m_nBuffers >> 1))
			m_Thread.BoostUp();
	}
	
private:
	CBuffer			m_Buffer;

	// Buffer we are working with right now
	BYTE*			m_pCurBuffer;
	size_t			m_nCurBuffFillnes;

	// Command queue
	CQueue			m_Queue;
	CCacheThread	m_Thread;

	// Associated file
	COutputFile*	m_pFile;
};

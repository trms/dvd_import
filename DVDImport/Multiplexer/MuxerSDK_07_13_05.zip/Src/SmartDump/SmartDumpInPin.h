//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//	Copyright (C) 2003 AMMTools. All rights reserved.
//	http://www.ammtools.com mailto:support@ammtools.com

#pragma once

#include "SmartDumpFilter.h"

//  Pin object
class CDumpInputPin : public CRenderedInputPin
{
public:
    CDumpInputPin(LPUNKNOWN pUnk, CBaseFilter* pFilter,
                  CCritSec* pLock, CCritSec* pReceiveLock, HRESULT* phr);

    STDMETHODIMP	Receive(IMediaSample* pSample)
	{	
		if(m_bEOS)
			return E_UNEXPECTED;
	    return Filter()->Receive(pSample);
	}

    STDMETHODIMP	EndOfStream(void);
    STDMETHODIMP	ReceiveCanBlock();

    STDMETHODIMP	BeginFlush()
	{
		return m_bFlushing ? S_OK : CRenderedInputPin::BeginFlush();
	}

    STDMETHODIMP	EndFlush()
	{
		return m_bFlushing ? CRenderedInputPin::EndFlush() : S_OK;
	}

    // Check if the pin can support this specific proposed type and format
    HRESULT			CheckMediaType(const CMediaType*);

    // Break connection
    HRESULT			BreakConnect();

    // Track NewSegment
    STDMETHODIMP	NewSegment(REFERENCE_TIME tStart, REFERENCE_TIME tStop, double dRate);
	
private:
	CDumpFilter*	Filter()
	{
		return (CDumpFilter*)(m_pFilter);
	}

	CCritSec* const m_pReceiveLock;
	bool			m_bEOS;
};

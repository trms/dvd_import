//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//	Copyright (C) 2003 AMMTools. All rights reserved.
//	http://www.ammtools.com mailto:support@ammtools.com


#include <windows.h>
#include <commdlg.h>
#include <streams.h>
#include <initguid.h>
#include "SmartFileDumpFltrGuids.h"
#include "SmartDump.h"
#include "SmartDumpFilter.h"
#include "SmartDumpInPin.h"

CDumpFilter::CDumpFilter(LPUNKNOWN pUnk, HRESULT* phr) :
			CBaseFilter(NAME("CDumpFilter"), pUnk, &m_Lock, CLSID_AMMT_SMART_FILE_DUMP),
			m_pPin(new CDumpInputPin(GetOwner(), this,
										   &m_Lock, &m_ReceiveLock, phr)),
			m_pDump(new CDump),
			m_pPosition(NULL),
			m_rtSegmentStart(0),
			m_rtCurTime(0),
			m_ulWritten(0)
{
    if(!m_pPin) 
	{
        *phr = E_OUTOFMEMORY;
        return;
    }
}

CDumpFilter::~CDumpFilter()
{
    delete m_pDump;
    delete m_pPin;
    delete m_pPosition;
}

/////////////////////////////////////////////////////////////////////////
//
STDMETHODIMP CDumpFilter::NonDelegatingQueryInterface(REFIID riid, void ** ppv)
{
    CheckPointer(ppv,E_POINTER);
    CAutoLock lock(&m_Lock);

    // Do we have this interface

	if(riid == IID_IFileSinkFilter)
	    return GetInterface((IFileSinkFilter*)this, ppv);
	if(riid == IID_IDumpProgress)
	    return GetInterface((IDumpProgress*)this, ppv);
	if(riid == IID_IBaseFilter ||
			riid == IID_IMediaFilter ||
			riid == IID_IPersist)
	    return GetInterface((IBaseFilter*)this, ppv);
    if(riid == IID_IMediaPosition || riid == IID_IMediaSeeking)
	{
        if(m_pPosition == NULL) 
		{
            HRESULT hr = S_OK;
            m_pPosition = new CRendererPosPassThru(NAME("Dump Pass Through"),
                                           (IUnknown *) GetOwner(),
                                           (HRESULT *) &hr, m_pPin);
            if(m_pPosition == NULL)
                return E_OUTOFMEMORY;

            if(FAILED(hr))
			{
                delete m_pPosition;
                m_pPosition = NULL;
                return hr;
            }
        }

        return m_pPosition->NonDelegatingQueryInterface(riid, ppv);
    } 

    return CUnknown::NonDelegatingQueryInterface(riid, ppv);
} 

STDMETHODIMP CDumpFilter::GetProgress(REFERENCE_TIME* prtTime, ULONGLONG* pullDataWritten)
{
	if(!prtTime && !pullDataWritten)
		return E_POINTER;

	if(prtTime)
		*prtTime = m_rtCurTime;

	if(pullDataWritten)
		*pullDataWritten = m_ulWritten;

	return  S_OK;
}

///////////////////////////////////////////////////////////////////////
// IFileSinkFilter
STDMETHODIMP CDumpFilter::SetFileName(LPCOLESTR pszFileName, const AM_MEDIA_TYPE* pmt)
{
    // Is this a valid filename supplied
    CheckPointer(pszFileName, E_POINTER);
    if(wcslen(pszFileName) > MAX_PATH)
        return ERROR_FILENAME_EXCED_RANGE;

	HRESULT hr = m_pDump->SetFileName(pszFileName);
/*
	if(SUCCEEDED(hr))
	{
		// Create the file then close it
		hr = m_pDump->OpenFile();
		m_pDump->CloseFile();
	}
*/
    return hr;
}

STDMETHODIMP CDumpFilter::GetCurFile(LPOLESTR* ppszFileName, AM_MEDIA_TYPE* pmt)
{
    CheckPointer(ppszFileName, E_POINTER);
    *ppszFileName = NULL;

    if(m_pDump->GetCurFileName()) 
	{
        *ppszFileName = (LPOLESTR)
        QzTaskMemAlloc(sizeof(WCHAR) * (1+lstrlenW(m_pDump->GetCurFileName())));
        if(*ppszFileName) 
            lstrcpyW(*ppszFileName, m_pDump->GetCurFileName());
    }

    if(pmt) 
	{
        ZeroMemory(pmt, sizeof(*pmt));
        pmt->majortype = MEDIATYPE_NULL;
        pmt->subtype = MEDIASUBTYPE_NULL;
    }
	
    return S_OK;

}

/////////////////////////////////////////////////////////////////////////////
// CBaseFilter methods
CBasePin* CDumpFilter::GetPin(int n)
{
	return !n ? m_pPin : NULL;
}

int CDumpFilter::GetPinCount()
{
    return 1;
}

STDMETHODIMP CDumpFilter::Stop()
{
    CAutoLock cObjectLock(m_pLock);
    m_pDump->CloseFile();
	HRESULT hr = CBaseFilter::Stop();
	m_rtCurTime = 0;
	m_ulWritten = 0;

	return hr == VFW_E_NO_ALLOCATOR ? S_OK : hr;
}

STDMETHODIMP CDumpFilter::Pause()
{
    CAutoLock cObjectLock(m_pLock);
    m_pDump->OpenFile();
    return CBaseFilter::Pause();
}

STDMETHODIMP CDumpFilter::Run(REFERENCE_TIME tStart)
{
    CAutoLock cObjectLock(m_pLock);
    m_pDump->OpenFile();
    return CBaseFilter::Run(tStart);
}

HRESULT CDumpFilter::Receive(IMediaSample* pSample)
{
    CAutoLock lock(&m_ReceiveLock);
	m_pPosition->RegisterMediaTime(pSample);

    // Has the filter been stopped yet
    if(!m_pDump->IsReady())
        return S_OK;

	REFERENCE_TIME tStart = 0, tStop = 0;
	if(pSample->GetTime(&tStart, &tStop) == S_OK)
		m_rtCurTime = tStart - m_rtSegmentStart;

    // Copy the data to the file
    PBYTE pbData = NULL;
    HRESULT hr = pSample->GetPointer(&pbData);
    if(FAILED(hr))
        return hr;

	m_ulWritten += pSample->GetActualDataLength();

	return m_pDump->Write(pbData, pSample->GetActualDataLength()) ? S_OK : E_FAIL;
}

HRESULT CDumpFilter::NewSegment(REFERENCE_TIME tStart, REFERENCE_TIME tStop, double dRate)
{
    m_rtSegmentStart = tStart;
	m_pDump->OnNewSegment();
	return S_OK;
}

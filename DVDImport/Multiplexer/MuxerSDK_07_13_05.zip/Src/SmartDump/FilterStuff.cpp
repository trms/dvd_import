//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//	Copyright (C) 2003 AMMTools. All rights reserved.
//	http://www.ammtools.com mailto:support@ammtools.com


#include <windows.h>
#include <streams.h>
#include "SmartDumpFilter.h"
#include "SmartFileDumpFltrGuids.h"

extern "C" BOOL WINAPI DllEntryPoint(HINSTANCE, ULONG, LPVOID);
BOOL APIENTRY DllMain(HANDLE hModule, 
                      DWORD  dwReason, 
                      LPVOID lpReserved)
{
	return DllEntryPoint((HINSTANCE)(hModule), dwReason, lpReserved);
}

// Setup data
const AMOVIESETUP_MEDIATYPE sudPinTypes =
{
    &MEDIATYPE_NULL,            // Major type
    &MEDIASUBTYPE_NULL          // Minor type
};

const AMOVIESETUP_PIN sudPins =
{
    L"Input",                   // Pin string name
    FALSE,                      // Is it rendered
    FALSE,                      // Is it an output
    FALSE,                      // Allowed none
    FALSE,                      // Likewise many
    &CLSID_NULL,                // Connects to filter
    L"Output",                  // Connects to pin
    1,                          // Number of types
    &sudPinTypes                // Pin information
};

const AMOVIESETUP_FILTER sudDump =
{
    &CLSID_AMMT_SMART_FILE_DUMP,           // Filter CLSID
    L"AMMT Smart Dump",         // String name
    MERIT_DO_NOT_USE,           // Filter merit
    1,                          // Number pins
    &sudPins                    // Pin details
};


//
//  Object creation stuff
CFactoryTemplate g_Templates[] = 
{
    L"AMMT SmartDump", &CLSID_AMMT_SMART_FILE_DUMP, CDumpFilter::CreateInstance, NULL, &sudDump
};

int g_cTemplates = 1;

/////////////////////////////////////////////////////////////////////////////////////
//
/*
CUnknown* WINAPI CDumpFilter::CreateInstance(LPUNKNOWN punk, HRESULT* phr)
{
    if(CDumpFilter* pNewObject = new CDumpFilter(punk, phr))
        return pNewObject;

	*phr = E_OUTOFMEMORY;
    return NULL;
} // CreateInstance
*/
///////////////////////////////////////////////////////////
// Handle the registration of this filter
STDAPI DllRegisterServer()
{
    return AMovieDllRegisterServer2(TRUE);

}

STDAPI DllUnregisterServer()
{
    return AMovieDllRegisterServer2(FALSE);

}

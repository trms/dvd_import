//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//	Copyright (C) 2003 AMMTools. All rights reserved.
//	http://www.ammtools.com mailto:support@ammtools.com


#pragma once

#include <windows.h>

class COutputFile  
{
public:
	COutputFile();
	virtual ~COutputFile();

	HRESULT	SetFileName(LPCWSTR wcsFileName);
	LPCWSTR	GetFileName() const
	{
		return m_wcsFileName;
	}

	bool	IsReady() const
	{
		return m_bReady;//m_hFile != INVALID_HANDLE_VALUE;
	}

     HRESULT Create();
   // Open and write to the file
    HRESULT Open();
    HRESULT Close();

    // Write data streams to a file
    HRESULT Write(const BYTE* pbData, size_t lData);

private:
    HANDLE		m_hFile;                 // Handle to file for dumping
    LPWSTR		m_wcsFileName;           // The filename where we dump to
	bool		m_bReady;
};

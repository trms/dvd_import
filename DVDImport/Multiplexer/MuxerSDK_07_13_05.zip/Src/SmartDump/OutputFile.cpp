//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//	Copyright (C) 2003 AMMTools. All rights reserved.
//	http://www.ammtools.com mailto:support@ammtools.com


#include "OutputFile.h"
#include <assert.h>
#include "..\XUtils\XUExc.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

COutputFile::COutputFile() :
		m_hFile(INVALID_HANDLE_VALUE),
		m_wcsFileName(NULL),
		m_bReady(false)
{}

COutputFile::~COutputFile()
{
	Close();
}

HRESULT	 COutputFile::SetFileName(LPCWSTR wcsFileName)
{
    Close();
	delete[] m_wcsFileName;

	m_wcsFileName = new WCHAR[MAX_PATH];
	wcscpy(m_wcsFileName, wcsFileName);
	
	return Create();
}

// Opens the file ready for dumping
HRESULT COutputFile::Open()
{
    // Is the file already opened
    if(m_hFile != INVALID_HANDLE_VALUE)
        return S_OK;

    // Has a filename been set yet
    if(!m_wcsFileName)
        return ERROR_INVALID_NAME;

    // Try to open the file
    m_hFile = CreateFileW(m_wcsFileName ,   // The filename
							 GENERIC_WRITE,       // File access
							 (DWORD) 0,             // Share access
							 NULL,                  // Security
							 OPEN_ALWAYS,         // Open flags
							 0,//FILE_FLAG_NO_BUFFERING,             // More flags
							 NULL);                 // Template

    if(m_hFile == INVALID_HANDLE_VALUE) 
        return HRESULT_FROM_WIN32(GetLastError());

	SetFilePointer(m_hFile, 0, 0, FILE_END);

    return S_OK;
} 

// Opens the file ready for dumping
HRESULT COutputFile::Create()
{
	m_bReady = false;
    // Is the file already opened
    if(m_hFile != INVALID_HANDLE_VALUE)
        return S_OK;

    // Has a filename been set yet
    if(!m_wcsFileName)
        return ERROR_INVALID_NAME;

    // Try to open the file
    m_hFile = CreateFileW(m_wcsFileName ,   // The filename
							 GENERIC_WRITE,       // File access
							 (DWORD) 0,             // Share access
							 NULL,                  // Security
							 CREATE_ALWAYS,         // Open flags
							 0,//FILE_FLAG_NO_BUFFERING,             // More flags
							 NULL);                 // Template

    if(m_hFile == INVALID_HANDLE_VALUE) 
        return HRESULT_FROM_WIN32(GetLastError());

	m_bReady = true;

//	Close();

    return S_OK;
} 

// Closes any dump file we have opened
HRESULT COutputFile::Close()
{
    if(m_hFile == INVALID_HANDLE_VALUE) 
        return S_OK;

    CloseHandle(m_hFile);
    m_hFile = INVALID_HANDLE_VALUE;
    return S_OK;
} 


// Write stuff to the file
HRESULT COutputFile::Write(const BYTE* pbData, size_t lData)
{
    DWORD dwWritten = 0;
//	assert(m_hFile == INVALID_HANDLE_VALUE) ;

    HRESULT hr = Open();
	if(SUCCEEDED(hr))
	{
		hr = WriteFile(m_hFile, pbData, lData, &dwWritten, NULL) ?
						S_OK :
						HRESULT_FROM_WIN32(GetLastError());
//		Close();
	}
	return hr;
}



//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//	Copyright (C) 2003 AMMTools. All rights reserved.
//	http://www.ammtools.com mailto:support@ammtools.com


#include "MemCache.h"
#include "..\XUtils\XUTrace.h"
#include "..\XUtils\XUMemUtils.h"

using namespace XU;
//////////////////////////////////////////////////////////////////////
// CMemCache::CCacheThread
CMemCache::CCacheThread::~CCacheThread()
{
	if(m_hThread)
		CloseHandle(m_hThread);
}

bool CMemCache::CCacheThread::Start()
{
	if(IsStarted())
		return true;

	m_nPriority = THREAD_PRIORITY_NORMAL;
	return CXThreadExecute<CQueue>::Execute(m_Queue,
												CQueue::ProcessQueue,
												&m_hThread, m_nPriority);

}

void CMemCache::CCacheThread::Stop()
{
	m_Queue.Stop();
	if(m_hThread)
	{
		CloseHandle(m_hThread);
		m_hThread = NULL;
	}
}

bool CMemCache::CCacheThread::BoostUp()
{
	assert(m_hThread);
	if(m_nPriority < THREAD_PRIORITY_HIGHEST)
	{
		XU_TRACE(_T("\nBoostUp m_nPriority = %d\n"), m_nPriority + 1);
		return SetThreadPriority(m_hThread, ++ m_nPriority);
	}
	return false;
}

bool CMemCache::CCacheThread::BoostDown()
{
	assert(m_hThread);
	if(m_nPriority > THREAD_PRIORITY_LOWEST)
	{
		XU_TRACE(_T("\nBoostDown m_nPriority = %d\n"), m_nPriority - 1);
		return SetThreadPriority(m_hThread, -- m_nPriority);
	}
	return false;
}

//////////////////////////////////////////////////////////////////////
// CMemCache::CBuffer
CMemCache::CBuffer::CBuffer(size_t nBuffers, size_t nBuffSize) :
				m_nBufferSize(nBuffSize),
				m_nBuffers(nBuffers),
				m_pBuffer((BYTE*)VirtualAlloc(NULL, m_nBuffers * m_nBufferSize,
												MEM_COMMIT, PAGE_READWRITE)),
				m_pbBuffMap(new bool[m_nBuffers]),
				m_nFreeBuffers(m_nBuffers)
{
	if(!m_pBuffer)
		throw HRESULT_FROM_WIN32(GetLastError());
	
	std::fill(m_pbBuffMap,
			m_pbBuffMap + m_nBuffers, true);
}

CMemCache::CBuffer::~CBuffer()
{
	if(m_pBuffer)
		VirtualFree(m_pBuffer, m_nBuffers * m_nBufferSize, MEM_DECOMMIT);
	
	delete [] m_pbBuffMap;
}

BYTE* CMemCache::CBuffer::GetNextFreeBuffer()
{
	if(!m_nFreeBuffers)// Wait for free buffers available
		m_Free.Wait();

	CXAutoLock<CXCritSec>	l(m_CritSec);
	
	int n = 0;
	assert(m_nFreeBuffers);
	while(n < m_nBuffers)
	{
		if(m_pbBuffMap[n])
		{
			
			m_pbBuffMap[n] = false;

			-- m_nFreeBuffers;

			if(!m_nFreeBuffers)
				m_Free.Reset();

			return &m_pBuffer[n * m_nBufferSize];
		}
		++ n;
	}

	assert(false); 
	return NULL;
}

void CMemCache::CBuffer::FreeBuffer(const BYTE* pPtr)
{
	int n = (pPtr - m_pBuffer) / m_nBufferSize;
	if(0 <= n && n < m_nBuffers)
	{
		CXAutoLock<CXCritSec>	l(m_CritSec);

		assert(&m_pBuffer[n * m_nBufferSize] == pPtr);
		assert(!m_pbBuffMap[n]);
		m_pbBuffMap[n] = true;

		if(!m_nFreeBuffers)
			m_Free.Set();

		++ m_nFreeBuffers;
		assert(m_nFreeBuffers <= m_nBuffers);
		return;
	}
	assert(false);
}

//////////////////////////////////////////////////////////////////////
// CMemCache
CMemCache::CMemCache(COutputFile* pFile, size_t nBuffers, size_t nBuffSize) :
				m_Buffer(nBuffers, nBuffSize),
				m_pCurBuffer(NULL),
				m_nCurBuffFillnes(0),
				m_Queue(*this, CMemCache::ExecCallback),
				m_Thread(m_Queue),
				m_pFile(pFile)
{
}

CMemCache::~CMemCache()
{
	m_Queue.Purge();
}

bool CMemCache::WriteData(const BYTE* pbData, size_t nDataSize)
{
	assert(m_pFile);

	if(!m_Thread.IsStarted())
		m_Thread.Start();

	///////////////////////////////////////////////////
	// Handle data
	// Split buffer if it's too large
	const BYTE* pbNext = pbData;
	size_t		nNext = min(nDataSize, m_Buffer.m_nBufferSize - m_nCurBuffFillnes);
	while(nNext)
	{
//		ControlThreadPriority();

		//
		if(!m_pCurBuffer) // Get next free buffer
			m_pCurBuffer = m_Buffer.GetNextFreeBuffer();

		if(WriteToCurrentBuffer(pbNext, nNext)) // If current buffer is ready to dump
		{	// Create new command and put it into the queue
			CCommand* pCommand = new CCommand(*m_pFile, m_pCurBuffer, m_nCurBuffFillnes);
			ResetCurrentBuffer();
			m_Queue.AddCommand(*pCommand);
		}
		
		pbNext		+= nNext;
		nDataSize	-= nNext;
		nNext = min(nDataSize, m_Buffer.m_nBufferSize - m_nCurBuffFillnes);
	}

	return true;
}


bool CMemCache::WriteToCurrentBuffer(const BYTE* pbSrcData, size_t nSrcDataSize)
{
	assert(m_nCurBuffFillnes + nSrcDataSize <= m_Buffer.m_nBufferSize);
//	memcpy(m_pCurBuffer + m_nCurBuffFillnes, pbSrcData, nSrcDataSize);
	memcpy_mmx(m_pCurBuffer + m_nCurBuffFillnes, pbSrcData, nSrcDataSize);
	m_nCurBuffFillnes += nSrcDataSize;

	return IsCurrentBufferFull();
}


void CMemCache::Flush()
{
	if(m_pFile && m_pCurBuffer)
	{
		HANDLE h = CreateEvent(NULL, false, false, NULL);
		CCommand* pCommand = new CCommand(*m_pFile, m_pCurBuffer, m_nCurBuffFillnes, &h);
		ResetCurrentBuffer();
		m_Queue.AddCommand(*pCommand);
		WaitForSingleObject(h, INFINITE);
		CloseHandle(h);
	}
}

void CMemCache::Stop()
{
	m_Thread.Stop();
}

void CMemCache::ExecCallback(const CCommand& command)
{
//	assert(SUCCEEDED(command.GetResult()));
	m_Buffer.FreeBuffer(command.GetPtr());
	if(command.GetNotifyEvent())
		SetEvent(*command.GetNotifyEvent());

	delete &command;
}

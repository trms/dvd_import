//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//	Copyright (C) 2003 AMMTools. All rights reserved.
//	http://www.ammtools.com mailto:support@ammtools.com


// { 36a5f798-fe4c-11ce-a8ed-00aa002feab5 }
DEFINE_GUID(CLSID_SmartDump,
0x36a5f798, 0xfe4c, 0x11ce, 0xa8, 0xed, 0x00, 0xaa, 0x00, 0x2f, 0xea, 0xb5);


//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//	Copyright (C) 2003 AMMTools. All rights reserved.
//	http://www.ammtools.com mailto:support@ammtools.com


#include <windows.h>
#include <commdlg.h>
#include <streams.h>
#include "SmartDumpInPin.h"
#include "SmartDump.h"

//  Definition of CDumpInputPin
CDumpInputPin::CDumpInputPin(LPUNKNOWN pUnk, CBaseFilter* pFilter,
                             CCritSec* pLock, CCritSec* pReceiveLock, HRESULT* phr) :
					CRenderedInputPin(NAME("CDumpInputPin"),
								  pFilter,                   // Filter
								  pLock,                     // Locking
								  phr,                       // Return code
								  L"Input"),                 // Pin name
								  m_pReceiveLock(pReceiveLock),
								  m_bEOS(false)
{
}


// Check if the pin can support this specific proposed type and format
HRESULT CDumpInputPin::CheckMediaType(const CMediaType *)
{
    return S_OK;
}

// Break a connection
HRESULT CDumpInputPin::BreakConnect()
{
    if(Filter()->m_pPosition)
        Filter()->m_pPosition->ForceRefresh();
	m_bEOS = false;
    return CRenderedInputPin::BreakConnect();
}

// We don't hold up source threads on Receive
STDMETHODIMP CDumpInputPin::ReceiveCanBlock()
{
    return S_FALSE;
}

// EndOfStream
STDMETHODIMP CDumpInputPin::EndOfStream(void)
{
	m_bEOS = true;
    CAutoLock lock(m_pReceiveLock);
    return CRenderedInputPin::EndOfStream();
} 


// Called when we are seeked
STDMETHODIMP CDumpInputPin::NewSegment(REFERENCE_TIME tStart, REFERENCE_TIME tStop, double dRate)
{
	Filter()->NewSegment(tStart, tStop, dRate);
    return S_OK;
}

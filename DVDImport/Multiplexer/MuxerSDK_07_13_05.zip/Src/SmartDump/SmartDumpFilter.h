//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//	Copyright (C) 2003 AMMTools. All rights reserved.
//	http://www.ammtools.com mailto:support@ammtools.com


#pragma once

#include "SmartFileDumpFltrIfaces.h"

class CDumpInputPin;
class CDump;

// Main filter object
class CDumpFilter : public CBaseFilter, public IFileSinkFilter, public IDumpProgress
{
	friend class CDumpInputPin;
public:
	DECLARE_IUNKNOWN
	static CUnknown * CreateInstance(LPUNKNOWN punk, HRESULT *phr)
	{
		if(CDumpFilter* pNewObject = new CDumpFilter(punk, phr))
			return pNewObject;

		*phr = E_OUTOFMEMORY;
		return NULL;
	}

    // Constructor
	CDumpFilter(LPUNKNOWN pUnk, HRESULT* phr);
	~CDumpFilter();
	
	//    IDumpProgress : public IUnknown
    STDMETHODIMP	GetProgress(REFERENCE_TIME* prtTime, ULONGLONG* pullDataWritten);        

    // Overriden to say what interfaces we support where
    STDMETHODIMP	NonDelegatingQueryInterface(REFIID riid, void** ppv);

    // Pin enumeration
    CBasePin*		GetPin(int n);
    int				GetPinCount();

    // Open and close the file as necessary
    STDMETHODIMP	Run(REFERENCE_TIME tStart);
    STDMETHODIMP	Pause();
    STDMETHODIMP	Stop();

    // Implements the IFileSinkFilter interface
    STDMETHODIMP	SetFileName(LPCOLESTR pszFileName,const AM_MEDIA_TYPE* pmt);
    STDMETHODIMP	GetCurFile(LPOLESTR* ppszFileName, AM_MEDIA_TYPE* pmt);

	HRESULT			Receive(IMediaSample* pSample);
	HRESULT			NewSegment(REFERENCE_TIME tStart, REFERENCE_TIME tStop, double dRate);

private:
    CCritSec				m_Lock;			// Main renderer critical section
    CCritSec				m_ReceiveLock;	// Sublock for received samples

    CDumpInputPin*			m_pPin;			// A simple rendered input pin
    CRendererPosPassThru*	m_pPosition;	// Renderer position controls
	
    CDump*					m_pDump;

	REFERENCE_TIME			m_rtSegmentStart;

	// Progress
	REFERENCE_TIME			m_rtCurTime;
	ULONGLONG				m_ulWritten;

};

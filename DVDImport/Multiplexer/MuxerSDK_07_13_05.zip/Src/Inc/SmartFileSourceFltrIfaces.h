#ifndef __AMMT_SFSF_FilterInterfaces_h__
#define __AMMT_SFSF_FilterInterfaces_h__

#ifdef __cplusplus
extern "C"{
#endif 

#ifndef __IGeneralSettings_INTERFACE_DEFINED__
#define __IGeneralSettings_INTERFACE_DEFINED__

// {69EF135C-1936-4bd3-B011-445724558D8C}
DEFINE_GUID(IID_IGeneralSettings, 
0x69ef135c, 0x1936, 0x4bd3, 0xb0, 0x11, 0x44, 0x57, 0x24, 0x55, 0x8d, 0x8c);

#if defined(__cplusplus) && !defined(CINTERFACE)
    
	#define GPP_FLAG_AUTODETECT					0x1
	#define GPP_FLAG_INFINITE_TOTAL_LENGTH		0x2

    MIDL_INTERFACE("69EF135C-1936-4bd3-B011-445724558D8C")
    IGeneralSettings : public IUnknown
    {
    public:
		virtual HRESULT STDMETHODCALLTYPE GeFlags(/*[out]*/ DWORD* pdwFlags) = 0;
		virtual HRESULT STDMETHODCALLTYPE SetFlags(/*[in]*/ DWORD dwFlags) = 0;
		virtual HRESULT STDMETHODCALLTYPE GetOpenFileFlags(/*[out]*/ DWORD* pdwFlags) = 0;
		virtual HRESULT STDMETHODCALLTYPE SetOpenFileFlags(/*[in]*/ DWORD dwFlags) = 0;
		virtual HRESULT STDMETHODCALLTYPE GetSubstreamGuid(/*[out]*/ DWORD* pdwFlags) = 0;
		virtual HRESULT STDMETHODCALLTYPE SetSubstreamGuid(/*[in]*/ DWORD dwFlags) = 0;
   };

#endif // defined(__cplusplus) && !defined(CINTERFACE)
#endif // __IGeneralSettings_INTERFACE_DEFINED__


#ifndef __IPushModeSettings_INTERFACE_DEFINED__
#define __IPushModeSettings_INTERFACE_DEFINED__

// {69EF135d-1936-4bd3-B011-445724558D8C}
DEFINE_GUID(IID_IPushModeSettings, 
0x69ef135d, 0x1936, 0x4bd3, 0xb0, 0x11, 0x44, 0x57, 0x24, 0x55, 0x8d, 0x8c);

#if defined(__cplusplus) && !defined(CINTERFACE)
    
	#define PMPP_FLAG_PUSH_FAST			0x1
	#define PMPP_FLAG_LOOP				0x2

    MIDL_INTERFACE("69EF135D-1936-4bd3-B011-445724558D8C")
    IPushModeSettings : public IUnknown
    {
    public:
		virtual HRESULT STDMETHODCALLTYPE GeFlags(/*[out]*/ DWORD* pdwFlags) = 0;
		virtual HRESULT STDMETHODCALLTYPE SetFlags(/*[in]*/ DWORD dwFlags) = 0;
		virtual HRESULT STDMETHODCALLTYPE GetBitrate(/*[out]*/ DWORD* pdwBitrate) = 0;
		virtual HRESULT STDMETHODCALLTYPE SetBitrate(/*[in]*/ DWORD dwBitrate) = 0;
   };

#endif // defined(__cplusplus) && !defined(CINTERFACE)
#endif // __IPushModeSettings_INTERFACE_DEFINED__

///////////////////////////////////////////////////////////////////////////////////////
// Playlist support
///////////////////////////////////////////////////////////////////////////////////////

#ifndef __IPlayList_INTERFACE_DEFINED__
#define __IPlayList_INTERFACE_DEFINED__

// {69EF1330-1936-4bd3-B011-445724558D8C}
DEFINE_GUID(IID_IPlayList, 
	0x69ef1330, 0x1936, 0x4bd3, 0xb0, 0x11, 0x44, 0x57, 0x24, 0x55, 0x8d, 0x8c);

#if defined(__cplusplus) && !defined(CINTERFACE)

	#define PLPP_FLAG_LOOP					0x1
	#define PLPP_FLAG_LOCK_FILES			0x2
	#define PLPP_FLAG_NOTIFY_DISCONTINUITY	0x4
   
	struct PLAYLIST_ENTRY
	{
		LPCWSTR		wcsPath;
		ULONGLONG	ullFileSize;
		ULONG		ulNumber;
		ULONG		ulCookie;
	};


    MIDL_INTERFACE("69EF132F-1936-4bd3-B011-445724558D8C")
    IPlayListCallback : public IUnknown
    {
    public:
		virtual HRESULT STDMETHODCALLTYPE OnNextEntry(/*[out]*/PLAYLIST_ENTRY* pEntry) = 0;
   };

    MIDL_INTERFACE("69EF1330-1936-4bd3-B011-445724558D8C")
    IPlayList : public IUnknown
    {
    public:
		virtual HRESULT STDMETHODCALLTYPE GeFlags(/*[out]*/ DWORD* pdwFlags) = 0;
		virtual HRESULT STDMETHODCALLTYPE SetFlags(/*[in]*/ DWORD dwFlags) = 0;

		virtual HRESULT STDMETHODCALLTYPE Count(/*[out]*/ ULONG* pulCount) = 0;

		virtual HRESULT STDMETHODCALLTYPE Insert(/*[in]*/ LPCWSTR wcsPath,
						/*[in]*/ ULONGLONG	ullFileSize, /*[in]*/ ULONG ulNumber) = 0;

		virtual HRESULT STDMETHODCALLTYPE Remove(/*[in]*/ ULONG ulNumber) = 0;

		virtual HRESULT STDMETHODCALLTYPE GetEntry(/*[in]*/ ULONG ulNumber,
											/*[out]*/PLAYLIST_ENTRY* pEntry) = 0;

		virtual HRESULT STDMETHODCALLTYPE GetCurrEntry(/*[out]*/PLAYLIST_ENTRY* pEntry) = 0;

		virtual HRESULT STDMETHODCALLTYPE MoveEntryTo(/*[in]*/ ULONG ulPosFrom, /*[in]*/ ULONG ulPosTo) = 0;

		virtual HRESULT STDMETHODCALLTYPE RegisterCallback(/*[in]*/ IPlayListCallback* pCallback) = 0;
		virtual HRESULT STDMETHODCALLTYPE UnRegisterCallback(/*[in]*/ IPlayListCallback* pCallback) = 0;
   };



#endif // defined(__cplusplus) && !defined(CINTERFACE)
#endif // __IPlayList_INTERFACE_DEFINED__




#ifdef __cplusplus
}
#endif

#endif // __AMMT_SFSF_FilterInterfaces_h__



//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//	Copyright (C) 2003 AMMTools. All rights reserved.
//	http://www.ammtools.com mailto:support@ammtools.com

#ifndef __SmartDumpFilterInterfaces_h__
#define __SmartDumpFilterInterfaces_h__

#ifdef __cplusplus
extern "C"{
#endif

#ifndef __IDumpProgress_INTERFACE_DEFINED__
#define __IDumpProgress_INTERFACE_DEFINED__


// {D48CF7FE-F86D-4eb1-BAB2-15D57608C79A}
DEFINE_GUID(IID_IDumpProgress, 
0xd48cf7fe, 0xf86d, 0x4eb1, 0xba, 0xb2, 0x15, 0xd5, 0x76, 0x8, 0xc7, 0x9a);

#if defined(__cplusplus) && !defined(CINTERFACE)

    MIDL_INTERFACE("D48CF7FE-F86D-4eb1-BAB2-15D57608C79A")
    IDumpProgress : public IUnknown
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE GetProgress( 
            /* [in][out] */ REFERENCE_TIME* prtTime, /* [in][out] */ ULONGLONG* pullDataWritten) = 0;        
    };

#endif // defined(__cplusplus) && !defined(CINTERFACE)

#endif //__IDumpProgress_INTERFACE_DEFINED__

#ifdef __cplusplus
}
#endif

#endif // __SmartDumpFilterInterfaces_h__



//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//	Copyright (C) 2003 AMMTools. All rights reserved.
//	http://www.ammtools.com mailto:support@ammtools.com

#pragma once

// 9BE6CE5D-B8A3-4fa6-8B64-C73864B95CCA
static const CLSID CLSID_AMMTSmartFileSource = 
		{0x9be6ce5d, 0xb8a3, 0x4fa6, {0x8b, 0x64, 0xc7, 0x38, 0x64, 0xb9, 0x5c, 0xca}};


//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//	Copyright (C) 2003 AMMTools. All rights reserved.
//	http://www.ammtools.com mailto:support@ammtools.com

#pragma once

#include <list>
#include <algorithm>
#include <new>
#include <assert.h>


namespace XU
{

	//////////////////////////////////////////////////////////////
	// Allocator interfaces
	//////////////////////////////////////////////////////////////
	class AAllocator
	{
	public:
		virtual ~AAllocator()
		{}

		virtual	void*	Alloc(size_t size)	= 0;
		virtual void	Free(void* pPtr)	= 0;
	};


	class AFixedSizeAllocator
	{
	public:
		virtual ~AFixedSizeAllocator()
		{}

		virtual	void*	Alloc()				= 0;
		virtual void	Free(void* pPtr)	= 0;
	};


	/////////////////////////////////////////////////////////////////////////////////

	// Implementation of AFixedSizeAllocator using memory arena

	/////////////////////////////////////////////////////////////////////////////////
	template<size_t ST>
	class CXMemArena : public AFixedSizeAllocator
	{
	public:
		CXMemArena(size_t nBuffCount = 0) : 
						m_nBuffCount(nBuffCount),
						m_pArena(NULL),
						m_pbArenaMap(NULL) // true = free sample, false = allocated
#ifdef DEBUG
						,m_nAllocated(0),
						m_nMaxAllocated(0)
#endif // DEBUG
		{
			if(nBuffCount)
				Init(nBuffCount);
		}

		virtual ~CXMemArena()
		{
			Reset();
		}

		/////////////////////////////////////////////////////
		//
		void	Init(size_t nBuffCount)
		{
			Reset();

			m_nBuffCount = nBuffCount;
			m_pArena		= new unsigned char[m_nBuffCount * ST];
			m_pbArenaMap	= new bool[m_nBuffCount];

			std::fill(m_pbArenaMap,
					m_pbArenaMap + m_nBuffCount, true);
		}
		
		void	Reset()
		{
			delete[] m_pArena;
			m_pArena = NULL;
			delete[] m_pbArenaMap;
			m_pbArenaMap = NULL;

#ifdef DEBUG
//			assert(!m_nAllocated);
			m_nAllocated	= 0;
			m_nMaxAllocated	= 0;
#endif // DEBUG
		}
		
		/////////////////////////////////////////////////////
		//
		void*	Alloc()
		{
			assert(m_pArena && m_pbArenaMap);

			size_t n = 0;
			while(n < m_nBuffCount)
			{
				if(m_pbArenaMap[n])
				{
					m_pbArenaMap[n] = false;
#ifdef DEBUG
					++ m_nAllocated;
					if(m_nMaxAllocated < m_nAllocated)
						m_nMaxAllocated = m_nAllocated;
#endif // DEBUG
					return &m_pArena[n * ST];
				}
				++ n;
			}
			// if not found - alloc using new operator
			return new BYTE[ST];
		}

		void	Free(void* pPtr)
		{
			assert(m_pArena && m_pbArenaMap);

			ptrdiff_t n = ((unsigned char*)pPtr - m_pArena) / ST;
			if(0 <= n && n < (ptrdiff_t)m_nBuffCount)
			{
				assert(&m_pArena[n * ST] == pPtr);
				assert(!m_pbArenaMap[n]);
				m_pbArenaMap[n] = true;
#ifdef DEBUG
				-- m_nAllocated;
#endif // DEBUG
				return;
			}
			// if not found - free using delete operator
			delete [] pPtr;
		}

	private:
		size_t				m_nBuffCount;
		unsigned char*		m_pArena;
		bool*				m_pbArenaMap; // true = free sample, false = allocated

#ifdef DEBUG
		size_t		m_nAllocated;
		size_t		m_nMaxAllocated;
#endif // DEBUG

	};

	
	/////////////////////////////////////////////////////////////////////////////////

	// Utility class for dynamic objects handling

	/////////////////////////////////////////////////////////////////////////////////
#ifdef _DLL_FIXXX_
	class	CXAddressList;
	extern	CXAddressList*	g_pList;
	class	CXAddressList : public std::list<const void*>
	{
		CXAddressList() : m_nRef(1)
		{}
		~CXAddressList()
		{}

	public:
		static CXAddressList*	GetGlobalListPtr()
		{
			if(g_pList)
				g_pList->AddRef();
			else
				g_pList = new CXAddressList();
			return g_pList;
		}

		long					AddRef()
		{
			return InterlockedIncrement(&m_nRef);
		}

		long					Release()
		{
			InterlockedDecrement(&m_nRef);
			if(m_nRef == 0)
			{
				assert(empty());
				g_pList = NULL;
				delete this;
			}
			return m_nRef;
		}

	private:
		long		m_nRef;
	};

#else

	class	CXAddressList : public std::list<const void*>
	{};

#endif //_DLL_FIXXX_

	class CXAllocUtil
	{
	public:
		virtual ~CXAllocUtil(){}

		void* operator new(size_t size)
		{
			if(void* p = ::operator new(size))
			{
				GetList().push_back(p);
				return p;
			}
			return NULL;
		}

		void	operator delete(void * p)
		{
			GetList().remove(p);
			::operator delete(p);
		}

		bool IsSafeToDelete() const
		{
			return std::find(GetList().begin(), GetList().end(),
								dynamic_cast<const void*>(this)) !=	GetList().end();
		}

	private:
#ifdef _DLL_FIXXX_
		// NOTE: g_pList must be defined externaly, and initialized by NULL !!!
		static CXAddressList& GetList()
		{
			return *g_pList;
		}

#else //_DLL_FIXXX_
		// Unfortunatly this simple implementation doesn't work in DLL
		static CXAddressList& GetList()
		{
			static CXAddressList	List;
			return List;
		}

#endif //_DLL_FIXXX_
	};
}

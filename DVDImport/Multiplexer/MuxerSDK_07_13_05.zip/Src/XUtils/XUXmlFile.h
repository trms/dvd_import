//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//	Copyright (C) 2003 AMMTools. All rights reserved.
//	http://www.ammtools.com mailto:support@ammtools.com


#pragma once

#include "XUXmlElements.h"
#include "XUExc.h"
#include "XUMemUtils.h"

namespace XU
{
	class CXmlFile
	{
	public:
		CXmlFile(LPCTSTR tcsFileName = NULL, LPWORD pUnicodeFlag = NULL);
		
		virtual ~CXmlFile();
		
		virtual HRESULT Open(LPCTSTR tcsFileName, LPWORD pUnicodeFlag = NULL);
		virtual HRESULT Close();

		bool IsOpened() const
		{
			return m_hFile != INVALID_HANDLE_VALUE;
		}

		LPCTSTR GetFileName() const
		{
			return m_FileName;
		}

		virtual CXmlFile& operator <<(LPCTSTR csString);
		virtual CXmlFile& operator <<(LPCWSTR wcsString);
		virtual CXmlFile& operator <<(const AItem* pItem);

		operator HANDLE() const
		{
			return m_hFile;
		}

	private:
		CTString			m_FileName;
		HANDLE				m_hFile;
		CXUSimpleBuffer		m_Buffer;
	};
}
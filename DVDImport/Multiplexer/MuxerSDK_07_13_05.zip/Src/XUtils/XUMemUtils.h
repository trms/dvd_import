
#pragma once

namespace XU
{
	class CXUSimpleBuffer
	{
		public:
			CXUSimpleBuffer(size_t tInitSize = 0) :
			  m_pData(tInitSize ? new unsigned char[tInitSize] : 0), m_DataSize(tInitSize)
			{}
			~CXUSimpleBuffer()	
			{
				delete [] m_pData;
			}

			LPBYTE	GetPtr(size_t nSize)
			{
				if(nSize > m_DataSize)
				{
					delete [] m_pData;
					if(m_pData = new unsigned char[nSize])
						m_DataSize = nSize;
				}
				return m_pData;
			}

		private:
			unsigned char*	m_pData;
			size_t			m_DataSize;
	};





	// memcpy_mmx
	// Uses MMX instructions to move memory around
	// does as much as we can in 64 byte chunks
	// using MMX instructions, then copies any extra bytes
	// assumes there will be at least 64 bytes to copy
	// This code was originally from Borg's bTV plugin SDK 
	static void memcpy_mmx(void* dst, const void* src, int n)
	{
		__asm {
			mov		ecx, n
			mov		eax, dword ptr[src]
			shr     ecx, 6                      // nBytes / 64
			mov		edx, dword ptr[dst]
			or		ecx, ecx
			je		NoMMX
	align 8
	CopyLoop:
			movq	mm0, qword ptr[eax]
			movq	mm1, qword ptr[eax+8*1]
			movq	mm2, qword ptr[eax+8*2]
			movq	mm3, qword ptr[eax+8*3]
			movq	mm4, qword ptr[eax+8*4]
			movq	mm5, qword ptr[eax+8*5]
			movq	mm6, qword ptr[eax+8*6]
			movq	mm7, qword ptr[eax+8*7]
			add		eax, 64
			movq	qword ptr[edx], mm0
			movq	qword ptr[edx+8*1], mm1
			movq	qword ptr[edx+8*2], mm2
			movq	qword ptr[edx+8*3], mm3
			movq	qword ptr[edx+8*4], mm4
			movq	qword ptr[edx+8*5], mm5
			movq	qword ptr[edx+8*6], mm6
			movq	qword ptr[edx+8*7], mm7
			add		edx, 64
			loop CopyLoop
	NoMMX:
			mov		ecx, n
			cld
			mov		esi, eax
			and		ecx, 63
			mov		edi, edx
			rep		movsb

			emms
		}
	}
}


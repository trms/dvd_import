//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//	Copyright (C) 2003 AMMTools. All rights reserved.
//	http://www.ammtools.com mailto:support@ammtools.com


#pragma once
#include  <stddef.h>

typedef unsigned int	UINT;
typedef unsigned char	BYTE;

namespace XU
{
	/////////////////////////////////////////////////////////////////////////////////
	// INTERFACE of object which searches stream-specific syntax units in
	// input bitstream
	/////////////////////////////////////////////////////////////////////////////////
	class AParser
	{
	public:
		virtual ~AParser(){};
		// Initialization/ deinitialization
		virtual bool			Init(const BYTE*  pbData, size_t ulDataSize)	= 0;
		virtual void			Reset()											= 0;
		
		// Bitstream searching
		virtual const BYTE*		FindSyntaxUnit()								= 0;

		// Returns remainder of unparsed data
		virtual size_t			GetValidDataSize()		const					= 0;
		virtual size_t			GetAvailableDataSize()	const					= 0;
		virtual size_t			GetParsed()				const					= 0;

		// Shifts current parser pointer 
		virtual void			ShiftCursor(ptrdiff_t lShift)					= 0;
	};
}
//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//	Copyright (C) 2003 AMMTools. All rights reserved.
//	http://www.ammtools.com mailto:support@ammtools.com

#pragma once
#include <assert.h>
#include "XUFileNameUtils.h"
#include "XUExc.h"
#include "XUXmlElements.h"
#include "XUXmlParser.h"
#include <limits>

#undef max

namespace XU
{
	const size_t CXmlParser::s_nInvalidPos = std::numeric_limits<size_t>::max();

	CXmlParser::CXmlParser(AXmlParseCallback& Callback, LPCTSTR tcsFileName) :
			m_Callback(Callback),
			m_bContinue(true),
			m_File(tcsFileName)
	{
		m_sDigits.insert('0');
		m_sDigits.insert('1');
		m_sDigits.insert('2');
		m_sDigits.insert('3');
		m_sDigits.insert('4');
		m_sDigits.insert('5');
		m_sDigits.insert('6');
		m_sDigits.insert('7');
		m_sDigits.insert('8');
		m_sDigits.insert('9');
		m_sDigits.insert('+');
		m_sDigits.insert('-');
	}

	HRESULT CXmlParser::OpenFile(LPCTSTR tcsFileName)
	{
		return m_File.Open(tcsFileName);
	}

	void CXmlParser::Start()
	{
		assert(m_File.IsOpened());
		m_Callback.OnParseStart(m_File.GetData(), m_File.GetSize());
		//
		m_TagInfo.csTagStart = m_File.GetData();
		m_TagInfo.nTagLen = 0;
		//
		m_Callback.OnParseCompleted(Process());
	}

	void CXmlParser::Stop()
	{
		m_bContinue = false;
	}

	HRESULT CXmlParser::Process()
	{
		while(GetNextTag() && m_bContinue)
		{
			// Read tag
			if(m_TagInfo.csTagStart[1] == '?')
				XTRY
					ReadProcessorInstruction();
				XCATCH
			else if(m_TagInfo.csTagStart[1] == '!')
				XTRY
					ReadComments();
				XCATCH
			else
				XTRY
					ReadElement();
				XCATCH
			//
		}
		return m_bContinue ? S_OK : S_FALSE;
	}

	bool CXmlParser::GetNextTag()
	{
		XTRY
			if(m_TagInfo.csTagStart = strchr(m_TagInfo.csTagStart += m_TagInfo.nTagLen, '<'))
			{
				if(m_TagInfo.csTagStart[1] == '!')// Comments may contain tags
				{ // Search for end of comments
					if(LPSTR csEnd = strstr(m_TagInfo.csTagStart, "-->"))
					{
						m_TagInfo.nTagLen = csEnd - m_TagInfo.csTagStart + 3;
						return true;
					}
				}
				else if(LPSTR csEnd = strchr(m_TagInfo.csTagStart, '>'))
				{
					m_TagInfo.nTagLen = csEnd - m_TagInfo.csTagStart + 1;
					return true;
				}
			}
		XCATCH
		return false;
	}

	//
	void CXmlParser::ReadProcessorInstruction()
	{
		m_Callback.OnInstruction(m_TagInfo.csTagStart - m_File.GetData(), m_TagInfo.nTagLen);
	}
	void CXmlParser::ReadComments()
	{
		m_Callback.OnComments(m_TagInfo.csTagStart - m_File.GetData(), m_TagInfo.nTagLen);
	}

	void CXmlParser::ReadElement()
	{// Parse element tag
		LPCSTR csTmp = GetNormalizedString();
		if(csTmp[0] == '/') // Closing tag
		{// No parameters are supposed, just get the tag name
			m_Callback.OnElementDataEnd(m_TagInfo.csTagStart - m_File.GetData(),
										CTString(csTmp + 1));
		}
		else
		{
			CItemsList		Params;
			CTString name = ParseElementTag(csTmp, Params);
			m_Callback.OnElementBegin(m_TagInfo.csTagStart - m_File.GetData(),
									name, Params.size() ? &Params : NULL);

			m_Callback.OnElementDataBegin(m_TagInfo.csTagStart  + m_TagInfo.nTagLen - m_File.GetData(),
											name);
			if(csTmp[strlen(csTmp) - 1] == '/')
				m_Callback.OnElementDataEnd(m_TagInfo.csTagStart  + m_TagInfo.nTagLen - m_File.GetData(),
											name);

		}
		delete [] csTmp;
	}
	
	LPCSTR	CXmlParser::GetNormalizedString()
	{
		LPSTR csTmp = new CHAR[m_TagInfo.nTagLen];
		memcpy(csTmp, m_TagInfo.csTagStart + 1, m_TagInfo.nTagLen - 1);
		csTmp[m_TagInfo.nTagLen - 1] = 0;
		
		// Normalize string
		for(UINT n = 1, m = 0; n < m_TagInfo.nTagLen + 1; n++)
		{
			if(csTmp[n] == '\t'|| csTmp[n] == '\n' || csTmp[n] == 0xd)
				csTmp[n] = ' ';
			if((csTmp[n] == ' ' || csTmp[n] == '>' || csTmp[n] == '/' || csTmp[n] == '=' || csTmp[n] == '"')
					&& csTmp[m] == ' ')
				csTmp[m] = csTmp[n];// remove space
			else
				if((++ m) != n)
					csTmp[m] = csTmp[n];
		}
		csTmp[strlen(csTmp) - 1] = 0;
		return csTmp;
	}

	CTString CXmlParser::ParseElementTag(LPCSTR csTmp, CItemsList& Params)
	{
		CTString str(csTmp);
		// Get name
		size_t pos = str.find(' '), pos1, q1, q2;
		CTString name = str.substr(0, pos);

		// Check if the tag has parametrs list
		if(name.length() != str.length())
		{// Read parametrs
			str = str.substr(pos + 1, -1);
			CTString tmp, param, tmp1;
			const AItem* pItem = NULL;

			while((pos = str.find('=')) != -1)
			{
				tmp = str.substr(pos + 1, -1);
				while((pos1 = tmp.rfind('=')) != -1)
					tmp = tmp.substr(0, pos1);

 				if(q1 = tmp.find('\"') != -1)
				{
					tmp1 = tmp.substr(q1, -1);
					q2 = tmp1.find('\"');
					param = str.substr(0, pos += q1 + q2 + 2);

				}
//				pos1 = tmp.rfind(' ') + 1;
//				param = str.substr(0, pos1 ? pos += pos1 : -1);


				// Parse parametrs
				if(pItem = ParseParam(param))
					Params.push_back(const_cast<AItem*>(pItem));

				if(pos + 1 >= str.length())
					break;
				str = str.substr(pos + 1, -1);
			}
		}
		return name;
	}

	const AItem* CXmlParser::ParseParam(const CTString& param)
	{
		size_t pos = param.find('=');
		if(pos != -1)
		{
			CTString name = param.substr(0, pos),
				value = param.substr(pos + 2, param.length() - 1);
			// truncate  value's last " or "/
			if(value[value.length() - 1] == '/')
				value[value.length() - 2] = 0;
			else
				value[value.length() - 1] = 0;

			// Save param name
			m_ParamNames.insert(name);
			std::set<CTString>::iterator iname = m_ParamNames.find(name);

			if(!name.empty() && !value.empty())
			{
/*				// Determine value type
				bool bLong = true, bFloat = false;
				size_t sz = value.length();

				for(size_t n = 0; n < sz; n ++)
					if(value[n] = _T('.') || value[n] = _T('e'))
					{
						bFloat = true;
						bLong = false;
					}
					else if(m_sDigits.find(value[n]) == m_sDigits.end())
					{
						bLong = bFloat = false;
						break;
					}
				// Convert value
				if(bLong)
					pItem = new CXMLParam<long>((*iname), _tstol(value));
				else if(bFloat)
					pItem = new CXMLParam<double>((*iname), _tstof(value));
				else
					pItem = new CXMLParam<CTString>((*iname), value);
 */	
				return new CXMLParam<CTString>((*iname), value);
			}

		}
		return NULL;
	}

	////////////////////////////////////////////////////////////
	//
	CXmlParser::CFileMapping::CFileMapping(LPCTSTR tcsFileName) : 
			m_hFile(INVALID_HANDLE_VALUE),
			m_hMapping(NULL),
			m_csData(NULL),
			m_Size(0)

	{
		if(tcsFileName)
			Open(tcsFileName);
	}

	CXmlParser::CFileMapping::~CFileMapping()
	{
		Close();
	}

	HRESULT	CXmlParser::CFileMapping::Open(LPCTSTR tcsFileName)
	{
		Close();
		HRESULT hr = S_OK;
		LPCTSTR tcsMsg = _T("CXmlFile::Open has failed.");
		try
		{
			// Open file
			m_hFile = XUCreateFile(tcsFileName, GENERIC_READ, OPEN_EXISTING, FILE_SHARE_READ);

			// Support files less than 4 GB only
			m_Size = GetFileSize(m_hFile, NULL);

			// Create mapping object
			m_hMapping = CreateFileMapping(m_hFile, NULL, PAGE_READONLY, 0, 0, NULL);
			if(m_hMapping == NULL)
				throw CW32FileExc(tcsMsg, tcsFileName, GetLastError());

			// Map
			m_csData = (LPCSTR)MapViewOfFile(m_hMapping, FILE_MAP_READ, 0, 0, 0);
			if(!m_csData)
				throw CW32FileExc(tcsMsg, tcsFileName, GetLastError());
		}
		catch(...)
		{
			Close();
			throw;
		}
		return hr;
	}

	void CXmlParser::CFileMapping::Close()
	{
		// Unmap
		if(m_csData)
		{
			UnmapViewOfFile(m_csData);
			m_csData = NULL;
		}

		// Close mapping
		if(m_hMapping)
		{
			CloseHandle(m_hMapping);
			m_hMapping = NULL;
		}

		// Close file
		if(m_hFile != INVALID_HANDLE_VALUE)
		{
			CloseHandle(m_hFile);
			m_hFile = INVALID_HANDLE_VALUE;
		}
		m_Size = 0;
	}

}
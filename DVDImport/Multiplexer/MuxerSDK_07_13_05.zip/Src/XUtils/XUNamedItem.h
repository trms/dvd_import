//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//	Copyright (C) 2003 AMMTools. All rights reserved.
//	http://www.ammtools.com mailto:support@ammtools.com


#pragma once

#include "XUString.h"
#include "XUMemUtils.h"
#include <list>
#include <algorithm>
#include <assert.h>

namespace XU
{

	class AItem
	{
	public:
		virtual ~AItem()
		{}

		virtual LPCTSTR			GetName() const										= 0;
		virtual	CTString&		Format(CTString& str, CXUSimpleBuffer& buff) const	= 0;
		virtual	VARTYPE			GetValueType()	const								= 0;
	};


	template<typename T>
	class CItem : public AItem
	{
	public:
		CItem(LPCTSTR tcsName, const T& t) :
				m_Name(tcsName),
				m_Val(t)
		{}

		CItem(const CItem<T>& Item) :
				m_Name(Item.m_Name),
				m_Val(Item.m_Val)
		{}

		LPCTSTR		GetName() const
		{
			return m_Name;
		}

		const T&	GetValue() const
		{
			return m_Val;
		}

		VARTYPE			GetValueType()	const; // Need specification

	protected:
		LPCTSTR			m_Name;
		T				m_Val;
	};

	//////////////////////////////////////////////////////////
	//
		inline VARTYPE CItem<long>::GetValueType()	const
		{
			return VT_I4;
		}

		inline VARTYPE CItem<ULONGLONG>::GetValueType()	const
		{
			return VT_UI8;
		}

		inline VARTYPE CItem<bool>::GetValueType()	const
		{
			return VT_BOOL;
		}

		inline VARTYPE CItem<LPCSTR>::GetValueType()	const
		{
			return VT_LPSTR;
		}

		inline VARTYPE CItem<CTString>::GetValueType()	const
		{
			return VT_LPSTR;
		}

		inline VARTYPE CItem<LPCWSTR>::GetValueType()	const
		{
			return VT_LPWSTR;
		}

		inline VARTYPE CItem<void*>::GetValueType()	const
		{
			return VT_EMPTY;
		}

		inline VARTYPE CItem<double>::GetValueType()	const
		{
			return VT_R8;
		}
	///////////////////////////////////////////////////////////////////////
	//
		inline LPCTSTR	GetLPCTSTR(const AItem* pItem)
		{
			assert(pItem);
			return pItem ? (LPCTSTR)(static_cast< const CItem<CTString>* >(pItem)->GetValue()) : NULL;
		}

		inline bool		GetBool(const AItem* pItem)
		{
			LPCTSTR ts = GetLPCTSTR(pItem);
			if(ts && 
				(!_tcsicmp(ts, _T("true")) ||
				!_tcsicmp(ts, _T("yes")) ||
				!_tcsicmp(ts, _T("1"))))
				return true;

			return false;
		}

		inline long		GetLong(const AItem* pItem)
		{
			if(LPCTSTR ts = GetLPCTSTR(pItem))
				return _tstol(ts);
			return 0;
		}

		inline double		GetDouble(const AItem* pItem)
		{
			if(LPCTSTR ts = GetLPCTSTR(pItem))
				return _tstof(ts);
			return 0;
		}
	///////////////////////////////////////////////////////////////////////
	//
	class CItemsList : public std::list<AItem*>
	{
	public:
		virtual ~CItemsList()
		{
			while(!empty())
			{
				delete back();
				pop_back();
			}
		}

		AItem* FindByName(LPCTSTR tcsName)
		{
			iterator i = std::find_if(begin(), end(), PNameFind(tcsName));
			return i != end() ? *i : NULL;
		}

	private:
		class PNameFind
		{
		public:
			PNameFind(LPCTSTR tcsName) : m_tcsName(tcsName)
			{}
			bool operator()(const AItem* item) const
			{
				return !_tcscmp(m_tcsName, item->GetName());
			}
		private:
			LPCTSTR const m_tcsName;
		};
	};

	///////////////////////////////////////////////////////////////////////
	//
	class CCompositeItem : public AItem
	{
	public:
		CCompositeItem(LPCTSTR tcsName) :
				m_Name(tcsName)
		{}
		LPCTSTR		GetName() const
		{
			return m_Name;
		}

		VARTYPE				GetValueType()	const
		{
			return VT_RECORD;
		}

		CItemsList&			GetSubItems()
		{
			return m_Items;
		}
	protected:
//		XU::CTString	m_Name;
		LPCTSTR			m_Name;
		CItemsList		m_Items;
	};
}
//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//	Copyright (C) 2003 AMMTools. All rights reserved.
//	http://www.ammtools.com mailto:support@ammtools.com


#include "XUXmlFile.h"
#include "XUFileNameUtils.h"

namespace XU
{
	CXmlFile::CXmlFile(LPCTSTR tcsFileName, LPWORD pUnicodeFlag) : 
			m_hFile(INVALID_HANDLE_VALUE)
	{
		if(tcsFileName)
			Open(tcsFileName, pUnicodeFlag);
	}
	
	CXmlFile::~CXmlFile()
	{
		Close();
	}
	
	HRESULT CXmlFile::Open(LPCTSTR tcsFileName, LPWORD pUnicodeFlag)
	{
		if(!tcsFileName)
			throw CW32FileExc(_T("CXmlFile::Open"), tcsFileName, E_POINTER);

		// Open file
		m_hFile = XUCreateFile(tcsFileName, GENERIC_WRITE, CREATE_ALWAYS);

		if(pUnicodeFlag)
		{
			DWORD dwWritten = 0;
			if(!WriteFile(m_hFile, pUnicodeFlag, sizeof(WORD), (LPDWORD)&dwWritten, NULL)) // Write string
				throw CW32FileExc(_T("CXmlFile::Open"), tcsFileName, GetLastError());
		}

		m_FileName = tcsFileName;
		return S_OK;
	}

	HRESULT CXmlFile::Close()
	{
		if(IsOpened())
		{
			CloseHandle(m_hFile);
			m_hFile = INVALID_HANDLE_VALUE;
		}
		m_FileName.clear();
		return S_OK;
	}

	CXmlFile& CXmlFile::operator <<(LPCTSTR csString)
	{
		if(!IsOpened())
			throw CW32Exc(_T("CXmlFile::operator << file isn't opened"));

		size_t dwBuffSize = strlen(csString) + 512;
		LPTSTR lpMsgBuf = (LPTSTR)m_Buffer.GetPtr(dwBuffSize * sizeof(TCHAR));
		try
		{
			if(!(dwBuffSize = FormatMessage(FORMAT_MESSAGE_FROM_STRING|FORMAT_MESSAGE_IGNORE_INSERTS,
								csString, 0, 0, lpMsgBuf, dwBuffSize, NULL)))
				throw CW32FileExc(_T("CXmlFile::operator<<"), m_FileName, GetLastError());

#if  defined(_UNICODE) || defined(UNICODE)
			LPSTR csStr = new CHAR[dwBuffSize];
			int result = ::WideCharToMultiByte(CP_ACP, 0, (LPCWSTR)lpMsgBuf, -1,
												csStr, wcslen((LPCWSTR)lpMsgBuf) + 1, NULL, NULL);
			if(result > 0)
				csStr[result - 1] = 0;

			if(!WriteFile(m_hFile, csStr, dwBuffSize, &dwBuffSize, NULL)) // Write string
			{		
				delete [] csStr;
				throw CW32FileExc(_T("CXmlFile::operator<<"), m_FileName, GetLastError());
			}

			delete [] csStr;
#else
			DWORD dwWritten = 0;
			if(!WriteFile(m_hFile, lpMsgBuf, dwBuffSize, &dwWritten, NULL)) // Write string
				throw CW32FileExc(_T("CXmlFile::operator<<"), m_FileName, GetLastError());
#endif
		}
		catch(CW32FileExc&)
		{
			throw;
		}
		catch(CW32Exc&)
		{
			throw;
		}
		catch(...)
		{
			throw CW32Exc(_T("CXmlFile::operator<< unknown error"));
		}
		return *this;
	}

	CXmlFile& CXmlFile::operator <<(LPCWSTR wcsString)
	{
		if(!IsOpened())
			throw CW32Exc(_T("CXmlFile::operator << file isn't opened"));

		size_t dwBuffSize = wcslen(wcsString)*sizeof(WCHAR);
		try
		{
			if(!WriteFile(m_hFile, wcsString, dwBuffSize, (LPDWORD)&dwBuffSize, NULL)) // Write string
				throw CW32FileExc(_T("CXmlFile::operator<<"), m_FileName, GetLastError());
		}
		catch(CW32Exc&)
		{
			throw;
		}
		catch(...)
		{
			throw CW32Exc(_T("CXmlFile::operator<< unknown error"));
		}
		return *this;
	}

	CXmlFile& CXmlFile::operator <<(const AItem* pItem)
	{
		CTString str;
		CXUSimpleBuffer buff;
		return operator<<(pItem->Format(str, buff));
	}


}
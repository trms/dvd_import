//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//	Copyright (C) 2003 AMMTools. All rights reserved.
//	http://www.ammtools.com mailto:support@ammtools.com

#pragma once
#include "XUNamedItem.h"
#include <set>

namespace XU
{
	class AXmlParseCallback
	{
	public:
		//
		virtual void OnParseStart(LPCSTR csData, size_t nDataSize)		= 0;
		virtual void OnParseCompleted(HRESULT hr)						= 0;
		//
		virtual void OnElementBegin(ptrdiff_t nPos, LPCTSTR csTag,
									const CItemsList* pParams)			= 0;
		virtual void OnElementDataBegin(ptrdiff_t nPos, LPCTSTR tsTag)	= 0;
		virtual void OnElementDataEnd(ptrdiff_t nPos, LPCTSTR tsTag)	= 0;
		//
		virtual void OnComments(ptrdiff_t nPos, size_t nSize)			= 0;
		//
		virtual void OnInstruction(ptrdiff_t nPos, size_t nSize)		= 0;
	};

	class CXmlParser
	{
	public:
		CXmlParser(AXmlParseCallback& Callback, LPCTSTR tcsFileName = NULL);

		virtual HRESULT OpenFile(LPCTSTR tcsFileName);
		virtual void	Start();
		virtual void	Stop();


	private:
		AXmlParseCallback&		m_Callback;
		bool					m_bContinue;

		
		static const size_t		s_nInvalidPos;
		//////////////////////////////////////////////////
		// File object
		class CFileMapping
		{
		public:
			CFileMapping(LPCTSTR tcsFileName = NULL);
			~CFileMapping();
			HRESULT					Open(LPCTSTR tcsFileName);
			void					Close();

			bool					IsOpened() const
			{
				return !!m_csData;
			}

			LPCSTR					GetData() const
			{
				return m_csData;
			}

			size_t					GetSize() const
			{
				return m_Size;
			}
		private:
			HANDLE							m_hFile;
			HANDLE							m_hMapping;
			LPCSTR							m_csData;
			size_t							m_Size;
		};
		CFileMapping		m_File;

		/////////////////////////////////////////////////
		// Parsing stuff
		HRESULT		Process();
		bool		GetNextTag();

		void		ReadProcessorInstruction();
		void		ReadComments();
		void		ReadElement();

		struct 
		{
			LPCSTR	csTagStart;
			size_t	nTagLen;
		}			m_TagInfo;

		LPCSTR			GetNormalizedString();
		CTString		ParseElementTag(LPCSTR csTmp, CItemsList& Params);
		const AItem*	ParseParam(const CTString& param);

		std::set<CTString> m_ParamNames;

		//
		std::set<TCHAR> m_sDigits;
	};

	// some helpers
	inline bool CheckName(LPCTSTR tcsName, LPCTSTR tcsString)
	{
		assert(tcsName);
		return _tcsicmp(tcsName, tcsString) == 0;
	}

	inline bool CheckName(const XU::AItem* pItem, LPCTSTR tcsString)
	{
		assert(pItem);
		return CheckName(pItem->GetName(), tcsString);
	}

}
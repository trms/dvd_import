//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//	Copyright (C) 2003 AMMTools. All rights reserved.
//	http://www.ammtools.com mailto:support@ammtools.com


#pragma once

#include <windows.h>
#include <tchar.h>
#include <string>

/*
	#if (defined _UNICODE || defined UNICODE)
		typedef unsigned short*			LPTSTR;
		typedef const unsigned short*	LPCTSTR;
	#else
		typedef	unsigned char*			LPTSTR;		
		typedef	const unsigned char*	LPCTSTR;
	#endif // _UNICODE
*/
/////////////////////////////////////////////////////////////////////
// Win32 adapted string classes
namespace XU
{
	class CWString;
	class CCString;

	class CTString : public std::basic_string<TCHAR>
	{
	public:
		CTString()
		{}

		CTString(int nCount, TCHAR tChar) :  std::basic_string<TCHAR>(nCount, tChar)
		{}


		CTString(const std::basic_string<TCHAR>& str) : std::basic_string<TCHAR>(str)
		{}

		CTString(const CTString& str) : std::basic_string<TCHAR>(str)
		{}

		CTString(LPCTSTR str) : std::basic_string<TCHAR>(str ? str : _T(""))
		{}

#if  !defined(_UNICODE) && !defined(UNICODE)
		CTString(LPCWSTR str, UINT nCodePage = CP_ACP)
		{
			if(str)
			{
				int result = ::WideCharToMultiByte(nCodePage, 0, str, -1,
					NULL, 0, NULL, NULL);
				LPTSTR tcsTmp = new TCHAR[result];
				result = ::WideCharToMultiByte(nCodePage, 0, str, -1,
					tcsTmp, (int)wcslen(str) + 1, NULL, NULL);
				if(result > 0)
					tcsTmp[result - 1] = 0;
				*this = tcsTmp;
				delete[] tcsTmp;
			}
		}
#endif // !defined(_UNICODE) && !defined(UNICODE)

		virtual ~CTString()
		{}

		CTString&	operator =(const CTString& str)
		{
			static_cast<std::basic_string<TCHAR>* >(this)->operator=(str);
			return *this;
		}

		CTString&	operator =(LPCTSTR str)
		{
			static_cast<std::basic_string<TCHAR>* >(this)->operator=(str);
			return *this;
		}

		operator LPCTSTR() const
		{
			return c_str();
		}

		CWString GetWString() const;
		CCString GetCString() const;
	};

	class CWString : public std::basic_string<WCHAR>
	{
	public:
		CWString()
		{}

		CWString(const std::basic_string<WCHAR>& str) : std::basic_string<WCHAR>(str)
		{}

		CWString(const CWString& str) : std::basic_string<WCHAR>(str)
		{}

		CWString(LPCWSTR str) : std::basic_string<WCHAR>(str ? str : L"")
		{}

#if  !defined(_UNICODE) && !defined(UNICODE)
		CWString(LPCTSTR str, UINT nCodePage = CP_ACP)
		{
			if(str)
			{
				int result = ::MultiByteToWideChar(nCodePage, 0, str, -1,
					NULL, 0);
				LPWSTR wcsTmp = new WCHAR[result];

				result = ::MultiByteToWideChar(nCodePage, 0, str, -1,
					wcsTmp, (int)_tcslen(str) + 1);
				if(result > 0)
					wcsTmp[result - 1] = 0;
				*this = wcsTmp;
				delete[] wcsTmp;
			}
		}
#endif // !defined(_UNICODE) && !defined(UNICODE)

		operator LPCWSTR() const
		{
			return c_str();
		}

		CTString GetTString() const;
		CCString GetCString() const;
	};

	class CCString : public std::basic_string<CHAR>
	{
	public:
		CCString()
		{}

		CCString(const std::basic_string<CHAR>& str) : std::basic_string<CHAR>(str)
		{}

		CCString(const CTString& str) : std::basic_string<CHAR>(str)
		{}

		CCString(LPCTSTR str) : std::basic_string<CHAR>(str)
		{}

		virtual ~CCString()
		{}

		operator LPCSTR() const
		{
			return c_str();
		}

		CTString GetTString() const;
		CWString GetWString() const;
	};
}


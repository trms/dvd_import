//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//	Copyright (C) 2003 AMMTools. All rights reserved.
//	http://www.ammtools.com mailto:support@ammtools.com


#pragma once

#include <windows.h>
#include <tchar.h>
#include <assert.h>

namespace XU
{
	/////////////////////////////////////////////////////////////////
	// Thread-safe reference counter 
	class CXRefCounter
	{
	public:
		CXRefCounter() : m_nRef(1)
		{}

		long	AddRef()
		{
			return InterlockedIncrement(&m_nRef);
//			return ++m_nRef;
		}

		long	Release()
		{
			return InterlockedDecrement(&m_nRef);
//			return --m_nRef;
		}

		long	GetRef() const
		{
			return m_nRef;
		}
	private:
		long	m_nRef;
	};


	///////////////////////////////////////////////////////////////////////////////////
	// Win32 API Event
	class CXEvent
	{
	public:
		CXEvent(bool bManual = false, bool bInitialState = false, LPCTSTR tcsName = NULL, LPSECURITY_ATTRIBUTES lpEventAttributes = NULL) : 
				m_hHandle(CreateEvent(lpEventAttributes, bManual, bInitialState, tcsName)),
				m_bManual(bManual),
				m_tcsName(tcsName ? m_tcsName = _tcsdup(tcsName) : NULL)
		{}

		// Copy constructor throws HRESULT if failed to duplicate handle
		CXEvent(const CXEvent& ev);

		virtual ~CXEvent()
		{
			CloseHandle(m_hHandle);
			if(m_tcsName)
				free((LPVOID)m_tcsName);
		}

		///////////////////////////////////////////////////////////////////////
		// Operators
		operator HANDLE() const
		{
			return m_hHandle;
		}
		
		// operator =() throws HRESULT if failed to duplicate handle
		virtual CXEvent& operator =(const CXEvent& ev);

		///////////////////////////////////////////////////////////////////////
		// 
		LPCTSTR		GetName() const
		{
			return m_tcsName;
		}

		bool		IsManual() const
		{
			return m_bManual;
		}

		//////////////////////////////////////////////////////////////////////
		// Operations
		void		Set()
		{
			SetEvent(m_hHandle);
		}

		void		Reset()
		{
			ResetEvent(m_hHandle);
		}

		void		Pulse()
		{
			PulseEvent(m_hHandle);
		}

		bool		Wait(DWORD dwTimeout = INFINITE) const
		{
			return WaitForSingleObject(m_hHandle, dwTimeout) == WAIT_OBJECT_0;
		}

		bool		IsSet() const
		{
			assert(m_bManual);// don't do it with automatic events!!!
			return WaitForSingleObject(m_hHandle, 0) == WAIT_OBJECT_0;
		}

	private :
		HANDLE		m_hHandle;
		bool		m_bManual;
		LPCTSTR		m_tcsName;
	};

	///////////////////////////////////////////////////////////////////////////////////
	// Win32 API Critical Section
	///////////////////////////////////////////////////////////////////////////////////
	class CXCritSec
	{
	public:
		CXCritSec()
		{
			InitializeCriticalSection(&m_cs);
		}

		virtual ~CXCritSec()
		{
			DeleteCriticalSection(&m_cs);
		}

		void	Lock()
		{
			EnterCriticalSection(&m_cs);
		}
		void	Unlock()
		{
			LeaveCriticalSection(&m_cs);
		}

	private:
		CRITICAL_SECTION	m_cs;

	private:
		CXCritSec(const CXCritSec&);
		CXCritSec& operator =(const CXCritSec&);
	};


	///////////////////////////////////////////////////////////////////////////////////
	// Win32 API Mutex
	///////////////////////////////////////////////////////////////////////////////////
	class CXMutex
	{
	public:
		 // Constructors throws HRESULT
		CXMutex(bool bInitialOwner = false,  LPCTSTR tcsName = NULL, bool bUnique = false) :
				m_hHandle(CreateMutex(NULL, bInitialOwner, tcsName)),
				m_tcsName(tcsName ? m_tcsName = _tcsdup(tcsName) : NULL)
		{
			if(!m_hHandle)
			{
				DWORD dwErr = GetLastError();
				if(bUnique || (dwErr != ERROR_ALREADY_EXISTS))
					throw HRESULT_FROM_WIN32(dwErr);
			}

		}
		
		CXMutex(const CXMutex& mutex);

		virtual ~CXMutex()
		{
			CloseHandle(m_hHandle);
			if(m_tcsName)
				free((LPVOID)m_tcsName);
		}
		
		// Operators
		virtual CXMutex& operator=(const CXMutex& mutex);

		operator HANDLE() const
		{
			return m_hHandle;
		}
		
		/////////////////////////////////////////////////////////////////////
		LPCTSTR		GetName() const
		{
			return m_tcsName;
		}
		/////////////////////////////////////////////////////////////////////
		// Operations
		bool IsLocked() const
		{
			return WaitForSingleObject(m_hHandle, 0) == WAIT_TIMEOUT;
		}

		bool Lock(DWORD dwWait = INFINITE)
		{
			return WaitForSingleObject(m_hHandle, dwWait) == WAIT_OBJECT_0;
		}

		bool Unlock()
		{
	        return !!ReleaseMutex(m_hHandle);
		}

	private:
		HANDLE		m_hHandle;
		LPCTSTR		m_tcsName;
	};

	/////////////////////////////////////////////////////////////////////
	// CAutoLock
	/////////////////////////////////////////////////////////////////////
	template <typename T>
	class CXAutoLock
	{
	public:
		CXAutoLock(const T& object) : m_Obj(const_cast<T&>(object))
		{
			m_Obj.Lock();
		}

		~CXAutoLock()
		{
			m_Obj.Unlock();
		}
	private:
		T&			m_Obj;
	};


	/////////////////////////////////////////////////////////////////////
	// CThreadExecute
	/////////////////////////////////////////////////////////////////////
	template <typename A = bool, typename R = bool>
	class CXThreadExecuteFunc
	{
		typedef R (*Func)();
		typedef R (*FuncA)(A a);
		struct arg
		{
			arg(Func pFunc) :	m_pFunc(pFunc), m_pFuncA(NULL), m_hWait(CreateEvent(NULL, false, false, NULL))
			{}

			arg(FuncA pFunc, A a) :	m_pFunc(NULL), m_pFuncA(pFunc), m_A(a), m_hWait(CreateEvent(NULL, false, false, NULL))
			{}
			
			Func	m_pFunc;
			FuncA	m_pFuncA;
			A		m_A;
			HANDLE	m_hWait;
		};
	public:
		static bool Execute(Func pFunc,
							HANDLE* pHndl = NULL,
							int nPiority = THREAD_PRIORITY_NORMAL,
							bool bSuspended = false)
		{
			assert(!bSuspended || pHndl);// Thread will never start if suspended and no returned hanle
			DWORD dwId = 0;

			arg a(pFunc);
			HANDLE hThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)ThreadFunc,
							&a,	bSuspended ? CREATE_SUSPENDED : 0, &dwId);

			WaitForSingleObject(a.m_hWait, INFINITE);
			CloseHandle(a.m_hWait);

			if(!bSuspended)
				SetThreadPriority(hThread, nPiority);

			if(pHndl)
				*pHndl = hThread;	// Return handle
			else if(hThread)
				CloseHandle(hThread);		// Close handle

			return !!hThread;
		}

		static bool Execute(FuncA pFunc,
							A argument,
							HANDLE* pHndl = NULL,
							int nPiority = THREAD_PRIORITY_NORMAL,
							bool bSuspended = false)
		{
			assert(!bSuspended || pHndl);// Thread will never start if suspended and no returned hanle
			DWORD dwId = 0;

			arg a(pFunc, argument);
			HANDLE hThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)ThreadFuncA,
							&a,	bSuspended ? CREATE_SUSPENDED : 0, &dwId);

			WaitForSingleObject(a.m_hWait, INFINITE);
			CloseHandle(a.m_hWait);

			if(!bSuspended)
				SetThreadPriority(hThread, nPiority);

			if(pHndl)
				*pHndl = hThread;	// Return handle
			else if(hThread)
				CloseHandle(hThread);		// Close handle

			return !!hThread;
		}
	private:
		static DWORD ThreadFunc(void* pArg)
		{
			arg a = *reinterpret_cast<arg*>(pArg);
			SetEvent(a.m_hWait);
			(*a.m_pFunc)();
			return 0;
		}

		static DWORD ThreadFuncA(void* pArg)
		{
			arg a = *reinterpret_cast<arg*>(pArg);
			SetEvent(a.m_hWait);
			(*a.m_pFuncA)(a.m_A);
			return 0;
		}
	};


	template <typename C, typename R = bool>
	class CXThreadExecute
	{
		typedef R (C::*Func)();
		struct arg
		{
			arg(C& rObj, Func pFunc) :
					m_rObj(rObj), m_pFunc(pFunc), m_hWait(CreateEvent(NULL, false, false, NULL))
			{}
			
			C&		m_rObj;
			Func	m_pFunc;
			HANDLE	m_hWait;
		};
	public:
		static bool Execute(C& obj, Func pFunc,
							HANDLE* pHndl = NULL,
							int nPiority = THREAD_PRIORITY_NORMAL,
							bool bSuspended = false)
		{
			assert(!bSuspended || pHndl);// Thread will never start if suspended and no returned hanle
			DWORD dwId = 0;

			arg a(obj, pFunc);
			HANDLE hThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)ThreadFunc,
							&a,	bSuspended ? CREATE_SUSPENDED : 0, &dwId);

			WaitForSingleObject(a.m_hWait, INFINITE);
			CloseHandle(a.m_hWait);

			if(!bSuspended)
				SetThreadPriority(hThread, nPiority);

			if(pHndl)
				*pHndl = hThread;	// Return handle
			else if(hThread)
				CloseHandle(hThread);		// Close handle

			return !!hThread;
		}

	private:
		static DWORD ThreadFunc(void* pArg)
		{
			arg a = *reinterpret_cast<arg*>(pArg);
			SetEvent(a.m_hWait);
			try
			{
				(a.m_rObj.*a.m_pFunc)();
			}
			catch(...)
			{}
			return 0;
		}
	};

	//
	template <typename C, typename A, typename R = bool>
	class CXThreadExecuteArg
	{
		typedef R (C::*Func)(A arg);
		struct arg
		{
			arg(C& rObj, Func pFunc, A arg) :
					m_rObj(rObj),
					m_pFunc(pFunc),
					m_rA(arg),
					m_hWait(CreateEvent(NULL, false, false, NULL))
			{}
			
			C&		m_rObj;
			Func	m_pFunc;
			A		m_rA;
			HANDLE	m_hWait;
		};
	public:
		static bool Execute(C& obj, Func pFunc, A argument,
							HANDLE* pHndl = NULL,
							int nPiority = THREAD_PRIORITY_NORMAL,
							bool bSuspended = false)
		{
			assert(!bSuspended || pHndl);// Thread will never start if suspended and no returned hanle
			DWORD dwId = 0;

			arg a(obj, pFunc, argument);
			HANDLE hThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)ThreadFunc,
							&a,	bSuspended ? CREATE_SUSPENDED : 0, &dwId);

			WaitForSingleObject(a.m_hWait, INFINITE);
			CloseHandle(a.m_hWait);

			if(!bSuspended)
				SetThreadPriority(hThread, nPiority);

			if(pHndl)
				*pHndl = hThread;	// Return handle
			else if(hThread)
				CloseHandle(hThread);		// Close handle

			return !!hThread;
		}

	private:
		static DWORD ThreadFunc(void* pArg)
		{
			arg a = *reinterpret_cast<arg*>(pArg);
			SetEvent(a.m_hWait);
			(a.m_rObj.*a.m_pFunc)(a.m_rA);
			return 0;
		}
	};

	template <typename C, typename A, typename R = bool>
	class CXThreadExecuteRefArg
	{
		typedef R (C::*Func)(A& arg);
		struct arg
		{
			arg(C& rObj, Func pFunc, A& arg) :
					m_rObj(rObj),
					m_pFunc(pFunc),
					m_hWait(CreateEvent(NULL, false, false, NULL))
			{}
			
			C&		m_rObj;
			Func	m_pFunc;
			A&		m_rArg;
			HANDLE	m_hWait;
		};
	public:
		static bool Execute(C& obj, Func pFunc, A& arg,
							HANDLE* pHndl = NULL,
							int nPiority = THREAD_PRIORITY_NORMAL,
							bool bSuspended = false)
		{
			assert(!bSuspended || pHndl);// Thread will never start if suspended and no returned hanle
			DWORD dwId = 0;

			arg a(obj, arg, pFunc);
			HANDLE hThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)ThreadFunc,
							&a,	bSuspended ? CREATE_SUSPENDED : 0, &dwId);

			WaitForSingleObject(a.m_hWait, INFINITE);
			CloseHandle(a.m_hWait);

			if(!bSuspended)
				SetThreadPriority(hThread, nPiority);

			if(pHndl)
				*pHndl = hThread;	// Return handle
			else if(hThread)
				CloseHandle(hThread);		// Close handle

			return !!hThread;
		}

	private:
		static DWORD ThreadFunc(void* pArg)
		{
			arg a = *reinterpret_cast<arg*>(pArg);
			SetEvent(a.m_hWait);
			(a.m_rObj.*a.m_pFunc)(a.m_rArg);
			return 0;
		}
	};
}

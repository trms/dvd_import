//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//	Copyright (C) 2003 AMMTools. All rights reserved.
//	http://www.ammtools.com mailto:support@ammtools.com

#pragma once

#include <windows.h>
#include <tchar.h>
#include <stdio.h>
#include <errors.h>
#include <assert.h>
#include <stdexcept>
#include "XUString.h"

namespace XU
{
	static LPCTSTR StrStdExc()
	{
		return _T("std::exception");
	}

	#if  defined(_DEBUG) || defined(DEBUG)
		
		#define	DBG_XTRY	try{

		#define DBG_XCATCH }\
			catch(XU::CW32Exc& e){e.DbgOut()} \
			catch(...){}

		#define DBG_XCATCH_THROW(tcsMsg) }\
			catch(XU::CW32Exc&){throw;} \
			catch(...){throw XU::CW32Exc(tcsMsg);}

		#define DBG_XCATCH_MSG }\
			catch(XU::CW32Exc& e){e.DbgMsgBox(); e.DbgOut();} \
			catch(std::exception& e){hr = E_FAIL;	XU::CW32Exc ee(XU::StrStdExc(), e); ee.DbgMsgBox();}\
			catch(...){hr = E_FAIL; XU::CW32Exc ee(_T("Unknown exception"), hr); ee.DbgMsgBox();}

		#define DBG_XCATCH_HR(hr) }\
			catch(XU::CW32Exc& e){hr = e; e.DbgOut();} \
			catch(...){hr = E_FAIL;}

		#define DBG_XCATCH_HR_MSG(hr) }\
			catch(XU::CW32Exc& e){hr = e; e.DbgMsgBox(); e.DbgOut();} \
			catch(std::exception& e){hr = E_FAIL;	XU::CW32Exc ee(XU::StrStdExc(), e); ee.DbgMsgBox();}\
			catch(...){hr = E_FAIL; XU::CW32Exc ee(_T("Unknown exception"), hr); ee.DbgMsgBox();}

	#else  // _DEBUG
		
		#define	DBG_XTRY	
		#define DBG_XCATCH 
		#define DBG_XCATCH_THROW(tcsMsg)
		#define DBG_XCATCH_MSG 
		#define DBG_XCATCH_HR(hr) 
		#define DBG_XCATCH_HR_MSG(hr) 
	#endif // _DEBUG


	#define XTRY try{
	#define XCATCH }\
		catch(XU::CW32Exc& e){e.DbgOut();} \
		catch(std::exception& e){XU::CW32Exc ee(XU::StrStdExc(), e); ee.DbgOut();}\
		catch(...){}

	#define XCATCH_THROW(tcsMsg) }\
		catch(XU::CW32Exc&){throw;} \
		catch(std::exception& e){throw XU::CW32Exc(tcsMsg, e);}\
		catch(...){throw XU::CW32Exc(tcsMsg);}

	#define XCATCH_MSG }\
		catch(XU::CW32Exc& e){e.MsgBox(); e.DbgOut();} \
		catch(std::exception& e){XU::CW32Exc ee(XU::StrStdExc(), e); ee.MsgBox(); ee.DbgOut();}\
		catch(...){XU::CW32Exc ee(_T("Unknown exception"), E_FAIL); ee.MsgBox();}

	#define XCATCH_HR(hr) }\
		catch(XU::CW32Exc& e){hr = e;	e.DbgOut();}\
		catch(std::exception& e){hr = E_FAIL;	XU::CW32Exc ee(XU::StrStdExc(), e); ee.DbgOut();}\
		catch(...){hr = E_FAIL;}

	#define XCATCH_HR_MSG(hr) }\
		catch(XU::CW32Exc& e){hr = e;	e.MsgBox();}\
		catch(std::exception& e){hr = E_FAIL;	XU::CW32Exc ee(XU::StrStdExc(), e); ee.MsgBox();}\
		catch(...){hr = E_FAIL; XU::CW32Exc ee(_T("Unknown exception"), hr); ee.MsgBox();}

	/////////////////////////////////////////////////////////////
	// Exception classes

	// Base class
	class CXExc
	{
	public:
		CXExc(LPCTSTR tcsMessage):
						m_tcsText(tcsMessage),
						m_hrError(E_FAIL),
						m_bStd(false)
		{}

		CXExc(LPCTSTR tcsMessage, HRESULT hr):
						m_tcsText(tcsMessage),
						m_hrError(hr),
						m_bStd(false)
		{}

		CXExc(LPCTSTR tcsMessage, const std::exception& e) :
					m_tcsText(tcsMessage),
					m_hrError(E_FAIL),
					m_StdExc(e.what() ? e : std::exception("std unknown exception")),
					m_bStd(true)
		{}

		operator LPCTSTR	() const
		{
			return m_tcsText;
		}

		operator HRESULT	() const
		{
			return m_hrError;
		}

		operator const std::exception () const
		{
			return m_StdExc;
		}

		bool	IsStd() const
		{ 
			return m_bStd;
		}

		virtual bool		FormatMessage(CTString& sMessage) const
		{
			if(m_bStd)
			{
				LPTSTR tcsDest = NULL;
				try
				{
					if(m_StdExc.what())
					{
						tcsDest = new TCHAR[strlen(m_StdExc.what()) + _tcslen(m_tcsText) + 16];
						_stprintf(tcsDest, _T("%s\n(%s)\n"), m_tcsText, CTString(m_StdExc.what()));
						sMessage = tcsDest;
					}
					else
						sMessage = m_tcsText;
				}
				catch(...)
				{
					assert(false);
				}
				delete[] tcsDest;
				return true;
			}
			return false;
		}

	protected:
		LPCTSTR			m_tcsText;
		HRESULT			m_hrError;
		std::exception	m_StdExc;
		bool			m_bStd;
	};

	////////////////////////////////////////////////////////////
	// Exception class supporting debug output
	class CW32Exc : public CXExc
	{
	public:
		CW32Exc(LPTSTR tcsMessage) :
				CXExc(tcsMessage)
		{}

		CW32Exc(LPTSTR tcsMessage, HRESULT hr):
						CXExc(tcsMessage, hr)
		{}

		CW32Exc(LPCTSTR tcsMessage, DWORD dwWin32Code) :
					CXExc(tcsMessage,  HRESULT_FROM_WIN32(dwWin32Code))
		{}

		CW32Exc(LPCTSTR tcsMessage, const std::exception& e) :
					CXExc(tcsMessage,  e)
		{}

		//
		virtual void		DbgOut() const
		{
	#if  defined(_DEBUG) || defined(DEBUG)
			try
			{
				CTString sMessage;
				FormatMessage(sMessage);
				OutputDebugString(sMessage);
			}
			catch(...)
			{
				assert(false);
			}
	#endif // _DEBUG
		}

		virtual void		MsgBox() const
		{
	#ifndef	_NO_UI_
			try
			{
				CTString sMessage;
				if(FormatMessage(sMessage))
					MessageBox(NULL, sMessage, _T("Error!"), MB_OK|MB_ICONERROR);
				else
					MessageBox(NULL, sMessage, _T("Unknown Error!"), MB_OK|MB_ICONERROR);
			}
			catch(...)
			{
				assert(false);
			}
	#endif //	_NO_UI_
		}

		virtual void		DbgMsgBox()
		{
	#if  defined(_DEBUG) || defined(DEBUG)
			MsgBox();
	#endif // _DEBUG
		}

		virtual bool		FormatMessage(CTString& sMessage) const
		{
			if(CXExc::FormatMessage(sMessage))
				return true;

			bool bRet = false;
			LPTSTR lpszTemp = NULL,	tcsDest = NULL;
			try
			{
				bRet = !!::FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM|FORMAT_MESSAGE_IGNORE_INSERTS|FORMAT_MESSAGE_ALLOCATE_BUFFER, NULL, m_hrError, 0, (LPTSTR)&lpszTemp, 0, NULL);
				if(bRet && lpszTemp)
				{
					tcsDest = new TCHAR[_tcslen(lpszTemp) + _tcslen(m_tcsText) + 36];
					_stprintf(tcsDest, _T("%s\n(%s hr = 0x%x)\n"), m_tcsText, lpszTemp, m_hrError);
					sMessage = tcsDest;
				}
				else
					sMessage = m_tcsText;
			}
			catch(...)
			{
				assert(false);
				bRet = false;
			}
			if(lpszTemp)
				LocalFree(lpszTemp);
			delete [] tcsDest;

			return bRet;
		}
	};

	class CW32FileExc : public CW32Exc
	{
	public:
		CW32FileExc(LPCTSTR tcsMessage, LPCTSTR tcsFileName, DWORD dwWin32Code = GetLastError()) :
					CW32Exc(tcsMessage,  HRESULT_FROM_WIN32(dwWin32Code)),
					m_FileName(tcsFileName)
		{}

		CW32FileExc(LPCTSTR tcsMessage, LPCTSTR tcsFileName, HRESULT hr) :
					CW32Exc(tcsMessage,  hr),
					m_FileName(tcsFileName)
		{}

		virtual bool		FormatMessage(CTString& sMessage) const
		{
			bool bRet = true;
			LPTSTR lpszTemp = NULL,	tcsDest = NULL;
			try
			{
				bRet = !!::FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM|FORMAT_MESSAGE_IGNORE_INSERTS|FORMAT_MESSAGE_ALLOCATE_BUFFER, NULL, m_hrError, 0, (LPTSTR)&lpszTemp, 0, NULL);
				if(bRet && lpszTemp)
				{
					tcsDest = new TCHAR[_tcslen(lpszTemp) + _tcslen(m_tcsText) +
										m_FileName.length() + 48];
					_stprintf(tcsDest, _T("%s\nFile : %s \n"), m_tcsText, (LPCTSTR)m_FileName);
					_stprintf(tcsDest, _T("%s(%s hr = 0x%x)\n"), tcsDest, lpszTemp, m_hrError);
					sMessage = tcsDest;
				}
				else
					sMessage = CTString(m_tcsText) + CTString(_T("\n File: ")) + m_FileName;
			}
			catch(...)
			{
				assert(false);
				bRet = false;
			}
			if(lpszTemp)
				LocalFree(lpszTemp);
			delete [] tcsDest;

			return bRet;
		}

		LPCTSTR		GetFileName() const
		{
			return m_FileName;
		}
	protected:
		const CTString		m_FileName;
	};
}


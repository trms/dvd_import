//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//	Copyright (C) 2003 AMMTools. All rights reserved.
//	http://www.ammtools.com mailto:support@ammtools.com

#pragma once

#pragma warning (disable : 4786)

#include "XUSyncUtils.h"
#include <assert.h>
#include <list>

namespace XU
{
	template <typename R>
	class CXCommand
	{
	public:
		CXCommand() : m_bExecuted(false)
		{}
		virtual ~CXCommand()
		{}


		virtual void operator()()
		{
			Execute();
		}

		virtual void Execute() = 0;

		const R&	GetResult() const
		{
			return m_Result;
		}

		bool		IsExecuted() const
		{
			return m_bExecuted;
		}

	protected:
		R		m_Result;
		bool	m_bExecuted;
	};

	template <typename C>
	class CXCommandQueue
	{
	public:
		CXCommandQueue(CXEvent* pStopEvent = NULL) :
			m_NewCommand(true, true),
			m_Stop(true, false),
			m_refStop(pStopEvent ? *pStopEvent : m_Stop),
			m_bThreadActive(false)
		{
			m_hEvents[0] = m_NewCommand;
			m_hEvents[1] = m_refStop;
		}

		virtual ~CXCommandQueue()
		{}

		virtual bool	ProcessQueue()
		{
			m_bThreadActive = true;

			m_refStop.Reset();

			while(WaitCommand())
			{
				while(!m_Queue.empty())
				{
					Execute(*m_Queue.front());
					m_Queue.pop_front();
				}
				
				{
					CXAutoLock<CXCritSec> lock(m_CritSec);
					if(m_Queue.empty())
						m_NewCommand.Reset();
				}
			}
			m_bThreadActive = false;
			return true;
		}

		virtual void	Stop()
		{
			m_refStop.Set();
		}

		virtual void	AddCommand(C& command)
		{
			CXAutoLock<CXCritSec> lock(m_CritSec);
			m_Queue.push_back(&command);
//			if(m_Queue.size() == 1)
			m_NewCommand.Set();
		}

		virtual void	Purge()
		{
			CXAutoLock<CXCritSec> lock(m_CritSec);
			m_NewCommand.Reset();
			m_Queue.clear();
		}

		bool			IsThreadActive() const
		{
			return m_bThreadActive;
		}

	protected:
		virtual void	Execute(C& command)
		{
			command.Execute();
		}

		bool	WaitCommand() const
		{
			return WaitForMultipleObjects(2, m_hEvents, false, INFINITE) == 
					WAIT_OBJECT_0;
		}

		std::list<C*>		m_Queue;

		CXCritSec			m_CritSec;

		CXEvent				m_NewCommand;
		CXEvent				m_Stop;

		CXEvent&			m_refStop;

		bool				m_bThreadActive;

	private:
		mutable HANDLE		m_hEvents[2];
	};

	template <typename C, typename T>
	class CXCommandQueueCallback : public CXCommandQueue<typename C>
	{
	public:
		typedef void (T::*CallbackFunc)(const C& command);

		CXCommandQueueCallback(T& refObject, CallbackFunc pCallback, CXEvent* pStopEvent = NULL) : 
			CXCommandQueue<C>(pStopEvent),
			m_refObject(refObject),
			m_pCallback(pCallback)
		{
			assert(m_pCallback);	
		}

	protected:
		void	Execute(C& command)
		{
			try
			{
				command.Execute();
			}
			catch(...)
			{}
			(m_refObject.*m_pCallback)(command);
		}
		
		T&				m_refObject;
		CallbackFunc	m_pCallback;
	};

};


//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//	Copyright (C) 2003 AMMTools. All rights reserved.
//	http://www.ammtools.com mailto:support@ammtools.com


#pragma once
#include "XUNamedItem.h"
#include <algorithm>

namespace XU
{
	static CTString& XMLFormatString(CTString& str)
	{
		static const LPCTSTR tcsInvalidCharackters[] = {_T("&"), _T("&amp;"),
														_T("\""), _T("&quot;"),
														_T("<"), _T("&lt;"),
														_T(">"), _T("&gt;"),};
		static const size_t st = sizeof(tcsInvalidCharackters)/sizeof(LPCTSTR);
		size_t pos = -1;
		// Replace all ampersands first
		LPCTSTR pChar = str;
		size_t len = str.length(), lshift = 0;
		while(len)
		{
			pChar = str;
			pChar += lshift;
			if(*pChar == *tcsInvalidCharackters[0])
			{
				str.replace(pChar - str, 1, tcsInvalidCharackters[1]);
				lshift += 5;
//				len += 4;
			}
			else
			{
				if((unsigned char)*pChar < 32)
					*const_cast<LPSTR>(pChar) = '?';
				++ lshift;
			}
			-- len;
		}
		// Replace other chars
		for(int n = 2; n < st; n += 2)
			while((pos = str.find(tcsInvalidCharackters[n])) != -1)
				str.replace(pos, 1, tcsInvalidCharackters[n + 1]);
		return str;
	}


	static CTString& FormatStringFromXML(CTString& str)
	{
		static const LPCTSTR tcsInvalidCharackters[] = { _T("&amp;"),  _T("&"),
														 _T("&quot;"), _T("\""),
														 _T("&lt;"),   _T("<"),
														 _T("&gt;"),   _T(">")};
		static const size_t st = sizeof(tcsInvalidCharackters)/sizeof(LPCTSTR);
		// Replace other chars
		for(size_t n = 0, pos = 0; n < st; n += 2)
			while((pos = str.find(tcsInvalidCharackters[n])) != -1)
				str.replace(pos, _tcslen(tcsInvalidCharackters[n]),
							tcsInvalidCharackters[n + 1]);
		return str;
	}

	////////////////////////////////////////////////////////////////
	//
	template<typename T>
	class CXMLParam : public CItem<T>
	{
	public:
		CXMLParam(LPCTSTR tcsName, const T& t) :
				CItem<T>(tcsName, t)
		{}

		CXMLParam(const CXMLParam<T>& rParam) :
				CItem<T>(rParam)
		{}

		CTString&		Format(CTString& str, CXUSimpleBuffer& buff) const; // Need specification
	};

	/////////////////////////////////////////////////////////////////////
	// Specifications of CXMLParam::Format
		inline CTString& CXMLParam<CTString>::Format(CTString& str, CXUSimpleBuffer& buff) const
		{
			LPTSTR tcsTmp = (LPTSTR)buff.GetPtr(_tcslen(m_Name) + str.length() + 6 * m_Val.length() + 16);
			_stprintf(tcsTmp, _T("%s %s=\"%s\""), (LPCTSTR)str, m_Name, (LPCTSTR)XMLFormatString(const_cast<CTString&>(m_Val)));
			return str = tcsTmp;
		}

		inline CTString& CXMLParam<LPCTSTR>::Format(CTString& str, CXUSimpleBuffer& buff) const
		{
			LPTSTR tcsTmp = (LPTSTR)buff.GetPtr(_tcslen(m_Name) + str.length() + 6 * _tcslen(m_Val) + 16);
			CTString stmp(m_Val);
			_stprintf(tcsTmp, _T("%s %s=\"%s\""), (LPCTSTR)str, m_Name, (LPCTSTR)XMLFormatString(stmp));
			return str = tcsTmp;
		}

		inline CTString& CXMLParam<bool>::Format(CTString& str, CXUSimpleBuffer& buff) const
		{
			LPTSTR tcsTmp = (LPTSTR)buff.GetPtr(_tcslen(m_Name) + str.length() + 36);
			_stprintf(tcsTmp, _T("%s %s=\"%s\""), (LPCTSTR)str, m_Name,
												m_Val ? _T("true") : _T("false"));
			return str = tcsTmp;
		}

		inline CTString& CXMLParam<long>::Format(CTString& str, CXUSimpleBuffer& buff) const
		{
			LPTSTR tcsTmp = (LPTSTR)buff.GetPtr(_tcslen(m_Name) + str.length() + 36);
			_stprintf(tcsTmp, _T("%s %s=\"%ld\""), (LPCTSTR)str, m_Name, m_Val);
			return str = tcsTmp;
		}

		inline CTString& CXMLParam<ULONGLONG>::Format(CTString& str, CXUSimpleBuffer& buff) const
		{
			LPTSTR tcsTmp = (LPTSTR)buff.GetPtr(_tcslen(m_Name) + str.length() + 36);
			if(m_Val < 0XFFFFFFFF)
				_stprintf(tcsTmp, _T("%s %s=\"%u\""), (LPCTSTR)str, m_Name, (ULONG)m_Val);
			else
				_stprintf(tcsTmp, _T("%s %s=\"%u%u\""), (LPCTSTR)str, m_Name, (ULONG)(m_Val >> 32), (ULONG)(m_Val & 0XFFFFFFFF));
			return str = tcsTmp;
		}

		inline CTString& CXMLParam<double>::Format(CTString& str, CXUSimpleBuffer& buff) const
		{
			LPTSTR tcsTmp = (LPTSTR)buff.GetPtr(_tcslen(m_Name) + str.length() + 36);
			_stprintf(tcsTmp, _T("%s %s=\"%g\""), (LPCTSTR)str, m_Name, m_Val);
			return str = tcsTmp;
		}
	//////////////////////////////////////////////////////////////
	//
	template<typename T>
	class CXMLElement : public CItem<T>
	{
	public:
		CXMLElement(LPCTSTR tcsName, const T& t, int nLevel = 0) :
				CItem<T>(tcsName, t),
				m_Tabs(nLevel, '\t')
		{}

		CTString&		Format(CTString& str, CXUSimpleBuffer& buff) const; // Need specification

		CItemsList&		GetParams()
		{
			return m_Params;
		}
	
	protected:
		CTString			m_Tabs;
		mutable CItemsList	m_Params;
		CTString&	WriteParams(CTString& str, CXUSimpleBuffer& buff) const
		{
			CItemsList::iterator n;
			for(n = m_Params.begin(); n != m_Params.end(); n++)
				(*n)->Format(str, buff);
			return str;
		}
	};

	///////////////////////////////////////////////////////////
	// Specifications of CXMLElement::Format
		inline CTString& CXMLElement<void*>::Format(CTString& str, CXUSimpleBuffer& buff) const
		{
			CTString tmp;
			WriteParams(tmp, buff);
			LPTSTR tcsTmp = (LPTSTR)buff.GetPtr(_tcslen(m_Name) + m_Tabs.length() + str.length() + tmp.length() + 36);
			_stprintf(tcsTmp, _T("%s%s<%s%s/>\n"), (LPCTSTR)str, (LPCTSTR)m_Tabs, m_Name, (LPCTSTR)tmp);
			return str = tcsTmp;
		}

		inline CTString& CXMLElement<CTString>::Format(CTString& str, CXUSimpleBuffer& buff) const
		{
			str += m_Tabs + CTString(_T("<")) + CTString(m_Name);
			WriteParams(str, buff);
			str += 	CTString(_T(">\n")) + m_Tabs + XMLFormatString(const_cast<CTString&>(m_Val)) +
							CTString(_T("\n")) + m_Tabs + CTString(_T("</")) +
							CTString(m_Name) + CTString(_T(">\n"));
			return str;
		}

		inline CTString& CXMLElement<bool>::Format(CTString& str, CXUSimpleBuffer& buff) const
		{
			str += m_Tabs + CTString(_T("<")) + CTString(m_Name);
			WriteParams(str, buff);
			str += CTString(_T(">\n")) + m_Tabs + 
				(m_Val ? CTString(_T("true")) : CTString(_T("false"))) +
				m_Tabs + CTString(_T("</")) + CTString(m_Name) + CTString(_T(">\n"));
			return str;
		}

		inline CTString& CXMLElement<long>::Format(CTString& str, CXUSimpleBuffer& buff) const
		{
			LPTSTR tcsTmp = (LPTSTR)buff.GetPtr(str.length() + _tcslen(m_Name) + m_Tabs.length() + 16);
			_stprintf(tcsTmp, _T("%s%s<%s"), str, m_Tabs, m_Name);
			str = tcsTmp;
			WriteParams(str, buff);
			tcsTmp = (LPTSTR)buff.GetPtr(str.length() + _tcslen(m_Name) + 2 * m_Tabs.length() + 36);
			_stprintf(tcsTmp, _T("%s>\n%s%ld\n%s</%s>\n"), str, m_Tabs, m_Val, m_Tabs, m_Name);
			return str = tcsTmp;
		}
	//////////////////////////////////////////////////////////////////
	//
	class CXMLCompositeElement : public AItem
	{
	public:
		CXMLCompositeElement(LPCTSTR tcsName, int nLevel = 0) :
				m_Name(tcsName),
				m_Tabs(nLevel, '\t')
		{}

		LPCTSTR		GetName() const
		{
			return m_Name;
		}

		VARTYPE			GetValueType()	const
		{
			return VT_RECORD;
		}

		CTString&		Format(CTString& str, CXUSimpleBuffer& buff) const
		{
			FormatOpenTag(str, buff);
			for(CItemsList::iterator n = m_SubItems.begin(); n != m_SubItems.end(); n++)
				(*n)->Format(str, buff);
			return FormatClosingTag(str, buff);
		}

		// Alternative format
		CTString&		FormatOpenTag(CTString& str, CXUSimpleBuffer& buff) const
		{
			CTString params;
			for(CItemsList::iterator n = m_Params.begin(); n != m_Params.end(); n++)
				(*n)->Format(params, buff);
			LPTSTR tcsTmp = (LPTSTR)buff.GetPtr(str.length() + _tcslen(m_Name) + m_Tabs.length() + params.length() + 36);
			_stprintf(tcsTmp, _T("%s%s<%s%s>\n"), (LPCTSTR)str, (LPCTSTR)m_Tabs, m_Name, (LPCTSTR)params);
			return str = tcsTmp;
		}

		CTString&		FormatClosingTag(CTString& str, CXUSimpleBuffer& buff) const
		{
			LPTSTR tcsTmp = (LPTSTR)buff.GetPtr(_tcslen(m_Name) + m_Tabs.length() + str.length() + 36);
			_stprintf(tcsTmp, _T("%s%s</%s>\n"), (LPCTSTR)str, (LPCTSTR)m_Tabs, m_Name);
			return str = tcsTmp;
		}
		//

		CItemsList&		GetParams()
		{
			return m_Params;
		}

		CItemsList&		GetSubItems()
		{
			return m_SubItems;
		}
	protected:
		CTString				m_Tabs;
//		XU::CTString			m_Name;
		LPCTSTR					m_Name;
		mutable CItemsList		m_Params;
		mutable CItemsList		m_SubItems;
	};

}

//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//	Copyright (C) 2003 AMMTools. All rights reserved.
//	http://www.ammtools.com mailto:support@ammtools.com

#include "XUSyncUtils.h"

namespace XU
{
	// CXEvent
	CXEvent::CXEvent(const CXEvent& ev) : 
				m_hHandle(NULL),
				m_bManual(ev.m_bManual),
				m_tcsName(ev.m_tcsName ? m_tcsName = _tcsdup(ev.m_tcsName) : NULL)
	{
		if(!DuplicateHandle(NULL, ev, NULL, &m_hHandle, 0, false, DUPLICATE_SAME_ACCESS))
		{
			if(m_tcsName)
			{
				free((LPVOID)m_tcsName);
				m_tcsName = NULL;
			}
			throw HRESULT_FROM_WIN32(GetLastError());
		}
	}
	// operator =() throws HRESULT if failed to duplicate handle
	CXEvent& CXEvent::operator =(const CXEvent& ev)
	{
		if(&ev != this)
		{
			// Destroy previos object
			CloseHandle(m_hHandle);
			m_hHandle = NULL;
			if(m_tcsName)
			{
				free((LPVOID)m_tcsName);
				m_tcsName = NULL;
			}

			// Try to ge dublicate of the handle
			if(!DuplicateHandle(NULL, ev, NULL, &m_hHandle, 0, false, DUPLICATE_SAME_ACCESS))
				throw HRESULT_FROM_WIN32(GetLastError());

			
			if(ev.m_tcsName)
				m_tcsName = _tcsdup(ev.m_tcsName);

			m_bManual = ev.m_bManual;
		}
		return *this;
	}

	// CXMutex
	CXMutex::CXMutex(const CXMutex& mutex) : 
				m_hHandle(NULL),
				m_tcsName(mutex.m_tcsName ? m_tcsName = _tcsdup(mutex.m_tcsName) : NULL)
	{
		if(!DuplicateHandle(NULL, mutex, NULL, &m_hHandle, 0, false, DUPLICATE_SAME_ACCESS))
		{
			if(m_tcsName)
			{
				free((LPVOID)m_tcsName);
				m_tcsName = NULL;
			}
			throw HRESULT_FROM_WIN32(GetLastError());
		}
	}
	// Operator =() throws HRESULT if failed to duplicate handle
	CXMutex& CXMutex::operator =(const CXMutex& mutex)
	{
		if(&mutex != this)
		{
			// Destroy previos object
			CloseHandle(m_hHandle);
			m_hHandle = NULL;
			if(m_tcsName)
			{
				free((LPVOID)m_tcsName);
				m_tcsName = NULL;
			}

			// Try to ge dublicate of the handle
			if(!DuplicateHandle(NULL, mutex, NULL, &m_hHandle, 0, false, DUPLICATE_SAME_ACCESS))
				throw HRESULT_FROM_WIN32(GetLastError());

			if(mutex.m_tcsName)
				m_tcsName = _tcsdup(mutex.m_tcsName);
		}
		return *this;
	}

}

//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//	Copyright (C) 2003 AMMTools. All rights reserved.
//	http://www.ammtools.com mailto:support@ammtools.com

#pragma once

#include <windows.h>
#include <tchar.h>
#include <stdio.h>

namespace XU
{
	#if  defined(_DEBUG) || defined(DEBUG)
	
		static void ExcTrace(LPCTSTR lpszFormat, ...)
		{
			va_list args;
			va_start(args, lpszFormat);

			int nBuf;
			TCHAR szBuffer[512];

			nBuf = _vsntprintf(szBuffer, sizeof(szBuffer), lpszFormat, args);

			OutputDebugString(szBuffer);
			va_end(args);
		}
	
	#else // defined(_DEBUG) || defined(DEBUG)

		static void ExcTrace(LPCTSTR lpszFormat, ...)
		{}

	#endif // defined(_DEBUG) || defined(DEBUG)

	#define XU_TRACE XU::ExcTrace
}

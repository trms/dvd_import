//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//	Copyright (C) 2003 AMMTools. All rights reserved.
//	http://www.ammtools.com mailto:support@ammtools.com

#pragma once
#include "XUExc.h"
#include <algorithm>

namespace XU
{
	static CTString GetCurrentDirectory()
	{
		DWORD st = ::GetCurrentDirectory(0, NULL) + 16;
		LPTSTR tcs = new TCHAR[st];
		::GetCurrentDirectory(st, tcs);
		_tcscat(tcs, _T("\\"));
		CTString sDir = tcs;
		delete [] tcs; 

		return sDir;
	}

	static CTString GetFileExtention(const CTString& sFileName)
	{
		CTString::size_type n = sFileName.rfind(_T("."));
		CTString sExt = (n == XU::CTString::npos || n == sFileName.length() -  1) ?
			_T("") : sFileName.substr(n + 1);
		if(!sExt.empty())
			_tcslwr(const_cast<TCHAR*>(sExt.c_str()));
		return sExt;
	}

	static void GetFilePath(LPCTSTR tcsFileName, CTString& sPath)
	{
		DWORD nLen = GetFullPathName(tcsFileName, 0, NULL, NULL);
		LPTSTR tsPath = new TCHAR[nLen], lpName = NULL;
		if(GetFullPathName(tcsFileName, nLen, tsPath, &lpName))
			sPath = tsPath;
		delete [] tsPath;
	}

	static CTString GetFilePath(LPCTSTR tcsFileName)
	{
		DWORD nLen = GetFullPathName(tcsFileName, 0, NULL, NULL);
		LPTSTR tsPath = new TCHAR[nLen], lpName = NULL;
		XU::CTString sPath;
		if(GetFullPathName(tcsFileName, nLen, tsPath, &lpName))
		{
			*lpName = 0;
			sPath = tsPath;
		}
		delete [] tsPath;
		return sPath;
	}

	static CTString GetFileName(const CTString& sFilePath)
	{
		CTString::size_type n = sFilePath.rfind(_T("\\"));
		return XU::CTString ((n == XU::CTString::npos || n == sFilePath.length() -  1) ?
								sFilePath : sFilePath.substr(n + 1));
	}

	static CTString GetOnlyFileName(const CTString& sFilePath)
	{
		CTString::size_type n = sFilePath.rfind(_T("\\"));
		CTString str((n == XU::CTString::npos || n == sFilePath.length() -  1) ?
				sFilePath : sFilePath.substr(n + 1));
		n = str.rfind(_T("."));
		str = (n == XU::CTString::npos || n == str.length() -  1) ?
					str : str.substr(0, n);

		return str;
	}

	static CTString MakeFullPath(LPCTSTR tcsPath, LPCTSTR tcsFileName)
	{
		TCHAR ch = tcsPath[_tcslen(tcsPath) - 1], ch1 = tcsFileName[0];
		return (ch == '\\' || ch == '/' ||
			ch1 == '\\' || ch1 == '/') ?
			(CTString(tcsPath) + CTString(tcsFileName)) :
			(CTString(tcsPath) +  CTString("\\") +
								CTString(tcsFileName));
	}

	static CTString& RemoveLastSlash(CTString& str)
	{
		size_t nLen = str.length();
		while(nLen && 
			(str[nLen - 1] == '/' ||
			str[nLen - 1] == '\\'))
		{
			str.resize(nLen - 1);
			nLen = str.length();
		}
		return str;
	}

	static CTString RemoveLastSlash(LPCTSTR tcsPath)
	{
		if(!_tcslen(tcsPath))
			return CTString();
		CTString str(tcsPath);
		RemoveLastSlash(str);
		return str;
	}

	inline CTString& NormalizeWinPath(CTString& str)
	{
		std::replace(str.begin(), str.end(), '/', '\\');
		return str;
	}

	inline CTString NormalizeWinPath(LPCTSTR tcsPath)
	{
		CTString str(tcsPath);
		std::replace(str.begin(), str.end(), '/', '\\');
		return str;
	}

	static CTString& NormalizeUrlPath(CTString& str)
	{
		std::replace(str.begin(), str.end(), '\\', '/');
		if(str.length() > 2 && (str.at(0) == '/') && (str.at(1) == '/'))
		{
			str.at(0) = '\\';
			str.at(1) = '\\';
		}
		return str;
	}

	static CTString NormalizeUrlPath(LPCTSTR tcsPath)
	{
		CTString str(tcsPath);
		std::replace(str.begin(), str.end(), '\\', '/');
		if(str.length() > 2 && (str.at(0) == '/') && (str.at(1) == '/'))
		{
			str.at(0) = '\\';
			str.at(1) = '\\';
		}
		return str;
	}


	enum path_type
	{
		pathInvalid,
		pathUnknown,
		pathRelative,
		pathUNC,
		pathURL,
		pathDrive
	};

	static path_type GetPathType(LPCTSTR tcsPath)
	{
		size_t nLen = _tcslen(tcsPath);
		if(nLen == 1 &&	tcsPath[0] == '.')
			return pathRelative;

		if((nLen == 2) &&
			((tcsPath[0] == '.' && tcsPath[1] == '.') ||
			(tcsPath[0] == '/' && tcsPath[1] == '.') ||
			(tcsPath[0] == '\\' && tcsPath[1] == '.') ||
			(tcsPath[0] == '.' && tcsPath[1] == '/') ||
			(tcsPath[0] == '.' && tcsPath[1] == '\\')))
			return pathRelative;

		if(nLen < 3)
			return pathInvalid;

		// If starts with DriveLetter:/
		if(tcsPath[1] == ':' &&
			(tcsPath[2] == '\\' || tcsPath[2] == '/'))
			return pathDrive;
		// If //ServerName
		if((tcsPath[0] == '/' && tcsPath[1] == '/') ||
			(tcsPath[0] == '\\' && tcsPath[1] == '\\'))
			return pathUNC;

		// Relative path
		if((tcsPath[0] == '.' && tcsPath[1] == '.') ||
			(tcsPath[0] == '/' || tcsPath[0] == '\\'))
			return pathRelative;

		// Try to find somethng like server.com/pth
		CTString str(tcsPath);
		size_t n = str.find_first_of(_T("\\/"));
		if(n != - 1)
		{
			str.resize(n);
			return str.find('.') != -1 ? pathURL : pathRelative;
		}
		return pathUnknown;
	}

	static bool GetMutualPathRoot(LPCTSTR tcsPath1, LPCTSTR tcsPath2,
								CTString* pRoot = NULL, CTString* pTail1 = NULL,
								CTString* pTail2 = NULL)
	{
		if(!_tcslen(tcsPath1))
			return false;
		CTString sPath1(tcsPath1), sPath2(tcsPath2), sRoot, sTail1, sTail2;

		TCHAR tch = sPath1.at(sPath1.length() - 1);
		if(tch != '\\' || tch != '/')
			sPath1.append(_T("\\"));
		tch = sPath2.at(sPath2.length() - 1);
		if(tch != '\\' || tch != '/')
			sPath2.append(_T("\\"));

		for(size_t n = 0, nLen = min(sPath1.length(), sPath2.length());
															n < nLen; n++)
			if(sPath1[n] != sPath2[n])
				break;
			else if(sPath1[n] == '\\' || sPath1[n] == '/')
			{
				sRoot = tcsPath1;
				sRoot.resize(n);
				sTail1	= &tcsPath1[n];
				sTail2	= &tcsPath2[n]; 
			}

		if(pRoot)
			*pRoot = sRoot;
		if(pTail1)
			*pTail1 = sTail1;
		if(pTail2)
			*pTail2 = sTail2;

		return !sRoot.empty();
	}

	static int GetPathLevels(LPCTSTR tcsPath)
	{
		CTString str(tcsPath);

		std::replace(str.begin(), str.end(), '/', '\\');
		while((!str.empty()) && str.at(0) == '\\')
			str.erase(0, 1);
		while((!str.empty()) && str.at(str.length() - 1) == '\\')
			str.resize(str.length() - 1);

		return str.empty() ?
				0 : (int)std::count(str.begin(), str.end(), '\\') + 1;
	}

	static bool GoUpByPath(CTString& sPath, size_t nLevels)
	{
		size_t nPos = sPath.find_last_of(_T("\\/"));
		while(nLevels && nPos != -1)
		{
			sPath.resize(nPos);
			nPos = sPath.find_last_of(_T("\\/"));
			-- nLevels;
		}
		if(nLevels == 1 && !sPath.empty())
		{
			sPath.clear();
			nLevels = 0;
		}
		
		return nLevels == 0;
	}

	/////////////////////////////////////////////////////////////////////////////
	//
	static bool CheckDirectoryExisists(LPCTSTR tcsPath)
	{
		DWORD dw = GetFileAttributes(tcsPath);
		return (dw != INVALID_FILE_ATTRIBUTES) && (dw & FILE_ATTRIBUTE_DIRECTORY);
	}

	static bool CheckCanOpenFile(LPCTSTR tcsFileName, DWORD dwAccess = GENERIC_READ,
														DWORD dwCreateDispos = OPEN_EXISTING,
														DWORD dwShareMode = 0,
														LPSECURITY_ATTRIBUTES lpSecAttr = NULL)
	{
		HANDLE hFile = CreateFile(tcsFileName, dwAccess, dwShareMode,
								lpSecAttr, dwCreateDispos, FILE_ATTRIBUTE_NORMAL, NULL);
		if(hFile == INVALID_HANDLE_VALUE)
			return false;

		CloseHandle(hFile);
		return true;
	}

	static void XUCreateDirectory(LPCTSTR tcsDirName)
	{
		CTString sDir = RemoveLastSlash(NormalizeWinPath(tcsDirName));
		if(sDir.length() < 2)
			throw XU::CW32FileExc(_T("Directory name too short."), sDir);
		if(sDir.length() == 2 && sDir.at(1) == ':')
			return;
		if(!((sDir.at(1) == ':' &&  sDir.at(2) == '\\') || (sDir.at(0) == '\\' && sDir.at(1) == '\\')))
			throw XU::CW32FileExc(_T("Directory name is not local or UNC path"), sDir);

		CTString sCurPath;
		if(sDir.at(1) == ':')
		{
			sCurPath = sDir.substr(0, 3);
			sDir = sDir.substr(3, sDir.length() - 1);
		}
		else if(sDir.at(1) == '\\')
		{
			sCurPath = sDir.substr(0, 2);
			sDir = sDir.substr(2, sDir.length() - 1);
			size_t nPos = sDir.find('\\');
			if(nPos == -1)
				throw XU::CW32FileExc(_T("Directory name is not completed."), tcsDirName);
			sCurPath += sDir.substr(0, nPos + 1);
			sDir = sDir.substr(nPos + 1, sDir.length() - 1);
		}
		size_t nPos = sDir.find('\\');
		while(true)
		{
			if(nPos != -1)
			{
				sCurPath += sDir.substr(0, nPos + 1);
				sDir = sDir.substr(nPos + 1, sDir.length() - 1);
			}
			else
				sCurPath += sDir;

			if(!CreateDirectory(sCurPath, NULL))
			{
				DWORD dwError = GetLastError();
				if(dwError != ERROR_ALREADY_EXISTS)
					throw XU::CW32FileExc(_T("Unable to create directory."), tcsDirName);
			}

			if(nPos == -1)
				break;

			nPos = sDir.find('\\');
		}
	}

	static HANDLE XUCreateFile(LPCTSTR tcsFileName, DWORD dwAccess = GENERIC_READ,
								DWORD dwCreateDispos = OPEN_EXISTING,
								DWORD dwShareMode = 0,
								LPSECURITY_ATTRIBUTES lpSecAttr = NULL)
	{
		CTString sDir = GetFilePath(tcsFileName);
		if(!sDir.empty())
			XUCreateDirectory(sDir);

		HANDLE hFile = CreateFile(tcsFileName, dwAccess, dwShareMode,
								lpSecAttr, dwCreateDispos, FILE_ATTRIBUTE_NORMAL, NULL);
		if(hFile == INVALID_HANDLE_VALUE)
			throw CW32FileExc(_T("Unable to open file"), tcsFileName);
		return hFile;
	}

	static ULONGLONG	XUGetFileSize(LPCTSTR tcsFilePath)
	{
		HANDLE hFile = CreateFile(tcsFilePath, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
								NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
		if(hFile == INVALID_HANDLE_VALUE)
			return 0;

		LARGE_INTEGER li;
		li.LowPart = GetFileSize(hFile, (LPDWORD)&li.HighPart);

		CloseHandle(hFile);

		return li.QuadPart;
	}

	static CTString& FixFileName(CTString& sFileName)
	{
		static const TCHAR tcsForbiden[] = {'\\', '/', '?',
											'*', ':', '<',
											'>', '\"', '|'};
		static const size_t st = sizeof(tcsForbiden)/sizeof(TCHAR);
		for(size_t n = 0; n < sFileName.length(); n ++)
			for(size_t f = 0; f < st; f ++)
				if(sFileName[n] == tcsForbiden[f])
					sFileName[n] = '_';

		return sFileName;
	}
}
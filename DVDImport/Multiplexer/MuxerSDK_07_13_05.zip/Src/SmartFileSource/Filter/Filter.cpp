#include <streams.h>

#include "Filter.h"

using namespace SFIO;

CSourceFilter::~CSourceFilter()
{
}

STDMETHODIMP  CSourceFilter::NonDelegatingQueryInterface(REFIID riid, void **ppv)
{
    if (riid == IID_IFileSourceFilter)
        return GetInterface((IFileSourceFilter *)this, ppv);
    if (riid == IID_IPlayList)
        return GetInterface((IPlayList *)this, ppv);
	return CSource::NonDelegatingQueryInterface(riid, ppv);
}

////////////////////////////////////////////////////////////
// CBaseFilter
//  IFileSourceFilter methods
//  Load a (new) file
STDMETHODIMP  CSourceFilter::Load(LPCOLESTR lpwszFileName, const AM_MEDIA_TYPE *pmt)
{
    CheckPointer(lpwszFileName, E_POINTER);
    CAutoLock lck(&m_csFilter);

	HRESULT hr = m_Stream.m_Files.Add(lpwszFileName, 0);
	if(FAILED(hr))
	{
		m_sFileName.clear();
		return hr;
	}

    //  Check the file type
    CMediaType cmt;
    if(!pmt) 
	{
        cmt.SetType(&MEDIATYPE_Stream);
        cmt.SetSubtype(&MEDIASUBTYPE_NULL);
    } 
	else 
        cmt = *pmt;


    m_sFileName = lpwszFileName;

    // this is not a simple assignment... pointers and format
    // block (if any) are intelligently copied
    m_mt = cmt;

    //  Work out file type
    cmt.bTemporalCompression = TRUE;	       //???
    cmt.lSampleSize = 1;
    return S_OK;
}

// Modeled on IPersistFile::Load
// Caller needs to CoTaskMemFree or equivalent.
STDMETHODIMP  CSourceFilter::GetCurFile(LPOLESTR * ppszFileName, AM_MEDIA_TYPE *pmt)
{
    CheckPointer(ppszFileName, E_POINTER);
    *ppszFileName = NULL;

    if(!m_sFileName.empty())
	{
        DWORD n = sizeof(WCHAR)*(1 + lstrlenW(m_sFileName));
        *ppszFileName = (LPOLESTR) CoTaskMemAlloc( n );
        if(*ppszFileName)
                CopyMemory(*ppszFileName, (LPCWSTR)m_sFileName, n);
    }
    if(pmt)
        CopyMediaType(pmt, &m_mt);
    return S_OK;
}


// IPlayList impl
STDMETHODIMP   CSourceFilter::GeFlags(/*[out]*/ DWORD* pdwFlags)
{
	return E_NOTIMPL;
}

STDMETHODIMP   CSourceFilter::SetFlags(/*[in]*/ DWORD dwFlags)
{
	return E_NOTIMPL;
}

STDMETHODIMP   CSourceFilter::Count(/*[out]*/ ULONG* pulCount)
{
	if(!pulCount)
		return E_POINTER;
	*pulCount = m_Stream.m_Files.size();
	return S_OK;
}

STDMETHODIMP   CSourceFilter::Insert(/*[in]*/ LPCWSTR wcsPath,
					/*[in]*/ ULONGLONG	ullFileSize, /*[in]*/ ULONG ulNumber)
{
	return m_Stream.m_Files.Add(wcsPath, ulNumber);
}

STDMETHODIMP   CSourceFilter::Remove(/*[in]*/ ULONG ulNumber)
{
	return E_NOTIMPL;
}

STDMETHODIMP   CSourceFilter::GetEntry(/*[in]*/ ULONG ulNumber,
						/*[out]*/PLAYLIST_ENTRY* pEntry)
{
	return E_NOTIMPL;
}

STDMETHODIMP   CSourceFilter::GetCurrEntry(/*[out]*/PLAYLIST_ENTRY* pEntry)
{
	return E_NOTIMPL;
}

STDMETHODIMP   CSourceFilter::MoveEntryTo(/*[in]*/ ULONG ulPosFrom, /*[in]*/ ULONG ulPosTo)
{
	return E_NOTIMPL;
}

STDMETHODIMP   CSourceFilter::RegisterCallback(/*[in]*/ IPlayListCallback* pCallback)
{
	return E_NOTIMPL;
}

STDMETHODIMP   CSourceFilter::UnRegisterCallback(/*[in]*/ IPlayListCallback* pCallback)
{
	return E_NOTIMPL;
}



#include <streams.h> 
#include <initguid.h>   // Make our GUID get defined
#include "../SmartFileSourceFltrGuids.h"

#pragma warning(disable:4710)  // 'function' not inlined (optimization)
#include "..\AsyncIO\AsyncIO.h"
#include "OutPin.h"
#include "Filter.h"

extern "C" BOOL WINAPI DllEntryPoint(HINSTANCE, ULONG, LPVOID);
BOOL APIENTRY DllMain(HANDLE hModule, 
                      DWORD  dwReason, 
                      LPVOID lpReserved)
{
	return DllEntryPoint((HINSTANCE)(hModule), dwReason, lpReserved);
}

// Setup data for filter registration
const AMOVIESETUP_MEDIATYPE sudOpPinTypes = {&MEDIATYPE_Stream, &MEDIASUBTYPE_NULL};

const AMOVIESETUP_PIN sudOpPin =
{ 
	L"Output",          // strName
	FALSE,              // bRendered
	TRUE,               // bOutput
	FALSE,              // bZero
	FALSE,              // bMany
	&CLSID_NULL,        // clsConnectsToFilter
	L"Input",           // strConnectsToPin
	1,                  // nTypes
	&sudOpPinTypes		// lpTypes
};

const AMOVIESETUP_FILTER sudAsync =
{
	&CLSID_AMMTSmartFileSource,     // clsID
	L"AMMT Smart File Source",	// strName
	MERIT_UNLIKELY ,            // dwMerit
	1,                          // nPins
	&sudOpPin                   // lpPin
};

//  Object creation template
CFactoryTemplate g_Templates[1] = 
{
    { L"AMMT SmartFileSource", &CLSID_AMMTSmartFileSource, CSourceFilter::CreateInstance, NULL, &sudAsync }
};

int g_cTemplates = sizeof(g_Templates) / sizeof(g_Templates[0]);

// Create a new instance of this class
CUnknown* CSourceFilter::CreateInstance(LPUNKNOWN pUnk, HRESULT *phr)
{
    return new CSourceFilter(pUnk, phr);
}

CSourceFilter::CSourceFilter(LPUNKNOWN pUnk, HRESULT *phr) :
    CSource(NAME("AMMT SourceFilter"), pUnk, CLSID_AMMTSmartFileSource),
    m_OutputPin(phr, this, &m_Io, &m_csFilter),
    m_Io(&m_Stream)
{}

//
// Filter registration functions
//
HRESULT DllRegisterServer()
{
    return AMovieDllRegisterServer2(TRUE);
}

HRESULT DllUnregisterServer()
{
    return AMovieDllRegisterServer2(FALSE);
}


#include "..\AsyncIO\AsyncIO.h"
#include "OutPin.h"
#include "Filter.h"

//CSourceOutputPin implementation
CSourceOutputPin::CSourceOutputPin(HRESULT * phr,  CSourceFilter *pReader,
								CAsyncIo *pIo, CCritSec * pLock): 
			CSourceStream(NAME("Async output pin"), phr, pReader, L"Output"),
			m_pReader(pReader),
			m_pIo(pIo),
			m_llPos(0),
			m_bQueriedForAsyncReader(false)
{}

CSourceOutputPin::~CSourceOutputPin()
{}

STDMETHODIMP CSourceOutputPin::NonDelegatingQueryInterface(REFIID riid, void** ppv)
{
    CheckPointer(ppv,E_POINTER);
    if (riid == IID_IAsyncReader) 
	{
        m_bQueriedForAsyncReader = true;
    	return GetInterface((IAsyncReader*) this, ppv);
    }
   	return CSourceStream::NonDelegatingQueryInterface(riid, ppv);
}

STDMETHODIMP CSourceOutputPin::Connect(IPin * pReceivePin, const AM_MEDIA_TYPE *pmt)
{
 //   return m_pReader->Connect(pReceivePin, pmt);
	HRESULT hr = m_bQueriedForAsyncReader ? 
				CBasePin::Connect(pReceivePin, pmt) :
				CSourceStream::Connect(pReceivePin, pmt);

	return hr;
}

HRESULT CSourceOutputPin::CheckConnect(IPin *pPin)
{
    HRESULT hr = CBasePin::CheckConnect(pPin);
    if(FAILED(hr))
		return hr;

    // get an input pin and an allocator interface
    hr = pPin->QueryInterface(IID_IMemInputPin, (void **) &m_pInputPin);
    return S_OK;
}

// See if it was asked for
HRESULT CSourceOutputPin::CompleteConnect(IPin *pReceivePin)
{
	HRESULT hr = m_bQueriedForAsyncReader ? 
			CBasePin::CompleteConnect(pReceivePin) :
			CSourceStream::CompleteConnect(pReceivePin);
	return hr;
}

HRESULT CSourceOutputPin::SetMediaType(const CMediaType *pType)
{
	return S_OK;
}


//  Remove our connection status
HRESULT CSourceOutputPin::BreakConnect()
{
    m_bQueriedForAsyncReader = false;
    return CSourceStream::BreakConnect();
}

HRESULT CSourceOutputPin::Active()
{
	return m_bQueriedForAsyncReader ? 
				CBasePin::Active() : 
				CSourceStream::Active();
}

HRESULT CSourceOutputPin::Inactive()
{
	return m_bQueriedForAsyncReader ? 
				CBasePin::Inactive() : 
				CSourceStream::Inactive();
}

HRESULT CSourceOutputPin::GetMediaType(int iPosition, CMediaType *pMediaType)
{
    if(iPosition < 0)
    	return E_INVALIDARG;
    if(iPosition > 0)
    	return VFW_S_NO_MORE_ITEMS;

    *pMediaType = *m_pReader->LoadType();
    return S_OK;
}

HRESULT CSourceOutputPin::CheckMediaType(const CMediaType* pType)
{
    CAutoLock lck(m_pLock);

	return S_OK;
    //  We treat MEDIASUBTYPE_NULL subtype as a wild card
    if ((m_pReader->LoadType()->majortype == pType->majortype) &&
	(m_pReader->LoadType()->subtype == MEDIASUBTYPE_NULL ||
         m_pReader->LoadType()->subtype == pType->subtype))
	    return S_OK;

    return S_FALSE;
}

HRESULT CSourceOutputPin::InitAllocator(IMemAllocator **ppAlloc)
{
    HRESULT hr = NOERROR;
    *ppAlloc = NULL;
    CMemAllocator *pMemObject = NULL;

    // Create a default memory allocator 
    pMemObject = new CMemAllocator(NAME("Base memory allocator"),NULL, &hr);
    if(!pMemObject)
    	return E_OUTOFMEMORY;

    if(FAILED(hr)) 
	{
	    delete pMemObject;
	    return hr;
    }

    // Get a reference counted IID_IMemAllocator interface
    if(FAILED(hr = pMemObject->QueryInterface(IID_IMemAllocator,(void **)ppAlloc)))
	{
	    delete pMemObject;
	    return E_NOINTERFACE;
    }

    ASSERT(*ppAlloc != NULL);
    return NOERROR;
}

// we need to return an addrefed allocator, even if it is the preferred
// one, since he doesn't know whether it is the preferred one or not.
STDMETHODIMP CSourceOutputPin::RequestAllocator(IMemAllocator* pPreferred,
					ALLOCATOR_PROPERTIES* pProps, IMemAllocator ** ppActual)
{
    // we care about alignment but nothing else
    if(!pProps->cbAlign || !m_pIo->IsAligned(pProps->cbAlign))
       m_pIo->Alignment(&pProps->cbAlign);

    ALLOCATOR_PROPERTIES Actual;
    HRESULT hr;
	if (pPreferred && 
		SUCCEEDED(hr = pPreferred->SetProperties(pProps, &Actual)) &&
		m_pIo->IsAligned(Actual.cbAlign)) 
	{
        pPreferred->AddRef();
    	*ppActual = pPreferred;
        return S_OK;
    }

    // create our own allocator
    IMemAllocator* pAlloc;
    if(FAILED(hr = InitAllocator(&pAlloc)))
        return hr;

    //...and see if we can make it suitable
    if (SUCCEEDED(hr = pAlloc->SetProperties(pProps, &Actual)) &&
				m_pIo->IsAligned(Actual.cbAlign)) 
	{	// we need to release our refcount on pAlloc, and addref
        // it to pass a refcount to the caller - this is a net nothing.
        *ppActual = pAlloc;
        return S_OK;
    }

    // failed to find a suitable allocator
    pAlloc->Release();

    // if we failed because of the IsAligned test, the error code will
    // not be failure
    if (SUCCEEDED(hr))
        hr = VFW_E_BADALIGN;
    return hr;
}

// queue an aligned read request. call WaitForNext to get
// completion.
STDMETHODIMP CSourceOutputPin::Request(IMediaSample* pSample, DWORD dwUser)
{
    REFERENCE_TIME tStart, tStop;
    HRESULT hr = pSample->GetTime(&tStart, &tStop);
    if(FAILED(hr))
    	return hr;

    LONGLONG llPos = tStart / UNITS;
    LONG lLength = (LONG) ((tStop - tStart) / UNITS);
    LONGLONG llTotal;
    LONGLONG llAvailable;

    hr = m_pIo->Length(&llTotal, &llAvailable);
    if (llPos + lLength > llTotal) 
	{
        // the end needs to be aligned, but may have been aligned
        // on a coarser alignment.
        LONG lAlign;
        m_pIo->Alignment(&lAlign);
        llTotal = (llTotal + lAlign -1) & ~(lAlign-1);

        if (llPos + lLength > llTotal) 
		{
            lLength = (LONG) (llTotal - llPos);

            // must be reducing this!
            ASSERT((llTotal * UNITS) <= tStop);
            tStop = llTotal * UNITS;
            pSample->SetTime(&tStart, &tStop);
        }
    }


    BYTE* pBuffer;
    if(FAILED(hr = pSample->GetPointer(&pBuffer)))
    	return hr;
    return m_pIo->Request(llPos, lLength, TRUE,
							pBuffer, (LPVOID)pSample, dwUser);
}

// sync-aligned request. just like a request/waitfornext pair.
STDMETHODIMP CSourceOutputPin::SyncReadAligned(IMediaSample* pSample)
{
    REFERENCE_TIME tStart, tStop;
    HRESULT hr = pSample->GetTime(&tStart, &tStop);
    if (FAILED(hr))
    	return hr;

    LONGLONG llPos = tStart / UNITS;
    LONG lLength = (LONG) ((tStop - tStart) / UNITS);
    LONGLONG llTotal;
    LONGLONG llAvailable;

    hr = m_pIo->Length(&llTotal, &llAvailable);
    if (llPos + lLength > llTotal)
	{	// the end needs to be aligned, but may have been aligned
        // on a coarser alignment.
        LONG lAlign;
        m_pIo->Alignment(&lAlign);
        llTotal = (llTotal + lAlign -1) & ~(lAlign-1);

        if (llPos + lLength > llTotal) 
		{
            lLength = (LONG) (llTotal - llPos);
            // must be reducing this!
            ASSERT((llTotal * UNITS) <= tStop);
            tStop = llTotal * UNITS;
            pSample->SetTime(&tStart, &tStop);
        }
    }


    BYTE* pBuffer;
    if (FAILED(hr = pSample->GetPointer(&pBuffer)))
    	return hr;

    LONG cbActual;
    hr = m_pIo->SyncReadAligned(llPos, lLength, pBuffer, &cbActual, pSample);
    pSample->SetActualDataLength(cbActual);
    return hr;
}


//
// collect the next ready sample
STDMETHODIMP CSourceOutputPin::WaitForNext(DWORD dwTimeout, IMediaSample** ppSample, DWORD * pdwUser)
{
    LONG cbActual;
    IMediaSample* pSample = NULL;
    HRESULT hr =  m_pIo->WaitForNext(dwTimeout,
			    (LPVOID*) &pSample, pdwUser, &cbActual);

    if(SUCCEEDED(hr))
        pSample->SetActualDataLength(cbActual);

    *ppSample = pSample;
    return hr;
}


//
// synchronous read that need not be aligned.
STDMETHODIMP CSourceOutputPin::SyncRead(
				LONGLONG llPosition,	// absolute Io position
				LONG lLength,  BYTE* pBuffer)
{
    return m_pIo->SyncRead(llPosition, lLength, pBuffer);
}

// return the length of the file, and the length currently
// available locally. We only support locally accessible files,
// so they are always the same
STDMETHODIMP CSourceOutputPin::Length(LONGLONG* pTotal, LONGLONG* pAvailable)
{
    HRESULT hr = m_pIo->Length(pTotal, pAvailable);
    return hr;
}

STDMETHODIMP CSourceOutputPin::BeginFlush(void)
{
    return m_pIo->BeginFlush();
}

STDMETHODIMP CSourceOutputPin::EndFlush(void)
{
    return m_pIo->EndFlush();
}


// CSource
HRESULT CSourceOutputPin::FillBuffer(IMediaSample* pSample)
{
    CheckPointer(pSample,E_POINTER);
    BYTE* pData = NULL;
    pSample->GetPointer(&pData);
    LONG lDataLen = pSample->GetSize(),
		cbActual = 0;

    HRESULT hr = m_pIo->SyncReadAligned(m_llPos, lDataLen, pData, &cbActual, pSample);
    pSample->SetActualDataLength(cbActual);
	m_llPos += cbActual;

	if(cbActual < lDataLen) 
	{
		m_llPos = 0;
//		rewind(fd);        // I doing this just to play the file in loop infinitely
	} 
	return S_OK;
}

// Ask for buffers of the size appropriate to the agreed media type
HRESULT CSourceOutputPin::DecideBufferSize(IMemAllocator *pIMemAlloc,
                            ALLOCATOR_PROPERTIES *pProperties)
{
	return S_OK;
}

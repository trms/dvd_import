#pragma once

#include "..\Stream\FileStream.h"
#include "..\AsyncIO\AsyncIO.h"
#include "..\SmartFileSourceFltrIfaces.h"
#include "OutPin.h"

class CSourceOutputPin;

class CSourceFilter : public CSource, public IFileSourceFilter, public IPlayList
{
public:
    CSourceFilter(LPUNKNOWN pUnk, HRESULT *phr);
    ~CSourceFilter();

    static CUnknown *CreateInstance(LPUNKNOWN pUnk, HRESULT *phr);
/*	{
		return new CSourceFilter(pUnk, phr);
	}
*/
    DECLARE_IUNKNOWN
    STDMETHODIMP NonDelegatingQueryInterface(REFIID riid, void **ppv);

    // Access our media type
    const CMediaType* LoadType() const
    {
        return &m_mt;
    }

    virtual HRESULT Connect(IPin* pReceivePin, const AM_MEDIA_TYPE *pmt)
    {
        return m_OutputPin.CBasePin::Connect(pReceivePin, pmt);
    }


    //  IFileSourceFilter methods
    //  Load a (new) file
    STDMETHODIMP Load(LPCOLESTR lpwszFileName, const AM_MEDIA_TYPE *pmt);
    // Modeled on IPersistFile::Load
    // Caller needs to CoTaskMemFree or equivalent.
    STDMETHODIMP GetCurFile(LPOLESTR * ppszFileName, AM_MEDIA_TYPE *pmt);

	// IPlayList
	STDMETHODIMP GeFlags(/*[out]*/ DWORD* pdwFlags);
	STDMETHODIMP SetFlags(/*[in]*/ DWORD dwFlags);
	STDMETHODIMP Count(/*[out]*/ ULONG* pulCount);
	STDMETHODIMP Insert(/*[in]*/ LPCWSTR wcsPath,
						/*[in]*/ ULONGLONG	ullFileSize, /*[in]*/ ULONG ulNumber);
	STDMETHODIMP Remove(/*[in]*/ ULONG ulNumber);
	STDMETHODIMP GetEntry(/*[in]*/ ULONG ulNumber,
							/*[out]*/PLAYLIST_ENTRY* pEntry);
	STDMETHODIMP GetCurrEntry(/*[out]*/PLAYLIST_ENTRY* pEntry);
	STDMETHODIMP MoveEntryTo(/*[in]*/ ULONG ulPosFrom, /*[in]*/ ULONG ulPosTo);
	STDMETHODIMP RegisterCallback(/*[in]*/ IPlayListCallback* pCallback);
	STDMETHODIMP UnRegisterCallback(/*[in]*/ IPlayListCallback* pCallback);


private:
    BOOL CSourceFilter::ReadTheFile(LPCTSTR lpszFileName);

private:
    // filter-wide lock
    CCritSec			m_csFilter;
    // all i/o done here
    CAsyncIo			m_Io;
    // our output pin
    CSourceOutputPin	m_OutputPin;
    // Type we think our data is
    CMediaType			m_mt;

	//
	XU::CWString		m_sFileName;
    SFIO::CFileStream	m_Stream;
};

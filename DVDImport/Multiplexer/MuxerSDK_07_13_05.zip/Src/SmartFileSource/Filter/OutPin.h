
#pragma once

#include <streams.h>

class CSourceFilter;
class CAsyncIo;

// the output pin class
class CSourceOutputPin : public CSourceStream,
						public IAsyncReader
{
public:
    // constructor and destructor
    CSourceOutputPin(HRESULT* phr, CSourceFilter* pReader,
					CAsyncIo* pIo, CCritSec* pLock);
    ~CSourceOutputPin();

    // CUnknown
    // need to expose IAsyncReader
    DECLARE_IUNKNOWN
    STDMETHODIMP NonDelegatingQueryInterface(REFIID, void**);

    // IPin methods
    STDMETHODIMP Connect(IPin * pReceivePin, const AM_MEDIA_TYPE *pmt);

    // CBasePin methods
    // return the types we prefer - this will return the known
    // file type
    HRESULT GetMediaType(int iPosition, CMediaType *pMediaType);
    // can we support this type?
    HRESULT CheckMediaType(const CMediaType* pType);
    HRESULT SetMediaType(const CMediaType *pType);
    // Clear the flag so we see if IAsyncReader is queried for
    HRESULT CheckConnect(IPin *pPin);
    // See if it was asked for
    HRESULT CompleteConnect(IPin *pReceivePin);
    //  Remove our connection status
    HRESULT BreakConnect();


	// CSource
	HRESULT FillBuffer(IMediaSample *pms);

    // Ask for buffers of the size appropriate to the agreed media type
    HRESULT DecideBufferSize(IMemAllocator *pIMemAlloc,
                             ALLOCATOR_PROPERTIES *pProperties);

    HRESULT Active();    // Starts up the worker thread
    HRESULT Inactive();  // Exits the worker thread.

    // IAsyncReader methods
    // pass in your preferred allocator and your preferred properties.
    // method returns the actual allocator to be used. Call GetProperties
    // on returned allocator to learn alignment and prefix etc chosen.
    // this allocator will be not be committed and decommitted by
    // the async reader, only by the consumer.
    STDMETHODIMP RequestAllocator(IMemAllocator* pPreferred,
                      ALLOCATOR_PROPERTIES* pProps, IMemAllocator ** ppActual);

    // queue a request for data.
    // media sample start and stop times contain the requested absolute
    // byte position (start inclusive, stop exclusive).
    // may fail if sample not obtained from agreed allocator.
    // may fail if start/stop position does not match agreed alignment.
    // samples allocated from source pin's allocator may fail
    // GetPointer until after returning from WaitForNext.
    STDMETHODIMP Request(IMediaSample* pSample, DWORD dwUser);	        // user context

    // block until the next sample is completed or the timeout occurs.
    // timeout (millisecs) may be 0 or INFINITE. Samples may not
    // be delivered in order. If there is a read error of any sort, a
    // notification will already have been sent by the source filter,
    // and STDMETHODIMP will be an error.
    STDMETHODIMP WaitForNext(DWORD dwTimeout,
                      IMediaSample** ppSample,  // completed sample
                      DWORD * pdwUser);		// user context

    // sync read of data. Sample passed in must have been acquired from
    // the agreed allocator. Start and stop position must be aligned.
    // equivalent to a Request/WaitForNext pair, but may avoid the
    // need for a thread on the source filter.
    STDMETHODIMP SyncReadAligned(IMediaSample* pSample);

    // sync read. works in stopped state as well as run state.
    // need not be aligned. Will fail if read is beyond actual total
    // length.
    STDMETHODIMP SyncRead(LONGLONG llPosition,	// absolute file position
                      LONG lLength,		// nr bytes required
                      BYTE* pBuffer);		// write data here

    // return total length of stream, and currently available length.
    // reads for beyond the available length but within the total length will
    // normally succeed but may block for a long period.
    STDMETHODIMP Length(LONGLONG* pTotal,
                      LONGLONG* pAvailable);

    // cause all outstanding reads to return, possibly with a failure code
    // (VFW_E_TIMEOUT) indicating they were cancelled.
    // these are defined on IAsyncReader and IPin
    STDMETHODIMP BeginFlush(void);
    STDMETHODIMP EndFlush(void);

protected:
    CSourceFilter*	m_pReader;
    CAsyncIo*		m_pIo;
	LONGLONG		m_llPos;

    //  This is set every time we're asked to return an IAsyncReader
    //  interface
    //  This allows us to know if the downstream pin can use
    //  this transport, otherwise we can hook up to thinks like the
    //  dump filter and nothing happens
    bool         m_bQueriedForAsyncReader;

    HRESULT InitAllocator(IMemAllocator **ppAlloc);
};

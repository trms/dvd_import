
#include "FileList.h"
#include <XUFileNameUtils.h>
#include <algorithm>

namespace 
{
	static UINT GenerateCookie()
	{
		static UINT unCookie = 0;
		return ++unCookie;
	}
}

namespace SFIO
{
	///////////////////////////////////////////////////////////////////////////
	// CFileEntry implementation
	CFileEntry::CFileEntry(const CFileList& List, LPCWSTR wcsFileName) : 
		m_List(List),
		m_sFileName(wcsFileName),
		m_uiCookie(GenerateCookie()),
		m_hFile(INVALID_HANDLE_VALUE)
	{
		m_ullFileSize.QuadPart = m_ullCurPos.QuadPart = 0;

		Open();
		m_ullFileSize.LowPart = GetFileSize(m_hFile, (LPDWORD)&m_ullFileSize.HighPart);
		Close();
	}

	CFileEntry::CFileEntry(const CFileEntry& Entry) :
		m_List(Entry.m_List),
		m_sFileName(Entry.m_sFileName),
		m_ullFileSize(Entry.m_ullFileSize),
		m_uiCookie(GenerateCookie()),
		m_hFile(INVALID_HANDLE_VALUE)
	{
		m_ullCurPos.QuadPart = 0;
	}

	CFileEntry::~CFileEntry()
	{
		Close();
	}

	// File operations
	HRESULT	CFileEntry::Open()
	{
		Close();
		m_hFile = CreateFileW(m_sFileName, GENERIC_READ, m_List.m_dwShareMode,
								NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);

		if(m_hFile == INVALID_HANDLE_VALUE)
			throw XU::CW32FileExc(_T("Unable to open file"), XU::CTString(m_sFileName));
		return S_OK;
	}

	HRESULT	CFileEntry::Close()
	{
		if(m_hFile != INVALID_HANDLE_VALUE)
		{
			CloseHandle(m_hFile);
			m_hFile = INVALID_HANDLE_VALUE;
		}
		m_ullCurPos.QuadPart = 0;

		return S_OK;
	}

	HRESULT	CFileEntry::Seek(LONGLONG ullPos)
	{
		if(ullPos != m_ullCurPos.QuadPart)
		{
			assert(m_hFile != INVALID_HANDLE_VALUE);
			LARGE_INTEGER li;
			li.QuadPart = ullPos;
			DWORD dwRet = SetFilePointer(m_hFile, li.LowPart,
											&li.HighPart, FILE_BEGIN);

			if(dwRet == INVALID_SET_FILE_POINTER)
			{
				dwRet = GetLastError();
				if(dwRet != NO_ERROR)
					return HRESULT_FROM_WIN32(dwRet);
			}

			m_ullCurPos = li;
		}
		return S_OK;
	}

	HRESULT	CFileEntry::Read(LPBYTE pbBuffer, size_t stRead, size_t* pstActualRead)
	{
		assert(m_hFile != INVALID_HANDLE_VALUE);
		if(pstActualRead)
			*pstActualRead = 0;
		DWORD dwRead = 0;
		if(!ReadFile(m_hFile, pbBuffer, stRead, &dwRead, NULL))
			return HRESULT_FROM_WIN32(GetLastError());
		if(pstActualRead)
			*pstActualRead = dwRead;
		m_ullCurPos.QuadPart += dwRead;
		return S_OK;
	}


	/////////////////////////////////////////////////////////////////////////////////////
	// 	CFileList
	/////////////////////////////////////////////////////////////////////////////////////
	CFileList::CFileList() :
					m_dwShareMode(FILE_SHARE_READ|FILE_SHARE_WRITE),
					m_ullTotalDuration(0),
					m_pCurrent(NULL),
					m_nCurNumb(0),
					m_ullCurrOffsetBegin(0),
					m_ullCurrOffsetEnd(0)
	{}

	/////////////////////////////////////////////////////
	// File operations
	bool CFileList::MoveToFile(LONGLONG ullPos)
	{
		if(ullPos >= m_ullTotalDuration || empty())
			return false;

		ULONGLONG ullPrev = 0;
		for(iterator i = begin(); i != end(); i ++)
		{
			if(ullPrev <= ullPos && ullPos < ullPrev + (*i).GetSize())
			{
				m_nCurNumb = std::distance(i, begin());
				m_pCurrent = &(*i);
				m_ullCurrOffsetBegin = ullPrev;
				m_ullCurrOffsetEnd = ullPrev + m_pCurrent->GetSize();
				if(m_pCurrent->IsOpened())
					m_pCurrent->Open();
				return true;
			}
			ullPrev += (*i).GetSize();
		}
		return false;
	}


	HRESULT CFileList::Seek(LONGLONG ullPos)
	{
		if(m_ullCurrOffsetBegin <= ullPos &&
			ullPos < m_ullCurrOffsetEnd)
			return m_pCurrent->Seek(ullPos - m_ullCurrOffsetBegin);

		if(MoveToFile(ullPos))
			return m_pCurrent->Seek(ullPos - m_ullCurrOffsetBegin);

		return E_FAIL;
	}

	HRESULT CFileList::Read(LPBYTE pbBuffer, size_t stRead, size_t* pstActualRead)
	{
		return m_pCurrent->Read(pbBuffer, stRead, pstActualRead);
	}

	//////////////////////////////////////////////////////
	// List operation
	HRESULT CFileList::Add(LPCWSTR wcsFileName, UINT nPos)
	{
		if(nPos > size())
			nPos = size();
		if(nPos > m_nCurNumb || empty())
		{
			try
			{
				iterator i = begin();
				std::advance(i, nPos);
				CFileEntry f(*this, wcsFileName);
				insert(i, f);// keep file opened if it is the first entry
				m_ullTotalDuration += f.GetSize();
				if(size() == 1)
					MoveToFile(0);
			}
			catch(XU::CW32FileExc& e)
			{
				return (HRESULT)e;
			}
			return S_OK;
		}
		m_WaitingAddList.push_back(waiting_entry(wcsFileName, nPos));
		return S_FALSE;
	}

	HRESULT CFileList::Remove(UINT nPos)
	{
		if(nPos >= size())
			return E_INVALIDARG;

		iterator i = begin();
		std::advance(i, nPos);
		if(nPos > m_nCurNumb)
		{
			m_ullTotalDuration -= (*i).GetSize();
			erase(i);
			return S_OK;
		}
		m_WaitingRemoveList.push_back(waiting_entry((*i).GetName(), nPos));
		return S_FALSE;
	}

	HRESULT CFileList::Move(UINT nPosFrom, UINT nPosTo)
	{
		return E_NOTIMPL;
	}
}
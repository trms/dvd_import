
#include "FileStream.h"

namespace SFIO
{
	CFileStream::CFileStream() : m_dwKBPerSec(INFINITE),
								m_dwTimeStart(0)
	{}

	CFileStream::~CFileStream()
	{}


	HRESULT CFileStream::Read(PBYTE pbBuffer, DWORD dwBytesToRead,
					BOOL bAlign, LPDWORD pdwBytesRead)
	{
		CAutoLock lck(&m_csLock);
		size_t dwReadLength = 0;

		// Wait until the bytes are here!
		DWORD dwTime = timeGetTime();

		if(m_Files.GetCurrentPosition() + dwBytesToRead > m_Files.TotalDuration())
			dwReadLength = m_Files.TotalDuration() - m_Files.GetCurrentPosition();
		else
			dwReadLength = dwBytesToRead;

		DWORD dwTimeToArrive =
			((DWORD)m_Files.GetCurrentPosition() + dwReadLength) / m_dwKBPerSec;

		if(dwTime - m_dwTimeStart < dwTimeToArrive)
			Sleep(dwTimeToArrive - dwTime + m_dwTimeStart);

		HRESULT hr = m_Files.Read(pbBuffer, dwReadLength, &dwReadLength);
		*pdwBytesRead = dwReadLength;
		return hr;
	}

	LONGLONG CFileStream::Size(LONGLONG *pSizeAvailable)
	{
		LONGLONG llCurrentAvailable =
			static_cast <LONGLONG> (UInt32x32To64((timeGetTime() - m_dwTimeStart), m_dwKBPerSec));

		*pSizeAvailable =  min(m_Files.TotalDuration(), llCurrentAvailable);
		return m_Files.TotalDuration();
	}
}

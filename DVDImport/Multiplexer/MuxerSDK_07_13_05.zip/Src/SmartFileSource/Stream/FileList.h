
#pragma once

#include <XUString.h>
#include <list>

namespace SFIO
{
	class CFileList;

	class CFileEntry
	{
	public:
		CFileEntry(const CFileEntry& Entry);
		CFileEntry(const CFileList& List, LPCWSTR wcsFileName);
		~CFileEntry();
		
		// File operations
		HRESULT	Open();
		HRESULT	Close();
		HRESULT	Seek(LONGLONG ullPos);
		HRESULT	Read(LPBYTE pbBuffer, size_t stRead, size_t* pstActualRead);

		ULONGLONG	GetCurPos() const
		{
			return m_ullCurPos.QuadPart;
		}

		bool	IsOpened() const
		{
			return m_hFile == INVALID_HANDLE_VALUE;
		}

		// Properties
		LPCWSTR			GetName() const
		{
			return m_sFileName;
		}

		LONGLONG		GetSize() const
		{
			return m_ullFileSize.QuadPart;
		}

		UINT			GetCookie() const
		{
			return m_uiCookie;
		}

	private:
		XU::CWString		m_sFileName;
		LARGE_INTEGER		m_ullFileSize;
		UINT				m_uiCookie;

		HANDLE				m_hFile;
		LARGE_INTEGER		m_ullCurPos;

		const CFileList&	m_List;
	};

	class CFileList : public std::list<CFileEntry>
	{
		friend class CFileEntry;
	public:
		CFileList();

		/////////////////////////////////////////////////////
		// File operations
		HRESULT					Seek(LONGLONG ullPos);
		HRESULT					Read(LPBYTE pbBuffer, size_t stRead, size_t* pstActualRead);

		//////////////////////////////////////////////////////
		// List operation
		HRESULT					Add(LPCWSTR wcsFileName, UINT nPos = 0);
		HRESULT					Remove(UINT nPos);
		HRESULT					Move(UINT nPosFrom, UINT nPosTo);

		ULONGLONG				GetCurrentPosition() const
		{
			return m_ullCurrOffsetBegin + 
							m_pCurrent ?
							m_pCurrent->GetCurPos() : 0;
		}

		const CFileEntry*		GetCurrentEntry() const
		{
			return m_pCurrent;
		}

		size_t					GetCurrentNumber() const
		{
			return m_nCurNumb;
		}

		//////////////////////////////////////////////////////
		//
		ULONGLONG				TotalDuration() const
		{
			return m_ullTotalDuration;
		}

	private:
		
		//////////////////////////////////////////////////////
		//
		bool			MoveToFile(LONGLONG ullPos);

		DWORD			m_dwShareMode;
		ULONGLONG		m_ullTotalDuration;
		
		//
		CFileEntry*		m_pCurrent;
		size_t			m_nCurNumb;
		//
		ULONGLONG		m_ullCurrOffsetBegin;
		ULONGLONG		m_ullCurrOffsetEnd;

		/////////////////////////////////////////////////////////
		//
		struct	waiting_entry
		{
			waiting_entry(LPCWSTR wcsName, UINT nPos) : m_sName(wcsName), m_nPos(nPos)
			{}

			XU::CWString	m_sName;
			UINT			m_nPos;
		};

		typedef std::list<waiting_entry>	CWaitingList;

		CWaitingList		m_WaitingAddList;
		CWaitingList		m_WaitingRemoveList;
	};
}
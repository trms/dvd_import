
#pragma once
#include <windows.h>

namespace SFIO
{
	//  Model the stream we read from based on a file-like interface
	class AStream
	{
	public:
		virtual ~AStream() {};
		virtual HRESULT		SetPointer(LONGLONG llPos) = 0;
		virtual HRESULT		Read(PBYTE pbBuffer,
							DWORD dwBytesToRead,
							BOOL bAlign,
							LPDWORD pdwBytesRead) = 0;
		virtual LONGLONG	Size(LONGLONG *pSizeAvailable = NULL) = 0;
		virtual DWORD		Alignment() = 0;
		virtual void		Lock() = 0;
		virtual void		Unlock() = 0;
	};
}


#pragma once
#include <Streams.h>
#include "Stream.h"
#include "FileList.h"

namespace SFIO
{
	class CFileStream : public AStream
	{
	public:
		CFileStream();
		~CFileStream();
		
		///////////////////////////////////////////////////////////////
		// AStream impl

		HRESULT		SetPointer(LONGLONG llPos)
		{
			return m_Files.Seek(llPos);
		}

		HRESULT		Read(PBYTE pbBuffer, DWORD dwBytesToRead, BOOL bAlign, LPDWORD pdwBytesRead);
		LONGLONG	Size(LONGLONG *pSizeAvailable);

		DWORD Alignment()
		{
			return 1;
		}

		void Lock()
		{
			m_csLock.Lock();
		}

		void Unlock()
		{
			m_csLock.Unlock();
		}

		///////////////////////////////////////////////////
		//
		CFileList		m_Files;

	private:
		CCritSec		m_csLock;

		DWORD			m_dwKBPerSec;
		DWORD			m_dwTimeStart;
	};
}
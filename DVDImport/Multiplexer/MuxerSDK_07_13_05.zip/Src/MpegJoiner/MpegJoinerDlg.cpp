// MpegJoinerDlg.cpp : implementation file
//

#include "stdafx.h"
#include "MpegJoiner.h"
#include "MpegJoinerDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

CString FormatTime(REFERENCE_TIME rt)
{
	static const REFERENCE_TIME rtMilisec = 10000000 / 1000;
	static const REFERENCE_TIME rtMinute = 60 * 10000000;
	static const REFERENCE_TIME rtHour = 60 * rtMinute;
	ULONG wHours = rt/rtHour;
	rt -= wHours * rtHour;
	ULONG wMinutes = rt/rtMinute;
	rt -= wMinutes * rtMinute;
	ULONG wSeconds = rt/10000000;
	rt -= wSeconds * 10000000;
	ULONG wMiliSecs = rt/rtMilisec;
	TCHAR tcsTime[64];
	if(wHours)
		_stprintf(tcsTime, _T("%d:%d:%d:%d"), wHours, wMinutes, wSeconds, wMiliSecs);
	else
		_stprintf(tcsTime, _T("%d:%d:%d"), wMinutes, wSeconds, wMiliSecs);
	return CString(tcsTime);
}

// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CMpegJoinerDlg dialog



CMpegJoinerDlg::CMpegJoinerDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMpegJoinerDlg::IDD, pParent),
	m_bBusy(false)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMpegJoinerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST_INPUT_FILES, m_FileList);
	DDX_Control(pDX, IDC_EDIT_INFO, m_EditInfo);
}

BEGIN_MESSAGE_MAP(CMpegJoinerDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON_ADD, OnBnClickedButtonAdd)
	ON_BN_CLICKED(IDC_BUTTON_DELETE, OnBnClickedButtonDelete)
	ON_BN_CLICKED(IDC_BUTTON_UP, OnBnClickedButtonUp)
	ON_BN_CLICKED(IDC_BUTTON_DOWN, OnBnClickedButtonDown)
	ON_BN_CLICKED(IDC_BUTTON_BROWSE, OnBnClickedButtonBrowse)
	ON_BN_CLICKED(IDC_BUTTON_START, OnBnClickedButtonStart)
	ON_WM_TIMER()
	ON_WM_DROPFILES()
END_MESSAGE_MAP()


// CMpegJoinerDlg message handlers

BOOL CMpegJoinerDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	DragAcceptFiles();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	GetDlgItem(IDC_EDIT_OUTPUT)->SetWindowText(_T("C:\\Joined.mpg"));

	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMpegJoinerDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

void CMpegJoinerDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMpegJoinerDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CMpegJoinerDlg::OnBnClickedButtonAdd()
{
	CFileDialog dlg(TRUE, NULL, NULL, OFN_ALLOWMULTISELECT|OFN_EXPLORER|OFN_ENABLESIZING, 
		_T("MPEG files|*.mpeg;*.mpg;*.mpv;*.m1v;*.m2v;*.mpa;*.mp1;*.mp2;*.m2ts;*.m2t;*.mts;*.ts;*.dat;*.vob|All Files (*.*)|*.*||"));

	const size_t stBuffSize = 100 * MAX_PATH;
	TCHAR tcsFileNames[stBuffSize];
	tcsFileNames[0] = 0;
	dlg.m_pOFN->lpstrFile = tcsFileNames;
	dlg.m_pOFN->nMaxFile = stBuffSize;

	if(dlg.DoModal() == IDOK)
	{
		POSITION pos = dlg.GetStartPosition();
		CString sNextFile = dlg.GetNextPathName(pos);
		m_FileList.AddString(sNextFile);
		while(pos)
		{
			sNextFile = dlg.GetNextPathName(pos);
			m_FileList.AddString(sNextFile);
		}
	}
}

void CMpegJoinerDlg::OnBnClickedButtonDelete()
{
	int nSel = m_FileList.GetCurSel();
	if(nSel != -1)
		m_FileList.DeleteString(nSel);
}

void CMpegJoinerDlg::OnBnClickedButtonUp()
{
	int nSel = m_FileList.GetCurSel();
	if(nSel > 0)
	{
		CString sTmp;
		m_FileList.GetText(nSel, sTmp);
		m_FileList.DeleteString(nSel);
		m_FileList.InsertString(nSel - 1, sTmp);
		m_FileList.SetCurSel(nSel - 1);
	}
}

void CMpegJoinerDlg::OnBnClickedButtonDown()
{
	int nSel = m_FileList.GetCurSel();
	if(nSel != -1 && nSel < m_FileList.GetCount() - 1)
	{
		CString sTmp;
		m_FileList.GetText(nSel, sTmp);
		m_FileList.DeleteString(nSel);
		m_FileList.InsertString(nSel + 1, sTmp);
		m_FileList.SetCurSel(nSel + 1);
	}
}

void CMpegJoinerDlg::OnBnClickedButtonBrowse()
{
	CFileDialog dlg(FALSE, NULL, NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT |OFN_EXPLORER|OFN_ENABLESIZING, 
		_T("MPEG files|*.mpeg;*.mpg;*.mpv;*.m1v;*.m2v;*.mpa;*.mp1;*.mp2;*.m2ts;*.m2t;*.mts;*.ts;*.dat;*.vob|All Files (*.*)|*.*||"));
	if(dlg.DoModal())
		GetDlgItem(IDC_EDIT_OUTPUT)->SetWindowText(dlg.GetPathName());
}

void CMpegJoinerDlg::OnBnClickedButtonStart()
{
	BeginWaitCursor();
	if(m_bBusy)// Stop graph
	{
		m_Graph.Stop();
		m_Graph.Reset();// Reset filter graph
		GetDlgItem(IDC_STATIC_INFO)->SetWindowText(_T("Operation aborted"));
		SetState(false);
	}
	else // Build graph and start it
	{
		// Check if we have enougth information to build graph
		if(!m_FileList.GetCount())
		{
			MessageBox(_T("Need at least one input file"), _T("Error"), MB_OK|MB_ICONSTOP);
			return;
		}
		// Set input file sequence
		CString sPath;
		for(int n = 0; n < m_FileList.GetCount(); n++)
		{
			m_FileList.GetText(n, sPath);
			m_Graph.m_InputFileList.push_back((LPCTSTR)sPath);
		}
		// Set output file name
		GetDlgItem(IDC_EDIT_OUTPUT)->GetWindowText(sPath);
		m_Graph.m_sOutputFileName = (LPCTSTR)sPath;
		
		try
		{
			m_Graph.Init(NULL); // Build graph

			// Display graph info
			int nChars = 0;
			TCHAR tcsStr[256];
			m_EditInfo.SetWindowText(_T(""));
			for(CMpgJoinerGraph::CStringList::iterator i = m_Graph.m_GraphInfo.begin();
				i != m_Graph.m_GraphInfo.end(); i++)
				if(FormatMessage(FORMAT_MESSAGE_FROM_STRING|FORMAT_MESSAGE_IGNORE_INSERTS,
							XU::CTString((*i) + XU::CTString(_T("\n"))), 0, 0,
							tcsStr, 256, NULL))
				{
					m_EditInfo.SetSel(nChars, nChars, false);
					m_EditInfo.ReplaceSel(tcsStr, true);
					nChars += _tcslen(tcsStr);
				}

			// Start multiplexing
			HRESULT hr = m_Graph.Run();
			if(FAILED(hr))
				throw AMMTDS::CQuartzExc(_T("Unable to run grpah"), hr);
		}
		catch(const AMMTDS::CQuartzExc& e)
		{
			m_Graph.Reset();
			e.MsgBox();
			return;
		}
		SetState(true);
	}
	EndWaitCursor();
}

void CMpegJoinerDlg::OnCancel()
{
	CDialog::OnCancel();
}


void CMpegJoinerDlg::SetState(bool bBusy)
{
	GetDlgItem(IDC_LIST_INPUT_FILES)->EnableWindow(!bBusy);
	GetDlgItem(IDC_BUTTON_ADD)->EnableWindow(!bBusy);
	GetDlgItem(IDC_BUTTON_DELETE)->EnableWindow(!bBusy);
	GetDlgItem(IDC_BUTTON_UP)->EnableWindow(!bBusy);
	GetDlgItem(IDC_BUTTON_DOWN)->EnableWindow(!bBusy);
	GetDlgItem(IDC_EDIT_OUTPUT)->EnableWindow(!bBusy);
	GetDlgItem(IDC_BUTTON_BROWSE)->EnableWindow(!bBusy);
	GetDlgItem(IDC_BUTTON_START)->SetWindowText(
				bBusy ? _T("S T O P") : _T("S T A R T"));
	if(bBusy)
		SetTimer(1001, 500, NULL); // Start timer
	else
		KillTimer(1001);// Stop timer

	m_bBusy = bBusy;
}

void CMpegJoinerDlg::OnTimer(UINT nIDEvent)
{
	if(nIDEvent == 1001 && m_bBusy)
	{// Display progress
		static TCHAR tcsTmp[256];
		double fs = (double)m_Graph.GetBytesWritten()/1048576;
		_stprintf(tcsTmp, _T("Cur. time - %s | Written - %.2f MB"),
				(LPCTSTR)FormatTime(m_Graph.GetCurrentMuxTime()),
				fs);

		GetDlgItem(IDC_STATIC_INFO)->SetWindowText(tcsTmp);

		if(m_Graph.WaitForCompletion(0))// Check if graph has completed multiplexing
		{// Stop graph 
			m_Graph.Stop();
			m_Graph.Reset();
			_stprintf(tcsTmp, _T("%s | Operation completed"), tcsTmp);
			GetDlgItem(IDC_STATIC_INFO)->SetWindowText(tcsTmp);
			SetState(false);
		}
	}

	CDialog::OnTimer(nIDEvent);
}

void CMpegJoinerDlg::OnDropFiles(HDROP hDropInfo)
{
	if(m_bBusy)
		return;

	if(UINT nFiles = DragQueryFile(hDropInfo, 0xFFFFFFFF, NULL, 0))
	{
		TCHAR	tcsFileName[MAX_PATH];
		for(UINT n = 0; n < nFiles; n++)
		{
			DragQueryFile(hDropInfo, n, tcsFileName, MAX_PATH);
			m_FileList.AddString(tcsFileName);
		}
	}

	CDialog::OnDropFiles(hDropInfo);
}

//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//	Copyright (C) 2003 AMMTools. All rights reserved.
//	http://www.ammtools.com mailto:support@ammtools.com


#pragma once
#include "..\AMMTDS\DirectShow.h"

//
#include "..\Inc\MuxerFltrIfaces.h"
#include "..\Inc\SmartFileDumpFltrIfaces.h"
#include "..\Inc\SmartFileSourceFltrIfaces.h"

class CMpgJoinerGraph : public AMMTDS::CGraph
{
public:
	CMpgJoinerGraph();
	class CStringList : public std::list<XU::CTString>{};

	void Reset();

	// Graph building info
	CStringList			m_GraphInfo;

	// Input  and output filenames
	CStringList			m_InputFileList;
	XU::CTString		m_sOutputFileName;

	// Graph statistics
    REFERENCE_TIME		GetCurrentMuxTime() const;
    ULONGLONG			GetBytesWritten() const;        

protected:
	// CGraph overrides
	// Initialization
	virtual HRESULT		CreateFilters(LPCWSTR wcsSourceFile);
	virtual HRESULT		ConnectFilters();
	virtual HRESULT		QueryInterfaces();

private:
	bool				m_bConnectAutomatic;
	AMMTDS::CFilter		ConnectDemuxer(AMMTDS::CFilter& Source);
	void				SelectMuxer(AMMTDS::CPin pinVideo,AMMTDS::CPin pinAudio);
	AMMTDS::CPin		FindVideoPin(const AMMTDS::CFilter& Demuxer);
	AMMTDS::CPin		FindAudioPin(const AMMTDS::CFilter& Demuxer);

	// Filters
	AMMTDS::CFilter				m_Source;

	AMMTDS::CFilter				m_ProgramMuxer;
	AMMTDS::CFilter				m_SystemMuxer;

	AMMTDS::CFilter				m_FileDump;
	CComPtr<IFileSinkFilter>	m_DumpSink;
	CComPtr<IDumpProgress>		m_DumpProgress;

	// Currently selected multiplexer 
	AMMTDS::CFilter				m_Muxer;
	CComPtr<IMuxProgress>		m_MuxProgress;
};
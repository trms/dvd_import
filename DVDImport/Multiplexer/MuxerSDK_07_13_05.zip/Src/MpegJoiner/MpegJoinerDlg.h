// MpegJoinerDlg.h : header file
//

#pragma once
#include "afxwin.h"
#include "JoinerGraph.h"


// CMpegJoinerDlg dialog
class CMpegJoinerDlg : public CDialog
{
// Construction
public:
	CMpegJoinerDlg(CWnd* pParent = NULL);	// standard constructor

	afx_msg void OnBnClickedButtonAdd();
	afx_msg void OnBnClickedButtonDelete();
	afx_msg void OnBnClickedButtonUp();
	afx_msg void OnBnClickedButtonDown();
	afx_msg void OnBnClickedButtonBrowse();
	afx_msg void OnBnClickedButtonStart();
	afx_msg void OnTimer(UINT nIDEvent);

// Dialog Data
	enum { IDD = IDD_MPEGJOINER_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	virtual void OnCancel();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()

private:
	CListBox				m_FileList;
	CEdit					m_EditInfo;
	bool					m_bBusy;

	CMpgJoinerGraph			m_Graph;

	void SetState(bool bBusy);
public:
	afx_msg void OnDropFiles(HDROP hDropInfo);
};

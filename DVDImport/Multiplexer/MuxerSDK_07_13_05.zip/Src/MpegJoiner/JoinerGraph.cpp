//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//	Copyright (C) 2003 AMMTools. All rights reserved.
//	http://www.ammtools.com mailto:support@ammtools.com


#include "JoinerGraph.h"
#include "..\AMMTDS\DirectShowUtils.h"
#include "..\XUtils\XUExc.h"

#include "..\Inc\SmartFileDumpFltrGuids.h"
#include "..\Inc\MuxerFltrGuids.h"
#include "..\Inc\SmartFileSourceFltrGuids.h"

using namespace AMMTDS;

CMpgJoinerGraph::CMpgJoinerGraph() : m_bConnectAutomatic(false)
{}

// Initialization
HRESULT	CMpgJoinerGraph::CreateFilters(LPCWSTR wcsSourceFile)
{
	HRESULT hr = CreateFilter(CLSID_AMMTSmartFileSource, L"Source", &m_Source);
	if(FAILED(hr))
		throw CQuartzExc(_T("Unable to create AMMT Smart Source filter"), hr);
	
	CComPtr<IFileSourceFilter> pSrcFlt;
	if(SUCCEEDED(hr = m_Source.QueryInterface(&pSrcFlt)))
		hr = pSrcFlt->Load((LPCWSTR)XU::CWString(m_InputFileList.front()), NULL);

	if(FAILED(hr = CreateFilter(CLSID_AMMT_M2PS_MUXER, L"PS Multiplexer", &m_ProgramMuxer)))
		throw CQuartzExc(_T("Unable to create AMMT Multiplexer"), hr);

	if(FAILED(hr = CreateFilter(CLSID_AMMT_M2SS_MUXER, L"SS Multiplexer", &m_SystemMuxer)))
		throw CQuartzExc(_T("Unable to create AMMT Multiplexer"), hr);

	if(FAILED(hr = CreateFilter(CLSID_AMMT_SMART_FILE_DUMP, L"FileDump", &m_FileDump)))
		throw CQuartzExc(_T("Unable to create AMMT FileDump filter"), hr);

	// Create output file
	if(SUCCEEDED(hr = m_FileDump.QueryInterface(&m_DumpSink)))
		hr = m_DumpSink->SetFileName((LPCWSTR)XU::CWString(m_sOutputFileName), NULL);

	if(FAILED(hr))
		throw CQuartzExc(_T("Unable to create Output file"), hr);

	return S_OK;
}

HRESULT	CMpgJoinerGraph::ConnectFilters()
{
	HRESULT hr = S_OK;
	if(m_bConnectAutomatic)// Automatic - DirectShow finds suitable demultiplexer by itself
	{
		// Connect demuxer outputs with muxer
		CFilter::CPinsList SourcePins, MuxerPins;
		m_Source.EnumPins(SourcePins, IsOutNotConnected); // get Source pins
		// Try Program muxer
		m_ProgramMuxer.EnumPins(MuxerPins, IsInNotConnected); // get Muxer's not connected pins
		if(SUCCEEDED(hr = Connect(SourcePins.front(), MuxerPins.front())))// using intelegent connect
			m_Muxer = m_ProgramMuxer;
		else
		{	// Try System muxer
			m_SystemMuxer.EnumPins(MuxerPins, IsInNotConnected); // get Muxer's not connected pins
			if(SUCCEEDED(hr = Connect(SourcePins.front(), MuxerPins.front())))// using intelegent connect
				m_Muxer = m_SystemMuxer;
			else
				throw CQuartzExc(_T("Unable to connect Video Source and Multiplexer."), hr);
		}

		// Find Demultiplexer
		CPin DemuxPin;
		MuxerPins.front().p->ConnectedTo(&DemuxPin);
		PIN_INFO Info;
		if(SUCCEEDED(hr = DemuxPin.p->QueryPinInfo(&Info)) &&
						Info.pFilter)
		{
			CFilter Demuxer(Info.pFilter);
			Info.pFilter->Release();

			// Get other demuxer's output pins
			CFilter::CPinsList DemuxerPins;
			Demuxer.EnumPins(DemuxerPins, IsOutNotConnected);
			// Connect other pins to muxer
			for(CFilter::CPinsList::iterator i = DemuxerPins.begin();
					i != DemuxerPins.end(); i++)
			{
				m_Muxer.EnumPins(MuxerPins, IsInNotConnected); // get Muxer's not connected pins
				hr = Connect(*i, MuxerPins.front(), false);// not using intelegent connect
			}
		}
		else
			throw CQuartzExc(_T("Demultiplexer not found"), hr);

	}
	else // Not automatic - we're trying to connect only MS demultiplexers
	{
		// Try to conncet demuxer to source
		CFilter Demuxer = ConnectDemuxer(m_Source);
		if(!Demuxer)
			throw CQuartzExc(_T("Unable to connect Demultiplexer to Source"), E_FAIL);

		// Find demuxers audio and video pins
		CPin	PinVideo = FindVideoPin(Demuxer),
				PinAudio = FindAudioPin(Demuxer);

		// Decide which muxer (MPEG2 PS or MPEG1 SS) we need to use
		// with these input streams
		SelectMuxer(PinVideo, PinAudio);

		// Connect demuxer outputs with muxer
		CFilter::CPinsList MuxerPins;
		m_Muxer.EnumPins(MuxerPins, IsInNotConnected); // get Muxer's not connected pins
		if(PinVideo && FAILED(hr = Connect(PinVideo, MuxerPins.front())))
			throw CQuartzExc(_T("Unable to connect Video Source and Multiplexer."), hr);

		m_Muxer.EnumPins(MuxerPins, IsInNotConnected); // reget Muxer's not connected pins
		if(PinAudio && FAILED(hr = Connect(PinAudio, MuxerPins.front())))
			throw CQuartzExc(_T("Unable to connect Audio Source and Multiplexer."), hr);
	}
	// Connect output file dump to muxer
	CFilter::CPinsList MuxerPins, DumpPins;
	m_FileDump.EnumPins(DumpPins, IsInNotConnected); // get Dump's input pin
	m_Muxer.EnumPins(MuxerPins, IsOutNotConnected); // get Muxer's output pin
	if(FAILED(hr = Connect(MuxerPins.front(), DumpPins.front())))
		throw CQuartzExc(_T("Unable to connect Muliplexer and File dump"), hr);

	RemoveNotConnectedFilters();

	// Load the rest of input file list into source filter
	CComPtr<IPlayList> pPlayList;
	if(SUCCEEDED(hr = m_Source.QueryInterface(&pPlayList)))
	{
		CStringList::iterator i = m_InputFileList.begin();
		++ i;// start form next
		ULONG nNext = 1;
		for(i; i != m_InputFileList.end(); i ++, nNext ++)
			hr = pPlayList->Insert((LPCWSTR)XU::CWString(*i), 0, nNext);
	}

	return hr;
}

HRESULT	CMpgJoinerGraph::QueryInterfaces()
{
	HRESULT hr = m_FileDump.QueryInterface(&m_DumpProgress);
	if(FAILED(hr))
		throw CQuartzExc(_T("Unable to query IDumpProgress interface"), hr);
	if(FAILED(hr = m_Muxer.QueryInterface(&m_MuxProgress)))
		throw CQuartzExc(_T("Unable to query IMuxProgress interface"), hr);

	return CGraph::QueryInterfaces();
}

CPin	CMpgJoinerGraph::FindVideoPin(const CFilter& Demuxer)
{
	CFilter::CPinsList Pins;
	Demuxer.EnumPins(Pins, IsOutVideo);
	return !Pins.empty() ? Pins.front() : CPin();
}

CPin	CMpgJoinerGraph::FindAudioPin(const CFilter& Demuxer)
{
	CFilter::CPinsList Pins;
	Demuxer.EnumPins(Pins, IsOutAudio);
	return !Pins.empty() ? Pins.front() : CPin();
}

CFilter	CMpgJoinerGraph::ConnectDemuxer(CFilter& Source)
{	// Connect demultiplexer to file source pin
// {172F4AD1-160C-462b-8D55-BD1D3359CE8C}
	static const GUID CLSID_AMMTDemultiplexer =  
		{0x172f4ad1, 0x160c, 0x462b, {0x8d, 0x55, 0xbd, 0x1d, 0x33, 0x59, 0xce, 0x8c}};

	static const GUID* clsCLSIDs[] = {//	&CLSID_MPEG2Demultiplexer,		// Demultiplexer options we have
									//	&CLSID_MPEG1Splitter,
									//	&CLSID_MMSPLITTER,
										&CLSID_AMMTDemultiplexer};

	static const LPCTSTR tcsDemuxNames[] = {//_T("Microsoft MPEG-2 Demultiplexer"),		// 
											//_T("Microsoft MPEG-1 Splitter"),
											//_T("Microsoft MPEG-2 Splitter"),
											_T("AMMTools MPEG-1/MPEG-2 Demultiplexer")};

	HRESULT hr = E_FAIL;
	for(size_t n = 0; n < sizeof(clsCLSIDs)/sizeof(GUID*); n++)
	{
		CFilter Demuxer;
		if(SUCCEEDED(hr = CreateFilter(*clsCLSIDs[n], L"Demuxer", &Demuxer)))
		{
			CFilter::CPinsList SourcePins, DemuxerPins;
			Source.EnumPins(SourcePins, IsOutPin);
			Demuxer.EnumPins(DemuxerPins, IsInPin);
			if(SUCCEEDED(hr = Connect(SourcePins.front(),
									DemuxerPins.front(), false)))
			{
				m_GraphInfo.push_back(XU::CTString(_T("Using demultiplexer: ")) +
									XU::CTString(tcsDemuxNames[n]));
				return Demuxer;
			}
		}
	}

	return CFilter();// empty object
}

void CMpgJoinerGraph::SelectMuxer(CPin pinVideo, CPin pinAudio)
{
	// Check which media types we have on audio and video pins and
	// select MPEG2 Program or MPEG1 System multiplexer we have to use
	CPin::CMediaTypeList MtList;
	bool bVideoMPEG2 = false, bAudioMPEG2 = false;

	if(pinVideo)
		if(SUCCEEDED(pinVideo.GetMediaTypes(MtList)) &&
			!MtList.empty())
		{
			bVideoMPEG2 = MtList.front().subtype == MEDIASUBTYPE_MPEG2_VIDEO;
			m_GraphInfo.push_back(FormatStreamName(&MtList.front()));
		}

	if(pinAudio)
		if(SUCCEEDED(pinAudio.GetMediaTypes(MtList)) &&
			!MtList.empty())
		{
			bAudioMPEG2 = MtList.front().subtype == MEDIASUBTYPE_DOLBY_AC3;
			m_GraphInfo.push_back(FormatStreamName(&MtList.front()));
		}

	m_Muxer = (bVideoMPEG2 || bAudioMPEG2) ? m_ProgramMuxer : m_SystemMuxer;
	m_GraphInfo.push_back((bVideoMPEG2 || bAudioMPEG2) ?
				XU::CTString(_T("Using MPEG-2 Program Stream Multiplexer")):
				XU::CTString(_T("Using MPEG-1 System Stream Multiplexer")));
}

void CMpgJoinerGraph::Reset()
{
	m_InputFileList.clear();
	m_GraphInfo.clear();

	m_DumpSink.Release();
	m_DumpProgress.Release();
	m_MuxProgress.Release();
	m_Source.Release();
	m_Muxer.Release();
	m_ProgramMuxer.Release();
	m_SystemMuxer.Release();
	m_FileDump.Release();

	CGraph::Reset();
}
// Graph statistics
REFERENCE_TIME CMpgJoinerGraph::GetCurrentMuxTime() const
{
	REFERENCE_TIME rt = 0;
	m_MuxProgress->GetCurrentMuxTime(&rt);
	return rt;
}

ULONGLONG CMpgJoinerGraph::GetBytesWritten() const    
{
	ULONGLONG ull = 0;
	m_DumpProgress->GetProgress(NULL, &ull);
	return ull;
}
